# Financial Domain — Top 3 Configs (FinQA & TatQA)

Candidate configs for the `ragbench-top3-demo` app, matching the same convention already used for
bio-medical (`v8c`/`v8e`/`v8l`) and Legal (`v19`/`v25`/`v31`): exactly 3 configs kept per dataset,
each with a `CONFIG_METADATA` entry in `demo_data.py`.

Ranked by `adherence_aucroc` (the project's headline hallucination-detection metric) as primary,
RMSE as secondary. Full run history and methodology: see `Observations and Inference.md`.

---

## Effort behind this selection

These 6 configs (3 per dataset) were selected from the project's full run history:

- **FinQA: 6 iterations** — `v2`, `v3`, `v4` (adopted/final), `v5`, `v6`, `finqa_v10`
  (8 standard eval runs total, since `v2` and `v5` were each run twice; plus 12 RGB robustness sub-runs)
- **TatQA: 11 iterations** — `tatv1`, `tatv2`, `tatv3` (adopted/final), `tatv3_recheck`, `tatv4`,
  `tatv5_best`, `tatv6`, `tatv7`, `tatv8`, `tatv9`, `tatv10`
  (11 standard eval runs, one per version — `tatv6` incomplete at 56/80; plus 6 RGB robustness sub-runs)
- **Total: 17 named config iterations, 38 checkpoint run files** across both domains.

---

## FinQA — top 3 by adherence_aucroc

| Rank | Config | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
|---|---|---|---|---|---|---|
| 1 | **`v4`** (adopted/final) | 15 | 0.122 | 0.112 | **0.186** | **0.786** |
| 2 | `v3` | 15 | **0.098** | **0.078** | 0.248 | 0.714 |
| 3 | `v5` (n=33 run) | 33 | 0.089 | 0.068 | 0.388 | 0.496 |

**Notes:**
- `v4` — larger embedding model (`bge-large` vs `bge-small`), independent judge, adopted as the
  final FinQA configuration. Best completeness and adherence of any FinQA run.
- `v3` — first run with an independent judge model (previously self-judged). Best relevance and
  utilization RMSE among the top 3; proved the self-evaluation-bias fix.
- `v5` (n=33) — largest-sample FinQA run, best raw relevance/utilization RMSE of *any* FinQA run
  on record, but flagged in the project docs as diagnostic/noisy: `generation_temperature=0.2`
  (not pinned to `0.0` like `v3`/`v4`), so the improvement isn't isolated from generation noise.
  Never adopted as a replacement for `v4`.

**Alternative #3, if a cleaner narrative is preferred over raw score:** `v2` (self-judged baseline,
n=15, rel=0.296/util=0.347/comp=0.444, aucroc=0.429) — tells the v2→v3→v4 progression story
coherently (self-eval bias → independent judge → better embeddings) but scores lower than `v5`.

---

## TatQA — top 3 by adherence_aucroc

| Rank | Config | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
|---|---|---|---|---|---|---|
| 1 | `tatv4` | 40 | 0.205 | 0.164 | 0.389 | **0.617** |
| 2 | `tatv10` | 77 | 0.264 | 0.261 | 0.318 | 0.577 |
| 3 | **`tatv3`** (adopted/final) | 15 | **0.157** | **0.160** | **0.397** | 0.558 |

**Notes:**
- `tatv4` — same config as `tatv3`, `n` raised 15→40 as a reproducibility/fragility check. Highest
  raw aucroc, but the project explicitly frames this run as diagnostic evidence about measurement
  noise, not a stronger config than `tatv3`.
- `tatv10` — reverted the judge prompt to its pre-`tatv5_best` (original RAGBench-verbatim) form at
  n=77. Recovered aucroc back toward the `tatv3`/`tatv4` band, but introduced 26 new false
  positives (27/77 mismatches, 35% — the worst raw mismatch rate of any TatQA run). AUCROC and raw
  accuracy moved in opposite directions here; see `Observations and Inference.md`'s `tatv10` entry
  for the full row-level analysis.
- `tatv3` — top_k restored to `tatv1`'s values + random sampling (seed 42). **The actual adopted,
  presented TatQA configuration** — best relevance/utilization/completeness RMSE of the three, and
  the only one of the three the project formally adopted, despite ranking 3rd by raw aucroc alone.

**Open question:** by strict aucroc ranking, the adopted `tatv3` places 3rd, not 1st. If the demo
should lead with the config the project actually recommends (matching every other write-up in this
project), swap ordering to `tatv3` → `tatv4` → `tatv10` instead of pure score order.

---

## Implementation notes (for `ragbench-top3-demo`)

Two open decisions before wiring this into the repo:

1. **Ordering:** strict score ranking (as tabled above) vs. adopted-config-first (matches the rest
   of this project's documented recommendations).
2. **Checkpoint pruning:** bio-medical and Legal both physically pruned `checkpoints/<category>/`
   down to only the 3 selected configs. Financial currently has all 17 historical run folders on
   disk. Decide whether to prune to just these 6 folders (3 FinQA + 3 TatQA) or leave full history
   in place and only add `CONFIG_METADATA` entries for the 6 selected configs.

`CONFIG_METADATA` entries to add to `demo_data.py` once the above is decided (example, matching the
existing Legal/bio-medical style):

```python
"v4": {
    "domains": ["finqa"],
    "embed_model": "bge-large-en-v1.5",
    "judge_model": "independent (openai/gpt-oss-120b)",
    "notes": "Adopted FinQA config — best completeness & adherence",
},
"v3": {
    "domains": ["finqa"],
    "judge_model": "independent (openai/gpt-oss-120b)",
    "notes": "First independent-judge run — best relevance & utilization",
},
"v5": {
    "domains": ["finqa"],
    "max_samples_per_domain": 33,
    "notes": "Largest-sample FinQA run (diagnostic — temp=0.2, not pinned)",
},
"tatv3": {
    "domains": ["tatqa"],
    "sample_strategy": "random",
    "sample_seed": 42,
    "notes": "Adopted TatQA config — best RMSE across the board",
},
"tatv4": {
    "domains": ["tatqa"],
    "max_samples_per_domain": 40,
    "notes": "tatv3 config at larger n (reproducibility check, diagnostic)",
},
"tatv10": {
    "domains": ["tatqa"],
    "max_samples_per_domain": 80,
    "notes": "Reverted judge prompt — highest aucroc at n=77, but worst mismatch rate",
},
```
