# Presentation Script — Evaluating a Retrieval-Augmented Generation Pipeline for Financial Question Answering

**Target delivery time:** 10–15 minutes (≈1,900 spoken words at a measured academic pace, excluding Q&A)
**Format:** 13 slides, script written for verbatim or near-verbatim delivery. `[Slide N: Title]` marks each transition — build the deck to match these beats one-for-one.

---

## Delivery Notes (read before rehearsing, not part of the script)

- Pace: ~130–150 words/minute is normal for a technical academic talk. Rehearse once against a timer.
- The two numbers to land with weight, pausing half a beat before and after: **0.429 → 0.786** (finqa adherence AUROC) and **"below random guessing."** These are your hook and your payoff — don't rush them.
- When you say a metric name for the first time (Relevance, Utilization, Completeness, Adherence, RMSE, AUROC), slow down slightly — this is where a professor's ear either locks in or drifts.
- If time runs short, Slides 9 (temperature noise) and 12 (RGB robustness) are the safe cuts — they strengthen credibility but the core narrative (Slides 1–8, 10–11) survives without them.

---

## [Slide 1: Title]

**Evaluating a Retrieval-Augmented Generation Pipeline for Financial Question Answering: An Iterative, Metric-Driven Approach**

Good [morning/afternoon]. Financial documents — earnings reports, 10-Ks, tabular disclosures — are exactly the kind of source material where large language models are most tempted to sound confident and be wrong. Today I'll walk through how I built and evaluated a Retrieval-Augmented Generation, or RAG, pipeline specifically for this domain, using a rigorous, benchmark-driven methodology to answer one question: not just "does it work," but "how do we *know* it works, and how do we know when it doesn't?"

## [Slide 2: Why Financial RAG, and Why Evaluation Is the Hard Part]

Financial question answering has a property that makes it an unusually demanding testbed for RAG systems: the answers are frequently **numerical, multi-step, and table-derived** — a percentage change between two fiscal years, a ratio buried across two different tables, a return computed from values that appear in different documents entirely. Unlike open-domain trivia, there is very little room for a plausible-sounding wrong answer to pass unnoticed. Getting the number wrong isn't a stylistic failure — it's a factual one, with real downstream consequences if this kind of system were ever trusted in a real workflow.

That is precisely why evaluation, not generation, was the center of gravity for this project. Anyone can wire an LLM to a vector database and get answers that *look* fluent. The much harder and more scientifically interesting question is: how do you measure, with a defensible number, whether the system is retrieving the right evidence, using it fully, and — critically — whether it is hallucinating. This project used **RAGBench**, a public benchmark built for exactly this purpose, across two financial sources: **FinQA**, financial-report question answering over tables and text, and **TatQA**, tabular-and-textual QA. Both are real filings-derived corpora, not synthetic data.

## [Slide 3: The TRACe Framework — Four Questions About Every Answer]

RAGBench evaluates every system response along four dimensions, collectively called **TRACe**:

- **Relevance** — of everything the retriever pulled back, how much of it was actually useful?
- **Utilization** — of everything retrieved, how much did the generator actually use?
- **Completeness** — of the useful material, how much of it made it into the final answer?
- **Adherence** — is every claim in the answer actually backed by the retrieved evidence, or did the model invent something?

Think of it as three roles working together on every single question, plus a report card. A **Librarian** — the retrieval system — searches a corpus of over a thousand documents two ways at once: a keyword search and a meaning-based search, fused together, and hands over the top handful. Those documents become a **prompt**: instructions, context, and the question, glued into the exact text sent to the model. A **Student** — the generator — writes an answer grounded, in principle, only in what it was given. And then, crucially, a **Grader** — a *separate* model — checks the work, sentence by sentence, the same way you would never let a student grade their own exam.

That separation between Student and Grader is not a minor implementation detail. It turns out to be the single most important design decision in this entire project, and I'll return to it directly.

## [Slide 4: Two Metrics, Two Kinds of Question]

Relevance, Utilization, and Completeness are continuous quantities — fractions between 0 and 1 — so they're scored against RAGBench's expert-annotated ground truth using **RMSE**, root-mean-squared error: on average, how far off was our predicted score from the true score, in either direction. Lower is strictly better, and zero would mean perfect agreement with the human-annotated reference.

Adherence is different in kind — it's a yes/no hallucination flag, not a fraction — so it's scored with **AUROC**, the area under the ROC curve: if you sort every answer from "most suspicious" to "least suspicious" by the grader's opinion, how well does that ordering actually put the truly hallucinated answers near the top? An AUROC of 0.5 is a coin flip — no better than random guessing. RAGBench's own paper reports 0.51 to 0.80 for comparable automated judges, which gave us a credible external yardstick to evaluate against, not just an internal one.

## [Slide 5: Methodology — Discipline Over Sweep]

The methodology was deliberately conservative: **one configuration change per iteration**, each one justified in advance by a specific hypothesis, with pre-registered confirm and falsify criteria decided *before* looking at the results — never a batch grid search. Every configuration was logged as a named, append-only entry, each keyed by a content hash of every field that could affect the output, specifically so that an edited configuration could never silently reuse stale results under an old name. That discipline mattered in practice — checkpoint verification caught more than one case where an apparently "new" result was actually leftover data from a previous run, which is exactly the kind of silent corruption that invalidates a project's conclusions if it isn't guarded against.

All runs share a common backbone: hybrid dense-plus-BM25 retrieval with reciprocal rank fusion, MMR diversity re-ranking, cross-encoder re-ranking, whole-document retrieval units — no chunking — a `llama-3.3-70b-versatile` generator, and a chain-of-thought generation prompt where the grader sees the model's full reasoning, not just its final answer. Against that fixed backbone, three variables were tested in sequence on FinQA: the judge model's independence, the embedding model, and — later — sampling strategy and scale, each isolated one at a time.

## [Slide 6: FinQA — The Baseline, and a Warning Sign]

The baseline configuration, `v2`, enabled every retrieval sophistication at once — hybrid search, fusion, MMR, re-ranking — and used the *same* model, `llama-3.3-70b-versatile`, as both the answer-generator and the grader.

The results: relevance RMSE 0.296, utilization RMSE 0.347, completeness RMSE 0.444, and — this is the number to sit with — **adherence AUROC of 0.429.** Below 0.5. Below random guessing. That doesn't mean the grader was merely noisy; it means its hallucination judgments were, on this sample, actively pointing in the wrong direction. The most direct, textbook explanation is self-evaluation bias: a model grading its own work is a well-documented failure mode in the literature, and it was the natural first hypothesis to test.

## [Slide 7: The Turning Point — An Independent Judge]

`v3` changed exactly one field: the judge model, from `llama-3.3-70b-versatile` — the same model as the generator — to `openai/gpt-oss-120b`, a genuinely independent model family. Every other setting was held identical.

The result was the single largest swing of the entire project, from **one field.** Relevance RMSE fell 67%, to 0.098. Utilization RMSE fell 78%, to 0.078. Completeness RMSE fell 44%, to 0.248. And adherence AUROC nearly doubled, from 0.429 to **0.714** — moving from below-random straight into RAGBench's own published range for competent judges. This is, to my mind, the headline finding of the project: judge independence was not a minor tuning knob. It was the dominant lever, and it confirms, with a controlled single-variable test rather than an anecdote, that self-evaluation bias is real and large in this setting.

## [Slide 8: Refining Further — Embedding Quality, and an Honest Trade-off]

With judge independence secured, the next isolated test targeted the retriever itself: swapping the embedding model from `bge-small-en-v1.5` to the larger `bge-large-en-v1.5`, same model family, holding everything else — including the judge — fixed. This became `v4`, the final adopted FinQA configuration.

Completeness RMSE improved a further 25%, to 0.186, and adherence AUROC climbed to **0.786** — landing at the top of RAGBench's reported range, and, importantly, verified as a genuine accuracy gain: adherence mismatches dropped from 8 rows out of 15 to 6, not merely a ranking artifact. But I want to be explicit about the trade-off, because reporting it honestly is part of the scientific claim: relevance and utilization RMSE got *moderately worse* — 0.122 versus 0.098, and 0.112 versus 0.078. A larger embedding model was not a free lunch; it reshaped *which* documents entered the candidate pool in a way that helped two metrics and cost two others. Across the full arc from `v2` to `v4`, though, every metric moved decisively in the right direction: relevance RMSE down 59%, utilization down 68%, completeness down 58%, and adherence AUROC up from below-random to the top of the published range for comparable judges.

## [Slide 9: Stress-Testing Our Own Result — The Temperature Discovery]

Before accepting `v4`, I ran a fragility check: the identical configuration, re-run at a larger sample size. If `v4`'s strong adherence number was real, it should hold up. It didn't hold up cleanly — and the reason turned out to be more interesting than a configuration bug. The generation step runs at `temperature=0.2`, not `0.0`. On re-run, only 1 of 15 questions produced a byte-identical response to the original run; the rest differed, and predicted adherence flipped on 8 of 15 rows purely from that regenerated text — even the *judge's* own verdict on one byte-identical response changed between runs. This pattern reproduced independently on the TatQA track as well.

I'm including this not as a caveat to apologize for, but as a finding in its own right: it means every single-run metric delta in this project carries a genuine noise floor, and it's why the large, directionally consistent gains — like the `v2`-to-`v3` judge swap — can be trusted at face value, while smaller or mixed-direction deltas should be read as noisy point estimates. Distinguishing a real signal from sampling noise is, arguably, as much the point of this project as the numbers themselves.

## [Slide 10: A Second Domain — TatQA, and a Genuine A/B Test]

To check whether these findings generalized, I applied FinQA `v4`'s proven levers to TatQA — the tabular-and-textual QA track — as a starting point, then tested what was domain-specific. TatQA's documents are far shorter than FinQA's, 388 characters versus 1,342 on average, so the baseline, `tatv1`, raised the retrieval width accordingly. A direct isolation test, `tatv2`, reverted that width back to FinQA's values on the *identical* question set: relevance and utilization RMSE improved, but completeness RMSE worsened by 38% and adherence mismatches increased — a clean falsification of the naive "smaller retrieval is always better" intuition. The wider retrieval was restored, and TatQA's final configuration, `tatv3`, additionally fixed a structural measurement problem: the original deterministic sampling had, by chance, drawn 15 questions that were *all* non-hallucinated, making AUROC mathematically undefined regardless of configuration. Switching to seeded random sampling resolved that and produced TatQA's first computable adherence score: **0.558** — modest, at the low end of RAGBench's range, but for the first time, real.

## [Slide 11: What the Data Actually Tells Us]

Pulling this together into conclusions I'd defend under questioning:

First, **judge and embedding quality mattered far more than retrieval-ranking sophistication.** Hybrid search, fusion, MMR, and re-ranking were all enabled from the very first run, and none of the measured gains came from them — every real improvement came from *who judged* the output and *what embedded* the documents.

Second, **self-evaluation bias is not a theoretical concern; it is large and directly measurable** — the single biggest lever in this entire project, worth nearly doubling an AUROC score on its own.

Third, **quality improvements trade off, they don't stack for free** — the embedding upgrade that helped completeness and adherence genuinely cost relevance and utilization accuracy.

Fourth, **residual error is partly structural, not a pipeline defect** — ground-truth scores are computed against RAGBench's own reference answer, not our pipeline's generated one, so occasional genuine arithmetic slips by the generator get correctly flagged by the judge but scored against a different correct answer. And a specific, reproducible judge weakness — inconsistent leniency toward harmless "scaffolding" reasoning sentences like *"to find X, we need to look at Y"* — was confirmed independently across both domains and two different question samples, and a proposed automated fix was tested and explicitly *rejected* after it was shown to also forgive a genuine hallucination, dropping AUROC from 0.786 to 0.321. Knowing when *not* to apply a fix is as much a result as knowing when to apply one.

## [Slide 12: Beyond TRACe — A Reality Check on Robustness]

As a final, independent check, I also ran a second benchmark methodology — the RGB robustness tests from Chen et al. (2023) — which ask a different question: does the model correctly refuse to answer when no retrieved document actually contains the information? On both domains, the answer was reassuring: **93.3% negative-rejection accuracy on FinQA, 86.7% on TatQA** — the model reliably declines rather than fabricates when the context genuinely doesn't support an answer. This is a cleaner, more intuitive signal than adherence AUROC, and it corroborates the adherence story from an entirely different angle.

## [Slide 13: Future Work, and Closing]

Three concrete next steps follow directly from what the data showed: **pin generation temperature to 0.0** — or explicitly report a spread across repeated runs — since this is now the single highest-value methodological fix for trusting future deltas at face value; **target the scaffolding-sentence leniency inconsistency with judge-prompt engineering**, since it's now confirmed cross-domain and is the largest *unresolved*, well-understood gap; and **scale sample size beyond n=15** once a configuration is locked, particularly for TatQA, where only two hallucination examples currently exist to measure detection against.

To close: this project's real contribution isn't a single leaderboard number. It's a demonstrated, reproducible answer to *why* a financial RAG system succeeds or fails — self-evaluation bias, embedding trade-offs, sampling artifacts, and generation-temperature noise are not footnotes here; they were each isolated, tested, and named. That is the standard I believe evaluation work in this space should be held to. Thank you — I'm happy to take questions.

---

## Anticipated Questions & Answers

### Methodology

**Q1. Why change only one configuration variable per iteration instead of running a full grid search?**
A grid search would confound effects — if judge model and embedding model changed together, an improvement couldn't be attributed to either one. Single-variable isolation, with a pre-registered hypothesis and falsify criterion decided *before* seeing results, is what lets me claim "the judge swap alone produced this gain" rather than "something in this batch of changes helped." It costs more runs, but it's the only way to get causally interpretable results from n=15 experiments.

**Q2. Why is your sample size only 15 questions per run?**
Cost and time — each run consumes API budget and wall-clock time (roughly 10–20 minutes per run), and this was an iterative, hypothesis-driven project rather than a single final benchmark submission. I address this limitation directly: adherence AUROC in particular is statistically fragile at n=15 with as few as one or two true-hallucination examples, and I ran fragility checks (`v5`, `tatv4`) at larger n specifically to probe this. Scaling sample size once a configuration is locked is explicit future work.

**Q3. How did you avoid silently re-using stale results across configuration changes?**
Every configuration is a named, append-only registry entry keyed by a content hash of every field that affects the output — so an edited config can never resume under an old name and silently mix results. I additionally verified every reported number directly against the raw checkpoint JSONL files rather than trusting pasted screenshots or partial re-runs, which caught real cases of stale data during the project.

**Q4. Why hold retrieval sophistication (hybrid search, MMR, re-ranking) constant instead of testing it as a variable?**
It was tested earlier, informally, against a plain dense-only baseline, and showed no statistically distinguishable difference — so it was fixed "on" as a reasonable default and the limited experimental budget was redirected toward the two variables that turned out to matter far more: judge independence and embedding quality. This is flagged as an explicit limitation, particularly for TatQA, where that retrieval configuration was inherited from FinQA rather than independently re-verified.

### Metrics

**Q5. Why use RMSE for three metrics and AUROC for the fourth?**
Relevance, Utilization, and Completeness are continuous fractions, so RMSE — average magnitude of error against ground truth — is the natural regression metric. Adherence is a binary hallucination flag, so it's evaluated as a ranking/classification problem: AUROC measures whether sorting answers by predicted suspicion correctly separates the hallucinated ones from the clean ones, independent of any particular threshold.

**Q6. What does an AUROC of 0.429 actually mean — isn't "below random" strange for a real model?**
It means that on this specific sample, the judge's hallucination scores were, on average, mildly *anti-correlated* with the true labels rather than just noisy. With only one truly hallucinated example in the sample, the score is highly sensitive to that single row: it happened to receive the *lowest* possible suspicion score, while two genuinely correct answers received the *highest*, which is close to the worst possible ordering three mismatches out of fifteen rows can produce. I state this class-imbalance sensitivity explicitly rather than treating 0.429 as a stable measurement.

**Q7. Why did AUROC improve while raw exact-match adherence accuracy dropped, when you swapped judges?**
Because AUROC measures ranking quality, not accuracy at a fixed threshold. The independent judge became *more* likely to flag things as unsupported overall — including several genuinely correct, arithmetic-derived answers — which lowered raw exact-match accuracy (80% to 47%) even as it correctly pushed the one true hallucination toward the "most suspicious" end of the ranking, which is what AUROC rewards. I report both numbers together specifically so this isn't misread as an unqualified win.

**Q8. What is TRACe, and is it your own metric or an established one?**
TRACe — Relevance, Utilization, Completeness, Adherence — is RAGBench's own evaluation framework, published alongside the benchmark. I didn't design it; I implemented a judge pipeline that predicts these four quantities per question and regressed the predictions against RAGBench's expert-annotated ground truth, which is what makes the RMSE/AUROC numbers externally comparable to RAGBench's own reported judge performance (0.51–0.80 AUROC).

### Results & Trade-offs

**Q9. The embedding upgrade (`v4`) made relevance and utilization worse — why adopt it anyway?**
Because the net effect was positive against the metric I judged most decision-relevant: adherence, the hallucination-detection signal, improved by a *verified accuracy* margin (6 mismatches versus 8, not just a ranking artifact), and completeness improved substantially (25%). Relevance and utilization regressed moderately, not catastrophically. I report this as a genuine trade-off rather than a clean win, and it's exactly the kind of result single-variable isolation is designed to surface honestly.

**Q10. Why does TatQA's adherence AUROC (0.558) land so much lower than FinQA's (0.786)?**
Primarily a measurement artifact of sample size, not a genuine capability gap: TatQA's final sample contains only two true-hallucination examples at n=15, versus FinQA's own fragile one-example baseline. With so few positive examples, one or two judge disagreements move the score substantially. It's a real, reported number, but I'd want a larger sample before treating the FinQA/TatQA gap as evidence of a genuine cross-domain performance difference.

**Q11. What is the "scaffolding-sentence" issue, concretely?**
The judge is asked to mark every generated sentence as fully supported by the retrieved evidence or not. Harmless, non-factual reasoning sentences — like "to find X, we need to look at Y" — carry no factual claim to verify, yet the judge inconsistently marks some of them `unsupported` anyway, sometimes even while its own category tag calls the same sentence "general." Since a response's overall adherence is the logical AND across all its sentences, one mis-flagged scaffolding sentence can sink an otherwise fully correct answer. I confirmed this recurs across both domains and two independently sampled question sets, so I treat it as a genuine, reproducible model behavior rather than an artifact of one dataset.

**Q12. You tried to fix that automatically and rejected the fix — why not ship it anyway, since it seems like an improvement?**
Because verification showed it wasn't one. The rule I tested — trusting the judge's own category tags over its supported/unsupported flag — did suppress some scaffolding-sentence false positives, but it also forgave the *one genuinely hallucinated response* in the sample, because that response happened to share a category tag with the harmless cases. AUROC dropped from 0.786 to 0.321. A fix that erases your only true-positive detection is worse than the problem it solves, and I could only know that by testing it against the actual checkpoint data rather than reasoning about it in the abstract.

**Q13. What does the RGB robustness test add that TRACe adherence doesn't already tell you?**
They measure different failure modes. TRACe adherence checks partial support *within* an otherwise-relevant context — did every sentence in the answer trace back to evidence. RGB's negative-rejection test is a harder, cleaner probe: give the model a context built entirely from irrelevant documents, with zero information needed to answer, and see if it correctly says "I can't answer" rather than fabricating. The high rejection rates (93.3% FinQA, 86.7% TatQA) corroborate the adherence story from an independent angle and are a more intuitive number to communicate.

### Limitations & Validity

**Q14. How much of your improvement could just be noise, given the temperature=0.2 finding?**
I address this directly rather than downplaying it: the large, directionally consistent gains — especially the `v2`-to-`v3` judge-independence swing, which moved every metric substantially in the same direction — are very unlikely to be pure noise. Smaller or mixed-direction deltas, like `v3`-to-`v4`'s relevance/utilization regression, should be read as noisier point estimates. The fragility checks (`v5`, `tatv4`) exist precisely to quantify that noise floor rather than let it go undetected.

**Q15. Why not just set temperature to 0 from the start?**
It should have been — I identify this as the single highest-value methodological fix going forward. It wasn't caught until the fragility check, which is itself a useful finding: it demonstrates the value of stress-testing your own strongest result rather than accepting it at face value.

**Q16. Isn't comparing your generated answers against RAGBench's reference answers, rather than judging your own answers on their own merits, a flaw in the evaluation?**
It's a structural property of using an external benchmark's ground truth, and I flag it explicitly rather than treat it as free-floating error: a couple of the remaining adherence mismatches trace to the generator making a genuine arithmetic slip that the judge correctly caught — but RAGBench's ground truth reflects its own, different, correct reference response for that question. That inflates apparent disagreement without reflecting a retrieval or judge defect. It's a limitation of the evaluation setup, not evidence the pipeline is wrong.

### Future Work & Broader Implications

**Q17. If you had another two weeks of budget, what's the next experiment?**
Judge-prompt engineering targeted specifically at the scaffolding-sentence leniency issue — it's the largest remaining, well-understood, cross-domain gap, unlike the arithmetic-error mode, which isn't fixable through configuration at all.

**Q18. Would this approach generalize to other domains outside finance?**
The TatQA-versus-FinQA comparison is itself early evidence for that: the judge's scaffolding-sentence behavior and the value of judge independence both reproduced in a second, structurally different financial domain. I'd be cautious extrapolating beyond finance without testing it, but the methodology — single-variable isolation, checkpoint-verified logging, explicit noise-floor characterization — is domain-agnostic by design.

**Q19. Is this system ready for real-world/production use in financial QA?**
Not as-is, and I'd say so directly: 15-question samples are appropriate for methodology development, not production sign-off; the temperature-driven noise floor needs to be closed first; and the scaffolding-sentence judge weakness is unresolved. What this project does establish is a validated, reproducible *process* for getting a financial RAG system to a trustworthy evaluation state — the next phase would be scaling that process up, not redesigning it.

**Q20. What was the single most surprising result of the project?**
That enabling every retrieval sophistication technique simultaneously — hybrid search, fusion, MMR, re-ranking — produced no measurable benefit over a plain baseline, while a single change to *who grades the output* nearly doubled the hallucination-detection score. It reoriented the entire rest of the project away from retrieval engineering and toward evaluation integrity, which is a less intuitive but, I'd argue, more important lesson about where RAG system quality actually comes from.
