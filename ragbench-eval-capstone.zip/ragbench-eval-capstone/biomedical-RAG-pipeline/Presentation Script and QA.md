# Capstone Presentation Script — Biomedical RAG Evaluation with TRACe

**Target duration:** 12–14 minutes spoken (~2,100 words), leaving buffer inside a 15-minute slot.
**Deck:** 13 slides. Slide cues are marked `[Slide N]`.
**Delivery notes** are in italics and are *not* to be read aloud.

---

## [Slide 1] — Title

> **Title slide:** *Falsifying Our Way to a Configuration: A Controlled Evaluation of
> Retrieval-Augmented Generation in the Biomedical Domain*
> Subtitle: 40 iterations · RAGBench (PubMedQA + CovidQA) · TRACe framework

*Delivery note: deliver the opening cold, without looking at the slide. This is the hook.*

Good [morning/afternoon]. I want to begin with the single most uncomfortable result of this
project.

At the midpoint of our experiments, we believed we had found the best configuration of our
pipeline. It scored an adherence AUROC of 0.92 — the strongest number we had recorded. We had
already written it up as our headline finding.

Then we fixed a two-line bug: we had never pinned a random seed on our language-model calls. We
re-ran that exact same configuration under seed control. Its adherence was not 0.92. It was 0.56.

Nothing about the configuration had changed. What changed was that we had stopped measuring luck.

That retraction is the intellectual centre of this project, and everything I present today is
downstream of it.

---

## [Slide 2] — Domain and Motivation

> **Slide:** Why biomedical RAG evaluation? Three bullets: cost of a fluent falsehood; retrieval
> as the safety boundary; the absence of a single "accuracy" number.

Retrieval-Augmented Generation grounds a language model's output in retrieved source documents.
The biomedical domain is where that grounding matters most, for a specific reason: in most
domains an unsupported answer is an inconvenience. In clinical and biomedical settings, a fluent,
confident, *unsupported* answer is the failure mode — because it is precisely the answer a reader
is least equipped to challenge.

This creates an evaluation problem. Conventional generation metrics ask "is the answer correct?"
For biomedical RAG, that is the wrong question, or at least an incomplete one. The questions that
matter are: *Did the system retrieve the right evidence? Did it actually use that evidence? Did
it cover the evidence? And is every claim it made traceable back to a retrieved sentence?*

Those four questions are the TRACe framework, and they are what we measured.

---

## [Slide 3] — Evaluation Framework: TRACe and the Two Metrics

> **Slide:** 2×2 grid. Relevance / Utilization / Completeness → RMSE (continuous). Adherence →
> AUROC (binary). Include the formula sketches.

We evaluated against RAGBench, a benchmark whose examples carry expert-grade,
sentence-level ground-truth annotations produced by GPT-4-turbo. Our pipeline runs its own LLM
judge over the same examples, and we score our judge *against theirs*.

That framing matters, and I want to be precise about it: **we are not measuring whether our
answers are true. We are measuring whether our pipeline's assessment of its own evidence agrees
with an expert annotation of that same evidence.** This is a calibration study.

Three of the four TRACe dimensions are continuous proportions:

- **Relevance** — what fraction of retrieved context is actually pertinent to the question.
- **Utilization** — what fraction of retrieved context the response actually drew upon.
- **Completeness** — what fraction of the *relevant* content the response managed to cover.

Because these are continuous, we score them with **Root Mean Squared Error** against ground
truth. RMSE is the right choice here for two reasons. First, it is in the same units as the
score itself — an RMSE of 0.24 means our predictions sit, on average, about a quarter of the
scale away from the annotation. Second, because it squares errors before averaging, it penalises
large, systematic disagreements far more than small scattered ones. That property turned out to
be diagnostically valuable: when our RMSE degraded, it was almost always because of a *directional
bias*, not random scatter. **Lower RMSE is better.**

**Adherence** is different in kind. It is binary: is every sentence in the response fully
supported by retrieved evidence, yes or no? A single unsupported sentence fails the whole
response. For a binary label we use **AUROC** — the area under the receiver operating
characteristic curve — which measures how well our predictions *rank* hallucinated responses
apart from grounded ones. 1.0 is perfect separation; **0.5 is a coin flip**. And, as I will
return to, that 0.5 line does real work in this project — several of our configurations fell
*below* it, which is a stronger statement than mere failure. **Higher AUROC is better.**

---

## [Slide 4] — Experimental Design

> **Slide:** Fixed vs. Variable table. Highlight: judge model, judge prompt, dataset, split, and
> sample all held constant.

The methodology was a controlled, sequential falsification programme rather than a grid search.
We fixed the control group deliberately: the same judge model, the *verbatim* TRACe annotation
prompt from the original paper, the same two RAGBench domains, the same test split, the same
15 examples per domain, the same decoding parameters, the same vector store.

The variable levers were the architectural choices a practitioner actually controls: chunking
strategy, retrieval depth, embedding and reranker models, document-selection strategy, fusion
parameters, and generation prompt style.

Crucially — and this was a rule we imposed on ourselves at the outset — **no sweep order was
planned in advance.** Each next configuration was chosen only after reading the actual metric
output of the previous run. Every iteration is logged as a four-part unit: a stated hypothesis, a
prediction of what would *confirm* it, a prediction of what would *falsify* it, and the observed
result. That structure is why this project has findings and not merely a changelog.

We ran 40 such iterations across roughly 25 registered configurations.

---

## [Slide 5] — Phase 1: The Generation Bottleneck

> **Slide:** Iteration 1 → 4. Completeness 0.4437 → 0.3755. Show a terse response next to a full
> one.

Our first substantive finding came from reading the responses, not the numbers.

The baseline scored a completeness RMSE of 0.44 — by a wide margin the worst of the four metrics.
The instinct is to blame retrieval. The row-level data said otherwise: **every generated response
was one to three words long.** "Norovirus." "December 2019." "Nine."

The cause was architectural, not statistical. Our chain-of-thought prompt asked the model to
reason and then emit a final answer line — and our parser then discarded the reasoning and passed
only that final line to the judge. A three-word answer *structurally cannot* be judged as
covering much relevant context, regardless of how good the retrieval was.

We changed one variable — the generation prompt style — and completeness improved from 0.4437 to
0.3755, reproducing at two different sample sizes.

But it did not improve for free, and this is the first of three structural trade-offs we
identified. Utilization got *worse*. The mechanism is arithmetic: completeness is a **ratio**, so
when a verbose response over-credits, the inflation appears in both numerator and denominator and
partially cancels. Utilization is an **absolute fraction** against total context, so it has no
such cancellation — it absorbs the overshoot in full. Verbosity flatters the ratio metric and
penalises the absolute one. That is not a coincidence of one sample; it is a property of the
metric definitions.

---

## [Slide 6] — Phase 1: Domain Adaptation Fails, and Fails Interestingly

> **Slide:** Four-way table — v1.1 / v5 (embed) / v6 (reranker) / v3 (both). Highlight the
> non-additivity.

The next hypothesis was the obvious one for a biomedical project: replace the general-purpose
embedding and reranker with domain-adapted biomedical models — PubMedBERT and MedCPT.

Every metric regressed.

We then did what I would argue is the more instructive thing: we decomposed the failure. We ran
the embedding swap alone, and the reranker swap alone. The result was genuinely non-additive.
**Each component, applied individually, *improved* utilization** — 0.1954 and 0.1921 against a
baseline of 0.2257. **Applied together, utilization was worse than baseline.** Neither component
alone came close to reproducing the adherence collapse the pair produced.

Two individually beneficial changes combining into a net-harmful one is not something a grid
search reports. It is only visible if you run the isolation studies. Our reading is that both
domain-adapted models narrow toward the same subset of medically precise language, compounding an
over-narrow selection that neither would produce alone.

---

## [Slide 7] — The Pivot: Reproducibility

> **Slide:** Large, centred. `v14: adherence 0.9231` → strike-through → `v14b (seeded): 0.5577`.
> Below: `v18 pubmedqa slice (seeded): 0.5577`.

*Delivery note: slow down here. This is the slide the audience should remember.*

Now I return to where I began.

At iteration 17 we recorded our best result: a chunked configuration with adherence 0.9231,
winning three of four metrics outright. We proposed it as the project's answer.

While validating it across domains, we noticed our Groq API calls carried no seed. The generator
was sampling at temperature 0.2. Every number we had produced was one unpinned draw from a
distribution we had never characterised.

We added `seed=42` to both the generator and the judge, and re-ran that exact configuration.
Adherence: **0.5577**.

The confirmation is on this slide and it is exact. That seeded pubmedqa-only run and an
independent seeded run that also included CovidQA returned adherence of 0.5577 — matching **to
four decimal places.** Two things follow. First, domain scope has no effect on PubMedQA's results,
which resolved a confound we had been chasing. Second, and far more importantly: the seeded
measurement is *reproducible*, and the celebrated 0.92 was not a property of the configuration.
It was a favourable coin flip that we had been about to report as a finding.

We then re-ran the chunking sweep under seed control at two chunk sizes. **Chunking's entire
advantage disappeared.** Whole-document retrieval beat it on adherence and utilization, with
relevance and completeness statistically tied. Our headline finding of the previous week was
retracted — by our own experiment.

---

## [Slide 8] — What Survived: MMR

> **Slide:** v8b → v8c. Adherence 0.6731 → 0.9231 (+0.25). Utilization 0.2057 → 0.1211. "No
> metric regressed."

Under seed control, one lever produced a large, unambiguous, reproducible gain.

Enabling **Maximal Marginal Relevance** — diversity-aware document selection at lambda 0.5 —
improved adherence AUROC from 0.6731 to **0.9231**, a gain of 0.25, and improved utilization RMSE
from 0.2057 to 0.1211. No metric regressed. It is the only intervention in the entire project to
improve two dimensions substantially at once with no cost.

We verified this was not a small-sample artefact by hand-checking the AUROC computation against
the row-level predictions: of thirteen ground-truth-grounded responses, the configuration
correctly separated eleven from both hallucinated responses. This is genuine ranking improvement,
not a degenerate score.

The mechanism we propose: MMR reduces redundancy among the retrieved documents. Redundant context
gives a generator repeated, near-identical statements to synthesise across — and synthesis across
near-duplicates is exactly where claims drift away from any single verifiable sentence. Reduce the
redundancy, and you reduce the drift.

We also tested whether MMR's benefit compounds with chunking. It does not — adherence stayed near
0.60. Whole-document retrieval has a property that diverse chunk selection cannot replicate:
complete, self-contained context lets the generator make claims it can fully ground.

---

## [Slide 9] — What Survived: The Boundaries

> **Slide:** The lever verdict table, colour-coded. One ✓ column, one ✗ column.

The remaining twenty-odd iterations mapped the boundaries of the design space, and the pattern is
consistent: **this pipeline sits in a narrow optimum, and nearly every direction out of it is
downhill.**

Retrieval depth has a sharp two-sided optimum at five final documents. Narrowing to three was
catastrophic — every metric regressed and adherence fell to 0.3462, *below random*, meaning our
support judgements became actively anti-correlated with truth. Widening to ten also collapsed
adherence. Too few documents starve the generator into ungrounded parametric recall; too many
flood it into cross-document inference the judge cannot verify against any single sentence.

Removing the cross-encoder reranker degraded all four dimensions simultaneously. Reordering
context so the best document sits nearest the question — "repacking" — backfired, and the
diagnostic explains why: the judge marked up to seventeen of eighteen context sentences as
relevant. Placing the strongest chunk adjacent to the question made the *entire* block read as
thematically unified, and the judge stopped discriminating within it.

Context summarization deserves special mention because it failed for a reason worth stating
carefully. It compressed the judge's sentence pool from roughly twenty sentences down to one to
five. Relevance and utilization RMSE rose by 0.26 and 0.41. The hypothesis was mechanically
*correct* — a smaller pool does raise coverage — but ground truth was annotated against full
documents. We had changed what the metric measures rather than improving the system. It is a
clean example of Goodhart's law inside an evaluation harness.

---

## [Slide 10] — Results: Final Configurations

> **Slide:** The three final configuration tables, side by side.

Under full seed control, these are our defensible results.

**Best PubMedQA configuration** — relevance 0.2756, utilization 0.1211, completeness 0.2417,
adherence **0.9231**.

**Best CovidQA configuration** — relevance 0.2693, utilization 0.1028, completeness 0.4431,
adherence **0.9286**. The difference is a wider reranker candidate pool: thirty candidates rather
than twenty.

**Best cross-domain configuration** — pooled relevance 0.3206, utilization 0.1490, completeness
0.3994, adherence **0.8704**. Whole-document retrieval, MMR at lambda 0.5, twenty candidates,
five final documents, cross-encoder reranking, seeded.

Note the tension between the second and third results. CovidQA prefers thirty retrieval
candidates; PubMedQA's adherence collapses from 0.9231 to 0.5577 at that setting. We tested the
midpoint of twenty-five — PubMedQA collapses there too, to 0.5192. **The dilution threshold lies
strictly between twenty and twenty-five, and there is no integer value that serves both domains.**
The single best cross-domain configuration is therefore not the union of the domain-specific
optima; it is a genuine compromise, and we can state precisely what it costs.

---

## [Slide 11] — Inferences

> **Slide:** Four numbered inferences.

Four conclusions follow from this evidence.

**First — architectural sophistication was consistently outperformed by disciplined defaults.**
Chunking, domain-adapted biomedical models, query expansion, context summarization, and context
repacking all either regressed or proved inconclusive. The winning configuration is
whole-document retrieval with a general-purpose embedding, a general-purpose reranker, and
diversity-aware selection. The one lever that produced a large real gain — MMR — costs nothing
and adds no tokens.

**Second — every design choice we examined was a trade-off, not an improvement.** Verbosity trades
utilization for completeness. Chunking trades adherence for completeness. Diversity weighting
trades one against the other in both directions, with the default at the Pareto optimum. The
honest description of RAG optimisation in this domain is *constrained navigation of a trade-off
surface*, not a search for a dominant configuration.

**Third — one bias survived every intervention.** Our judge credits retrieved sentences as
"relevant" more liberally than RAGBench's GPT-4 annotator does. This appeared at iteration 3 and
persisted through domain-adapted retrieval, chunking, depth changes, and fusion changes. Because
it survived every retrieval-side and generation-side lever, we conclude it is a property of the
*judge*, not of the pipeline — and therefore an annotation-level ceiling that retrieval
engineering cannot lift.

**Fourth — and this is the finding I would most want to be held to — an unseeded LLM evaluation
harness can manufacture a result that looks like a discovery.** We had a configuration winning
three of four metrics, with a mechanistic explanation we found persuasive. It was a sampling
artefact. We did not catch it through scepticism; we caught it through a determinism check. In a
biomedical safety context, that distinction is not academic.

---

## [Slide 12] — Limitations and Future Work

> **Slide:** Two columns — Acknowledged Limitations / Prioritised Next Steps.

I want to state our limitations before proposing extensions, because they bound the claims.

Fifteen examples per domain is a small sample. We characterised our own noise floor empirically —
by re-running an identical configuration and measuring the drift — at roughly 0.03 to 0.08 RMSE
and 0.06 AUROC, and every comparison in this project is reported against that band. But a noise
band is a mitigation, not a substitute for statistical power.

Our adherence metric is the more serious limitation. Ground-truth adherence is heavily
class-imbalanced — as few as two or three negative examples per run — and our predicted adherence
is a strict Boolean conjunction across sentences, with no partial credit. A single misclassified
minority-class row can swing AUROC by 0.2 or more. Some of the collapses I reported are therefore
better read as *directional evidence* than as precise effect sizes, and I have tried to flag those
consistently.

Our future work follows directly:

**One — make adherence measurable.** Have the judge emit a continuous support-confidence score
rather than a Boolean, and deliberately oversample hallucinated examples. This single change would
convert our most fragile metric into our most informative one.

**Two — replace the empirical noise band with multi-seed replication.** Three to five seeds per
configuration, reporting means and variances, would let us make statistical claims rather than
threshold comparisons.

**Three — a dedicated judge-calibration study.** Our strongest unresolved observation is the
relevance over-crediting bias. Isolating it — same contexts, varying only judge model and
temperature — would determine whether it is model capacity or prompt interpretation, and would
be of value beyond this pipeline.

**Four — parent-document retrieval.** Chunking failed on chunk-boundary recall; whole documents
dilute precision. Retrieving at chunk granularity while passing the full parent document to
generator and judge targets exactly that gap, and is the one architectural idea our results
motivate but we did not have the budget to test.

**Five — diagnose CovidQA's completeness gap at the annotation level.** It sits at 0.44 against
PubMedQA's 0.24 and resisted every retrieval-side lever we tried. Our evidence says the cause is
document length driving annotation density — which makes it a data-characteristics question, not
a tuning question.

---

## [Slide 13] — Closing

> **Slide:** Single line — *"The result we could defend was smaller than the result we first
> believed. That is the finding."*

I will close where I opened.

The most valuable artefact this project produced is not the configuration on slide ten. It is the
log: forty iterations, each with a stated hypothesis, a falsification criterion recorded *before*
the run, and an honest verdict afterwards. Most of those verdicts are negative. Two of them
retract our own previous claims.

We could have reported a 0.92 and stopped. What we can defend is 0.87 pooled, with a stated noise
floor, an acknowledged metric fragility, a named annotation bias we could not remove, and a
reproducible seed.

Thank you. I welcome your questions.

---
---

# Anticipated Questions and Answers

*Organised by the line of attack. Bolded answers are the ones most likely to be asked; the
one-line "short answer" is what to lead with under time pressure.*

## A. Metrics and Statistics

**Q1. Why RMSE rather than MAE or correlation?**
Short answer: because we wanted directional bias to be visible, and units to be interpretable.
RMSE squares errors before averaging, so a systematic overshoot on several rows dominates
scattered small errors. That is precisely how we detected the judge's relevance over-crediting —
under MAE, that pattern would have been muted into the average. RMSE also stays in the units of
the score itself, so an RMSE of 0.24 is directly readable as "roughly a quarter of the scale."
Correlation would have been the wrong choice entirely: it measures whether we rank examples the
same way as the ground truth, not whether we agree with it. Two judges can correlate at 0.95
while one is systematically 0.3 too high — which is close to the failure mode we actually found.

**Q2. Why AUROC for adherence rather than accuracy or F1?**
Adherence ground truth is heavily imbalanced — typically thirteen grounded responses to two
hallucinated ones. Accuracy would be around 87% for a classifier that never predicts
"hallucinated," which is worse than useless in a safety context. AUROC is threshold-independent
and measures separation between the classes, which is the property we actually care about:
can the pipeline tell a hallucinated response from a grounded one? That said — see Q4 — AUROC has
its own severe weakness at our sample size, and I would not defend it as our best-designed metric.

**Q3. What does an AUROC below 0.5 actually mean? Isn't that just noise?**
It means our support judgements are anti-correlated with ground truth on that run — we ranked
hallucinated responses as *more* grounded than grounded ones. At n=15 with only two negative
examples, a single flipped row moves AUROC a great deal, so I would not over-interpret the
magnitude. But the *sign* is informative: several configurations landed below 0.5 and none of our
good configurations did. Where I rely on those results — for instance, top_k_final=3 — I present
them as directional evidence corroborated by the row-level diagnostics, which showed the sentence
pool physically shrinking, not as precise effect sizes.

**Q4. n=15 per domain is very small. How can any of this be significant?**
It is small, and I would not claim statistical significance in the formal sense — we did not run
significance tests, and with fifteen examples we would be underpowered for most effects we
observed. What we did instead is characterise our own noise floor empirically: we re-ran an
identical configuration and measured the drift, giving roughly 0.03–0.08 RMSE and 0.06 AUROC.
Every comparison in the project is reported against that band, and I have been explicit about
which differences exceed it and which do not. The effects I present as real — MMR's 0.25 AUROC
gain, top_k_final=3's collapse — are three to eight times the noise band. The effects within the
band I report as inconclusive, including one hypothesis I would have liked to confirm. The
principled fix is multi-seed replication with variance reporting, which is my second future-work
priority.

**Q5. Your noise band came from a single repeat run. Isn't that itself a sample of one?**
Yes, and that is a fair criticism. A single re-run gives a point estimate of variability with no
confidence interval of its own. It was the best we could afford under a token budget, and I would
characterise it as a working heuristic rather than a measured standard deviation. Multi-seed
replication would replace it properly. I would note that the band's usefulness was mostly in
rejecting weak claims rather than accepting strong ones — it made us *more* conservative, not
less.

**Q6. Why not use standard RAG metrics — RAGAS, faithfulness, answer relevancy?**
Those metrics are reference-free: they use an LLM to score outputs with no ground truth to check
the LLM against. That is convenient but it makes the judge unfalsifiable. RAGBench's value is that
it ships sentence-level expert annotations, which let us score *our judge against theirs* and
therefore detect judge miscalibration — which turned out to be one of our persistent findings. A
RAGAS-based setup would have shown us a confident faithfulness score and given us no way to
discover that our judge over-credits relevance.

## B. Methodology and Experimental Design

**Q7. Why sequential hypothesis testing instead of a grid search or Bayesian optimisation?**
Three reasons. First, budget — we were on free-tier inference and hit a tokens-per-day ceiling
more than once; a full grid over our lever space was not affordable. Second, and more
substantively, a grid search returns an argmax, not an explanation. Our most interesting results —
the non-additive interaction between the domain-adapted embedding and reranker, and the
seed confound — are only visible through isolation studies that a grid would report as single
cells. Third, honestly: a grid search under an unpinned seed would have produced a
confidently-reported best cell that was pure noise. Our sequential design is what surfaced the
problem.

**Q8. Doesn't choosing each configuration after seeing the last result risk overfitting to your
test set?**
That is the correct concern to raise, and yes — with forty iterations against a fixed 30-example
set, our final configuration is selected on the same data we report it on. There is no held-out
split. I would defend the design as appropriate for a mechanism-finding study and inappropriate
for a performance claim, and I have tried to phrase the conclusions accordingly: I claim MMR helps
*for a stated reason*, not that 0.8704 is an unbiased estimate of out-of-sample performance.
Proper validation would require a fresh RAGBench sample scored once, at the end, against the
frozen configuration. That is a genuine gap.

**Q9. You changed the sample size mid-project and later restricted to one domain. Doesn't that
break comparability?**
Both changes were deliberate and both were handled by re-running the comparator. When we moved
from five to fifteen examples, we re-ran the baseline at the new size rather than comparing across
sizes. When we restricted to PubMedQA for budget reasons, we ran the identical configuration under
both scopes and confirmed — to four decimal places on adherence — that domain scope had no effect
on PubMedQA's results, because each domain's corpus and index are built independently. Where a
comparison *was* confounded, as at iteration 21, I have flagged it as confounded and run the
isolating configuration rather than drawing the conclusion.

**Q10. Why did you fix the judge prompt and judge model? Isn't the judge the most suspicious
component?**
It is, and that is exactly why we fixed it. The judge prompt is the RAGBench paper's verbatim
annotation prompt; changing it would mean our scores were no longer comparable to the benchmark's
ground truth, which is the only external reference we have. Holding it constant is what makes the
relevance over-crediting *detectable* as a stable bias rather than a moving target. The cost is
that we could not fix the bias — only characterise it. Studying it properly requires varying the
judge deliberately as its own experiment, which is my third future-work item.

**Q11. How do you know the seed fix actually works, given the results got worse?**
This is an important distinction and we corrected our own framing on it mid-analysis. The seed's
purpose is not to reproduce the earlier, unseeded numbers — those were never pinned to any
particular draw, so there is nothing to reproduce. Its purpose is that running the same
configuration again returns the same result. The evidence that it works is the exact four-decimal
adherence match between two independently-launched seeded runs of the same configuration. The
result being worse is not a failure of the fix; it is the fix revealing that the earlier number
was a favourable draw.

**Q12. Groq documents `seed` as best-effort, not a guarantee. Doesn't that undermine the whole
thing?**
It qualifies it, and I found direct evidence of that. In one cross-domain run, seeded PubMedQA
rows were not byte-identical to the single-domain run — we traced it to the cross-encoder's
floating-point batching order varying with what else is in the session. That residual
nondeterminism is much smaller than the temperature-driven variance we eliminated: the diffs sat
at or just outside our noise band, versus adherence swings of 0.37 before the fix. So the correct
statement is that seeding removed the dominant source of variance, not all of it. Full determinism
would need fixed batch ordering and deterministic kernels as well.

## C. Findings and Their Interpretation

**Q13. Why did domain-adapted biomedical models — PubMedBERT and MedCPT — fail? That is
counter-intuitive.**
It surprised us too, and I would offer the explanation as a hypothesis rather than a
demonstrated cause. Our reading is that RAGBench's task is not pure biomedical literature
retrieval — it is question-to-passage matching, where the query is a natural-language question and
the target is a passage. The general-purpose models were trained on exactly that objective;
ms-marco in particular is a passage-ranking model. PubMedBERT is trained on biomedical *language*,
which is a different competence from biomedical question-passage *matching*. The isolation study
supports this indirectly: each component individually improved utilization, so neither is
incompetent — the damage appeared only in combination, consistent with both narrowing toward the
same technical-language subspace. A proper test would be an ablation on query type.

**Q14. You claim MMR is the single most impactful lever. How confident are you, given everything
you have said about sample size?**
It is our strongest claim and I would defend it on four grounds. The effect size is 0.25 AUROC —
roughly four times our noise band. It is seed-controlled on both sides of the comparison. It
improved two metrics with no regression on any, which no other lever achieved. And we verified the
AUROC by hand against the row-level predictions: eleven of thirteen grounded responses correctly
separated from both hallucinated ones, so it is a genuine ranking improvement rather than a
degenerate score. What I would *not* claim is the effect size's precision — I would expect the
true value to move under replication. The direction I am confident in.

**Q15. Is your mechanistic explanation for MMR testable, or is it a story fitted after the fact?**
Fair challenge — it is currently post-hoc. The claim is that reducing redundancy among retrieved
documents reduces cross-document synthesis, which is where ungrounded claims arise. It is testable
and I would test it by measuring pairwise similarity within the retrieved set and correlating that
directly against per-row adherence. If the mechanism is right, high intra-set redundancy should
predict adherence failures independently of whether MMR produced the set. We did not run that
analysis, and I would rank it above further configuration search.

**Q16. You retracted chunking after previously reporting it as your best result. Which conclusion
should we believe?**
The seeded one, and for a stated reason: the chunking sweep that appeared to succeed was never
seed-controlled on either side, so the apparent benefit was built on comparing one arbitrary draw
against another. Under seed control we tested two chunk sizes, with and without diversity
selection, and chunking never recovered an adherence advantage over whole-document retrieval. I
would characterise the current position as *falsified as a net improvement under our conditions* —
specifically, at fifteen examples, with these two domains, at these chunk sizes. I would not
generalise it to "chunking does not work."

**Q17. Chunking is standard practice in production RAG. Doesn't your result contradict the
field?**
Not really, and the difference is instructive. Chunking's primary justification in production is
that documents exceed the context window. RAGBench's documents do not — CovidQA averages under six
hundred characters. So we removed chunking's main benefit while keeping its main cost, which is
chunk-boundary recall loss: the supporting sentence for a claim ends up in a chunk that was not
retrieved, and the judge correctly cannot verify it. We observed exactly that failure signature —
new false negatives on responses that had been correctly judged supported. My reading is that our
result is consistent with the field's practice, correctly scoped: chunking is a context-window
mitigation, not an accuracy improvement, and applying it where the constraint does not bind incurs
the cost without the benefit.

**Q18. What is the relevance over-crediting bias, and how do you know it is the judge?**
Our judge marks a larger fraction of retrieved sentences "relevant" than RAGBench's GPT-4
annotator did — for instance, 0.75 predicted against 0.412 ground truth, repeatedly, in the same
direction. We attribute it to the judge by elimination: it survived a full retrieval-model swap,
chunking at three sizes, retrieval-depth changes in both directions, fusion-parameter changes, and
generation-prompt changes. If retrieval precision drove it, domain-adapted retrieval should have
tightened the gap; it did not move. The residual explanations are judge model capacity — we used
an open 70-billion-parameter model against RAGBench's GPT-4-turbo — or the prompt's relevance
criteria being interpreted more inclusively by a smaller model. Distinguishing those two requires
varying the judge, which we deliberately did not do mid-project.

**Q19. Could you have simply used a stronger judge model?**
Almost certainly it would have changed the numbers, and we could not afford it — we were on free
tier and had already exhausted a daily token quota on one configuration. But I would push back
gently on the framing: swapping to a stronger judge would have *improved* our agreement scores
without telling us anything about why the weaker judge disagreed. Holding the judge fixed is what
converted the bias from an error into an observation. The right experiment is a judge ladder —
the same contexts scored by progressively stronger judges — measuring how agreement with GPT-4
annotations scales with judge capacity. That is a more interesting question than our score.

**Q20. Why is CovidQA's completeness so much worse than PubMedQA's, and why couldn't you fix it?**
CovidQA has longer documents, which means more sentences per retrieved document, which means the
judge identifies a larger relevant set — while the generated answer is roughly the same length
either way. Completeness is coverage of that relevant set, so a larger denominator mechanically
depresses it. We tested the implied fix directly: shrinking chunks to 300 characters *did* improve
completeness monotonically, from 0.52 to 0.48 to 0.40 — the hypothesis was correct. But adherence
collapsed to 0.39 through chunk-boundary recall loss. So the trade-off is structural rather than a
tuning failure: within this pipeline's constraints, every lever that shrinks the relevant set also
breaks the evidence chain the judge needs. Fixing it properly means either a completeness-oriented
generation prompt — which was out of scope, as our prompts were fixed — or parent-document
retrieval.

**Q21. Context summarization gave you a perfect adherence of 1.0 on CovidQA. Why discard it?**
Because the other three metrics regressed catastrophically — relevance and utilization RMSE rose
by 0.26 and 0.41 — and the reason exposes why the 1.0 is not meaningful. Summarization shrank the
judge's sentence pool from around twenty sentences to between one and five. With a pool that
small, nearly every sentence is labelled relevant and utilized, so those predictions push toward
1.0 while ground truth, computed on the full documents, sits near 0.3. The adherence of 1.0 is the
same artefact viewed favourably: with almost nothing to contradict, nothing gets contradicted. We
changed what the metric measures rather than improving the system — Goodhart's law inside the
evaluation harness. I report it as a curiosity and a cautionary case, not a result.

**Q22. You found that the optimal retrieval depth differs by domain and no midpoint works. Isn't
that just an artefact of two small samples?**
It might be, and I would not claim the exact threshold. But the pattern has structure that noise
would not easily produce: CovidQA improves smoothly and monotonically from twenty to twenty-five
to thirty candidates, while PubMedQA's adherence collapses to roughly 0.52 at twenty-five and 0.56
at thirty from a baseline of 0.92 — a step change, not a drift. The proposed mechanism is
consistent with the document characteristics: CovidQA's longer, richer documents give the
reranker genuinely better candidates in a deeper pool, while PubMedQA's short, topically tight
documents mean a deeper pool contributes mostly dilution. What I would defend is the qualitative
claim — that retrieval depth is not a universal lever — and I would want replication before
stating a threshold.

## D. Scope, Alternatives, and "What Would You Do Differently"

**Q23. What would you do differently if you started over?**
Pin the seed on day one. That single omission cost us roughly half the project's iterations in
retrospective uncertainty and forced two retractions. Second, I would hold out a validation split
from the beginning so that the final configuration could be scored once on unseen data. Third, I
would have addressed the adherence metric's class imbalance early — by having the judge emit a
continuous score — rather than logging it as an open limitation and working around it for thirty
iterations. All three are process decisions, not modelling decisions, which I think is itself the
lesson.

**Q24. Is any of this generalisable beyond RAGBench and these two domains?**
The specific numbers are not, and I would not present them as such. Three things I would tentatively
generalise. The trade-off structure — verbosity against utilization, chunking against adherence,
diversity against relevance — follows from the metric definitions rather than from the data, so it
should recur anywhere TRACe is used. The reproducibility finding is domain-independent and applies
to any LLM-judged evaluation. And the pattern that general-purpose retrieval components beat
domain-adapted ones on question-passage matching is worth testing elsewhere, though I would treat
it as a hypothesis rather than a result.

**Q25. Your best cross-domain adherence is 0.87. Is that good enough for real biomedical use?**
No, and I would want to be unambiguous about that. 0.87 AUROC means a meaningful fraction of
hallucinated responses are ranked as grounded. In a clinical decision-support context that is not
an acceptable operating point, and our sample size means the true value could be materially lower.
What this pipeline is suitable for is exactly what we used it for: comparative evaluation of
design choices under controlled conditions. Deploying it would require the continuous adherence
score, a much larger evaluation set, a stronger judge, and human expert review of the negative
cases — and even then I would position it as a triage aid rather than an authority.

**Q26. What was the single hardest technical problem?**
Distinguishing real effects from noise without the budget to replicate. Almost every methodological
decision in the second half of the project — the empirical noise band, the row-level minority-class
checks, the insistence on isolating one variable per run, and eventually the seed fix — exists to
address that one constraint. The seed confound is the clearest instance: it was invisible at the
level of summary metrics and only became provable when we ran the same configuration twice and
compared four decimal places.

**Q27. You mention a bug in the context-repacking experiment. How do we know other results are not
similarly affected?**
We cannot rule it out, and I would rather say so than overclaim. What I can describe is how that
one was caught: repacking reordered documents for the generator's prompt but not for the judge's,
so the two disagreed about which document "[Doc 2]" referred to, producing mass false-negative
adherence. We caught it because the failure pattern was implausible — a uniform collapse rather
than a graded one — which is a habit worth naming: implausibly clean failures are usually bugs,
not findings. We fixed it, re-registered under a new configuration name specifically so the cached
buggy rows would not be silently reused, and re-ran. The valid result also falsified the
hypothesis, but for a different and more interesting reason.

**Q28. Forty iterations and your final recommendation is close to the defaults. Was the effort
justified?**
I would argue the effort produced exactly the right kind of result. We can now say *which* defaults
matter and why — that MMR is worth 0.25 AUROC, that five final documents is a two-sided optimum
with sharp cliffs on both sides, that the cross-encoder is load-bearing rather than incidental —
and we can say which sophisticated additions cost tokens for nothing. A practitioner reading this
log saves the twelve experiments that do not work. Negative results are less satisfying to present
than a headline number, but for a study whose purpose was understanding rather than leaderboard
position, I would rather deliver a defensible small result than an indefensible large one.
