# Observations and Inference

Running log of decisions, observations, and inferences for the RAG pipeline built in
`rag-pipeline-v2/`. Updated after every iteration so the final narrative can be collated
directly from this file for the capstone presentation.

---

## Project Setup

**Datasets**: RAGBench (`galileo-ai/ragbench`) — `covidqa` + `pubmedqa` domains, test split.
**Compute**: Groq free tier (generator + judge LLMs), Google Colab free tier (execution).
**Deadline**: working pipeline demoed on a data subset within 5 days of project start
(started 2026-07-06).

**Evaluation framework**: TRACe (Relevance, Utilization, Completeness, Adherence).
- Relevance, Utilization, Completeness → scored via RMSE against RAGBench's own ground-truth
  annotations.
- Adherence → scored via AUCROC.

**End goal**: identify which pipeline configuration performs best, and understand *why*,
well enough to generalize the reasoning across dataset domains — not just report numbers.

---

## Fixed vs. Variable Parameters (locked 2026-07-06)

**Fixed for every iteration** (the control group, so comparisons stay clean):
| Parameter | Value |
|---|---|
| Judge LLM Model | TBD — one Groq model, same across all runs |
| Judge Prompt Template | RAGBench/TRACe paper's verbatim annotation prompt |
| Dataset domains & split | covidqa + pubmedqa, test split |
| Max Samples per Domain | small fixed n (10–15/domain), same across all runs |
| Random Seed | fixed |
| Decoding params | fixed, low temperature |
| Vector DB | LanceDB (disk-persisted) |

**Variable — the levers available to change** (chunking, top-k, embedding/reranker model,
generator model, prompt style). **No fixed sweep order.** Each next configuration is decided
only after reading the actual TRACe scores / RMSE / AUCROC from the most recent run — not
planned in advance. See Iteration Log below: only the immediate next iteration should ever be
specified in detail; anything past that is a placeholder until evidence justifies it.

**Every "Decision for next config" entry must also record the intuition/hypothesis behind it** —
not just what changed, but *why* that change is expected to move the specific metric(s) it's
targeting, and what result would confirm vs. falsify the hypothesis. This is what turns the log
into a reasoned narrative (config → observed failure → hypothesis → test → result) rather than a
changelog, and it's the material the capstone presentation should draw from directly.

---

## Iteration Log

### Iteration 0 — Skeleton / correctness check
- **Status**: DONE (2026-07-08)
- **Goal**: prove the full loop (retriever → generator → judge → TRACe metrics → RMSE/AUCROC)
  executes correctly end-to-end on a tiny sample (3–5/domain). No config optimization yet.
- **Observations**: ran cleanly end-to-end in Colab (browser — VS Code's local IDE was too slow to
  run this in); no crashes, no skipped rows (10/10 completed, 5/domain); the free ground-truth
  metric-formula validation cell (§9.1) was not reported back yet, so formula correctness itself
  is not re-confirmed for this notebook (it was validated in v1's near-identical implementation,
  and the code was ported unchanged — but worth pasting that cell's output too on the next run).
- **Inference**: pipeline is mechanically sound at this sample size; safe to treat this run's
  numbers as real signal, not just a smoke test.
- **Decision for next config**: none needed — proceeded directly into Iteration 1 at the same
  sample size.

### Iteration 1 — Baseline (`"baseline"` config, no chunking)
- **Status**: DONE (2026-07-08)
- **Config**: `CONFIG_REGISTRY["baseline"]` — bare `Config()` defaults. generator=judge=
  `llama-3.3-70b-versatile`, embed=`BAAI/bge-small-en-v1.5`, reranker=
  `cross-encoder/ms-marco-MiniLM-L-6-v2`, `generation_prompt_style="long_cot"`,
  `chunking_strategy="none"` (whole-document retrieval), `top_k_retrieve=20`/`top_k_final=5`,
  hybrid search + MMR + reranker all on, `max_samples_per_domain=5` (n=10 total).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 5 | 0.0972 | 0.1095 | 0.4081 | 0.875 |
  | pubmedqa | 5 | 0.2354 | 0.2580 | 0.4767 | 0.75 |
  | ALL | 10 | 0.1801 | 0.1982 | 0.4437 | 0.8125 |

  Row-level (`results_df`, covidqa, n=5):

  | question | response | pred_completeness | gt_completeness | pred_adherence | gt_adherence |
  |---|---|---|---|---|---|
  | Which viruses may not cause prolonged inflammation... | "Norovirus" | 0.0 | 0.4286 | 0.0 | 0.0 |
  | When was the first case of COVID-19 identified? | "December 2019" | 0.0909 | 0.2857 | 1.0 | 1.0 |
  | How many antigens... Liew's multiplex ELISA test? | "9" | 1.0 | 0.5 | 1.0 | 1.0 |
  | What is the structure of Hantaan virus? | (full descriptive sentence) | 0.5 | 1.0 | 1.0 | 1.0 |
  | How many people did SARS-CoV infect? | "8096-8098" | 0.6667 | 1.0 | 0.0 | 0.0 |

- **Observations**:
  1. **Relevance and utilization RMSE are already strong** (pooled 0.18 / 0.198) — notably better
     than v1's own `v1_baseline` run on the same whole-document/no-chunking architecture
     (v1_baseline: relevance 0.3947, utilization 0.1522, n=20). Retrieval-side quality is not the
     bottleneck here.
  2. **Completeness RMSE is by far the worst metric** (pooled 0.4437) — consistent with v1's
     finding that completeness is the hardest metric across the whole project, but the *cause*
     looks different here: v1 attributed completeness/adherence problems to chunk-boundary recall
     (chunking splits a doc's sentences across retrieval units). This run has **no chunking at
     all** (`chunking_strategy="none"`) and still shows the same completeness weakness — so
     chunk-boundary recall cannot be the explanation this time.
  3. **Every generated response is extremely terse** — single words/numbers ("Norovirus",
     "December 2019", "9", "8096-8098") except one. `generation_prompt_style="long_cot"` asks the
     model to reason step-by-step and then emit a `"Final Answer: <answer>"` line; the notebook's
     `generate_response()` regex-parses out *only* that trailing line and discards the reasoning
     that preceded it before the response is ever shown to the Judge. Completeness measures how
     much of the *relevant* context is reflected in the response — a 1-3 word answer structurally
     caps how much relevant content it can be judged as utilizing, regardless of retrieval quality.
  4. **The Hantaan virus question — a config-invariant failure case in every one of v1's chunked
     runs (pred_adherence=0.0 vs gt=1.0, every time)** — is CORRECT here (pred_adherence=1.0=gt).
     This is the one case that got a full, non-terse descriptive answer. Consistent with (3): once
     the response actually states supporting facts, both completeness and adherence look much
     healthier for that row (pred_completeness 0.5 here, the best non-1.0 value in the sample).
  5. Adherence AUCROC (0.8125 pooled) is already close to v1_baseline's 0.8235 and doesn't look
     broken — the two adherence misses (SARS-CoV row, Norovirus row) both have `gt_adherence=0.0`
     too, i.e. the judge correctly flagged genuinely unsupported/hallucinated terse answers, not a
     judge-quality problem.
- **Inference**: the completeness bottleneck in this run looks like a **generation-prompt/parsing
  artifact, not a retrieval or chunking problem** — the CoT reasoning the model actually produces
  is being thrown away before judging, leaving only a terse final answer that mechanically
  underuses the relevant retrieved context. This is a different root cause than v1 diagnosed for
  the same metric, and it's specific to the `"long_cot"` + `"Final Answer:"`-parsing combination.
- **Decision for next config**: CONFIRMED with user (2026-07-08) — proceeding to Iteration 2.
  - **Hypothesis**: completeness (and secondarily utilization) is being suppressed by an artifact
    of `generation_prompt_style="long_cot"` — the model's CoT reasoning likely *does* engage with
    relevant retrieved sentences, but `generate_response()`'s `"Final Answer:"` regex discards that
    reasoning and keeps only the terse trailing line, so the Judge only ever sees a 1-3 word
    answer. If true, the bottleneck is a generation/parsing choice, not retrieval quality or
    chunking — retrieval-side metrics (relevance) are already strong, so there's no reason to
    suspect the retriever first.
  - **Proposed test**: swap `generation_prompt_style` to `"long"` — same context/instructions, no
    CoT request, no trailing-answer parsing, so the full generated response is what the Judge
    sees.
  - **What would confirm it**: completeness RMSE (and likely utilization RMSE) drop substantially
    pooled, with relevance RMSE roughly unchanged (retrieval didn't change) and adherence not
    collapsing (a longer response isn't just restating unsupported claims).
  - **What would falsify it**: completeness RMSE stays similarly bad even with a full, un-parsed
    response — would point back toward a retrieval/context-relevance explanation instead (e.g. the
    right supporting sentences genuinely aren't being retrieved, not just discarded post-hoc).
  - **Registered as** `"v1"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell): `{"generation_prompt_style": "long"}`, all other fields inherited from `baseline`.
    `ACTIVE_CONFIG_NAME` set to `"v1"`.

### Iteration 2 — `"v1"` config (generation_prompt_style: long_cot → long)
- **Status**: DONE (2026-07-08)
- **Config**: `CONFIG_REGISTRY["v1"]` = baseline + `generation_prompt_style="long"` only. Everything
  else identical to baseline (whole-document retrieval, top_k_retrieve=20/top_k_final=5, hybrid
  search + MMR + reranker on, max_samples_per_domain=5, same generator/judge/embed/reranker
  models).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 5 | 0.1226 | 0.0368 | 0.4187 | 1.0 |
  | pubmedqa | 5 | 0.2720 | 0.1253 | 0.1818 | 0.375 |
  | ALL | 10 | 0.2109 | 0.0924 | 0.3227 | 0.6875 |

  vs. Iteration 1 (`baseline`) pooled: relevance 0.1801, utilization 0.1982, completeness 0.4437,
  adherence 0.8125.

  Row-level (`results_df`, pubmedqa, n=5) — the two adherence mismatches:

  | question | pred_adherence | gt_adherence | note |
  |---|---|---|---|
  | nitinol stents / prosthetic covering | 1.0 | 0.0 | Judge too lenient — false positive |
  | contact lens care / economic-social factors | 0.0 | 1.0 | Judge too strict — false negative (relevance/utilization/completeness all matched gt exactly on this row) |

- **Observations**:
  1. **Completeness improved substantially pooled** (0.4437 → 0.3227) and **utilization improved a
     lot** (0.1982 → 0.0924) — consistent with the Iteration 1 hypothesis: removing CoT stripping
     so the Judge sees the full response, not a terse final line, does increase how much relevant
     context shows up as "utilized."
  2. **Relevance got slightly worse** (0.1801 → 0.2109) — a secondary, smaller effect, not yet
     explained; retrieval itself didn't change between these two configs, so this is likely judge
     variance rather than a retrieval-side effect.
  3. **Adherence AUCROC regressed hard pooled** (0.8125 → 0.6875), but this is entirely a
     **pubmedqa-specific collapse** (covidqa actually improved to a perfect 1.0). Root cause
     identified at the row level: exactly 2 of pubmedqa's 5 rows have a pred/gt adherence
     mismatch, and they point in **opposite directions** (one false positive, one false negative)
     — not a consistent lenient-or-strict bias in one direction.
  4. The false-negative row (contact lens question) has **exact** relevance/utilization/
     completeness agreement with ground truth (0.1428 = 0.1428) — the disagreement is isolated
     to the adherence dimension specifically, on a response that reads as reasonably hedged and
     properly cites Doc 1.
- **Inference**: `compute_trace_metrics` defines adherence as `all(fully_supported for every
  response sentence)` — a single AND across every sentence in the response. `"long"`-style
  responses are longer and contain more transition/hedge/inferential sentences ("this suggests...",
  "may not be generalizable..."), which gives the Judge more individual sentence-support calls to
  make per example. Any single miscall on an ambiguous hedge sentence flips that example's overall
  adherence — in either direction, which matches the mixed-direction mismatch seen here. Combined
  with n=5 giving adherence AUCROC almost no statistical resolution (5 binary labels — the user's
  own observation), this reads as **noise amplified by response length interacting with a strict
  conjunctive formula**, not solid evidence that `"long"` style genuinely hurts groundedness. The
  completeness/utilization improvement, by contrast, is large and consistent across both domains,
  so that part of the hypothesis holds up better than the adherence result at this sample size.
- **Decision for next config**: CONFIRMED with user (2026-07-08) — before drawing any conclusion
  on `"long"` vs `"long_cot"`, resolve whether the adherence regression is real or n=5 noise.
  - **Hypothesis**: the adherence swing is a small-sample artifact, not a genuine effect of the
    prompt style change — at n=5/domain, a single sentence-level judge miscall can flip an entire
    example's binary adherence label, which is enough to swing AUCROC by 0.3+ pooled.
  - **Proposed test**: raise `max_samples_per_domain` from 5 to 15 (applied to the shared `Config`
    default, so it affects every registered config, past and future) and re-run **both**
    `baseline` and `v1` at the new n, so they remain a fair comparison at the larger sample size.
    Registered as a new named config `"v1.1"` — same overrides as `"v1"`
    (`generation_prompt_style="long"`), differing from `"v1"` only in inheriting the new
    `max_samples_per_domain=15` default. `"baseline"` will also be re-run at n=15 for comparison
    (either by re-registering it under a new name, or accepting that the shared default change
    means baseline needs a fresh named entry too — to be decided when we get there).
  - **What would confirm it**: at n=15, adherence AUCROC for both configs stabilizes closer to
    each other (no longer a 0.3+ pooled gap), and/or the specific sentence-level disagreements
    become rarer/more consistent in direction.
  - **What would falsify it**: the adherence gap between `long_cot` and `long` persists or widens
    at n=15 — would mean the regression is real and specific to the longer prompt style, not
    sampling noise.

### Iteration 3 — `"baseline_n15"` config (baseline re-run at n=15/domain)
- **Status**: DONE (2026-07-08)
- **Config**: `CONFIG_REGISTRY["baseline_n15"]` = `baseline` + `max_samples_per_domain=15` only
  (30 total rows). All other fields identical to `baseline`
  (`generation_prompt_style="long_cot"`, `chunking_strategy="none"`, top_k_retrieve=20/
  top_k_final=5, hybrid+MMR+reranker on). Registered as a new named entry, not an edit to
  `baseline` — `baseline`'s own n=5 results (Iteration 1) remain unchanged and separately logged.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3375 | 0.0920 | 0.4816 | 0.4286 |
  | pubmedqa | 15 | 0.2757 | 0.2348 | 0.5076 | 0.5192 |
  | ALL | 30 | 0.3081 | 0.1783 | 0.4948 | 0.5185 |

  vs. `baseline` (n=5) pooled: relevance 0.1801, utilization 0.1982, completeness 0.4437,
  adherence 0.8125.

- **Observations**:
  1. **Adherence AUCROC collapsed to near-random** (0.8125 → 0.5185) at the larger sample size.
     Root cause traced to extreme class imbalance in ground truth: only **3 of 30 rows** have
     `gt_adherence=0` (rows 0, 16, 24); everything else is `1`. AUCROC ranks those 3 rare
     negative-class rows against all others, so it is dominated by how well just those 3 are
     classified. **2 of the 3** were misclassified in this run (predicted `1.0`/not-hallucinated
     when ground truth said `0`/hallucinated). Because `compute_trace_metrics` returns adherence
     as a strict boolean (`all(fully_supported for every sentence)`), not a continuous confidence
     score, there is no partial credit or fine ranking to cushion misses on the minority class —
     a couple of wrong calls swing AUCROC by 0.2–0.3+.
  2. This means the earlier `baseline` (n=5) adherence read of 0.8125, and `v1`'s 0.6875, were
     both likely **inflated/deflated by small-sample luck** rather than being stable estimates —
     the n=5 sample happened to include negative-class rows that classified correctly.
  3. **Relevance RMSE got substantially worse** (0.1801 → 0.3081) and the *direction* is
     consistent, not random: several rows show `pred_relevance` far exceeding `gt_relevance`
     (e.g. "focus of the study" question: pred 1.0 vs gt 0.294; "first case of COVID-19": pred
     0.917 vs gt 0.269; IL-27/HCV question: pred 1.0 vs gt 0.533). Our Judge appears to mark
     retrieved sentences "relevant" more liberally than RAGBench's original GPT-4 annotator did —
     a systematic overshoot pattern, not scattered noise, and it only became visible/dominant at
     the larger sample size.
  4. Utilization and completeness stayed roughly stable pooled (0.198→0.178, 0.444→0.495) —
     neither improved nor collapsed the way adherence did, suggesting those two metrics are less
     sensitive to sample size at this range (likely because their ground-truth values are more
     continuously distributed than adherence's near-binary/imbalanced one).
- **Inference**: two separate, real findings, not one:
  - **(a) Methodology limitation, not a config effect**: adherence AUCROC is currently unreliable
    as a comparison metric between configs at this sample size, because of ground-truth class
    imbalance combined with a boolean (not continuous) predicted adherence score. Any adherence
    AUCROC comparison between configs going forward should be read cautiously until this is
    addressed (e.g. a continuous Judge confidence score, or deliberately oversampling negative-
    class examples) — logged as an open item, not fixed reactively under time pressure.
  - **(b) Possible real effect worth investigating**: the Judge's relevance annotations look
    systematically more liberal than RAGBench's own ground truth — this is a directional,
    repeatable pattern (not random noise) and is a stronger candidate for a genuine finding than
    the adherence swing.
- **Decision for next config**: CONFIRMED with user (2026-07-08) — proceed to run `"v1.1"`
  (already registered, `generation_prompt_style="long"` + `max_samples_per_domain=15`) as
  planned, and compare it against `baseline_n15` (not the old n=5 `baseline`/`v1` numbers) so the
  comparison is apples-to-apples at the same, more reliable sample size. The adherence AUCROC
  comparison between the two will be read with the class-imbalance caveat above in mind; the
  completeness/utilization/relevance comparisons are not affected by that specific limitation and
  can be trusted more directly.
  - **Hypothesis carried over from Iteration 2**: `"long"` should still show better completeness/
    utilization than `"long_cot"` at n=15, consistent with what was seen at n=5 (Iteration 2's
    finding wasn't in question — only the adherence read was).
  - **What would confirm it**: `v1.1`'s completeness/utilization RMSE are meaningfully lower than
    `baseline_n15`'s (0.4948 / 0.1783), similar in direction/magnitude to the n=5 gap.
  - **What would falsify it**: `v1.1`'s completeness/utilization are similar to or worse than
    `baseline_n15`'s — would mean the earlier n=5 improvement was itself a small-sample artifact.

### Iteration 4 — `"v1.1"` config (generation_prompt_style="long", n=15/domain)
- **Status**: DONE (2026-07-08)
- **Config**: `CONFIG_REGISTRY["v1.1"]` = baseline + `generation_prompt_style="long"` +
  `max_samples_per_domain=15`. Same underlying 30 sampled questions as `baseline_n15` (same domains,
  same row order), so this is a true apples-to-apples comparison against Iteration 3.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3227 | 0.2209 | 0.4726 | 0.9643 |
  | pubmedqa | 15 | 0.2747 | 0.2304 | 0.2421 | 0.6731 |
  | ALL | 30 | 0.2997 | 0.2257 | 0.3755 | 0.7778 |

  vs. `baseline_n15` (Iteration 3) pooled: relevance 0.3081, utilization 0.1783, completeness
  0.4948, adherence 0.5185.

- **Observations**:
  1. **Completeness improved again, consistently with Iteration 2's n=5 result** (0.4948 →
     0.3755) — the largest, most consistent effect across both sample sizes so far.
  2. **Utilization got WORSE this time** (0.1783 → 0.2257) — the opposite direction from the n=5
     result, where utilization also improved alongside completeness. Row-level inspection shows
     `pred_utilization` now frequently overshoots `gt_utilization` by a large margin (e.g. phage
     display question: pred 0.95 vs gt 0.158; elderly-fluids question: pred 1.0 vs gt 0.462;
     IL-27/HCV question: pred 1.0 vs gt 0.533).
  3. **Relevance essentially unchanged** (0.3081 → 0.2997) — small movement, no clear direction.
  4. **Adherence AUCROC "improved"** (0.5185 → 0.7778), but checking the same 3 minority-class
     rows flagged in Iteration 3 (`gt_adherence=0`: rows 0, 16, 24 — identical underlying
     questions/order to `baseline_n15`): `baseline_n15` got 1/3 of these correct, `v1.1` gets
     **2/3 correct** (row 16, nitinol stents, is still misclassified in both). One row flipping
     from wrong to right is fully sufficient to explain the entire 0.26 AUCROC swing — this is the
     exact fragility mechanism flagged as an open methodology limitation in Iteration 3, not new
     evidence that `"long"` is more grounded.
- **Inference**: the hypothesis carried over from Iteration 2 is **partially confirmed, partially
  falsified** — not a clean win. Completeness's improvement is real and consistent (same
  direction, similar magnitude, at two different sample sizes) and is the strongest finding of
  this whole comparison. But utilization's earlier improvement does NOT hold at n=15; instead
  there's a genuine **structural tradeoff**: completeness is a ratio (utilized∩relevant /
  relevant), so a verbose response's utilization overshoot partly cancels out in both numerator
  and denominator, leaving completeness looking good. Utilization itself is an absolute fraction
  against total context sentences, so it has no such cancellation — it directly and fully
  reflects any overshoot. In short: **`"long"`-style verbosity helps the ratio-based completeness
  metric while directly hurting the absolute-fraction utilization metric** — a real mechanism,
  not a coincidence of one sample. Adherence AUCROC cannot yet be used to distinguish these two
  configs — the confirmed-vs-falsified test here is inconclusive on adherence specifically,
  exactly per the open methodology-limitation flag from Iteration 3.
- **Decision for next config**: CONFIRMED with user (2026-07-09) — proceeding to Iteration 5.
  - **Hypothesis**: since `"long"` trades utilization for completeness via response verbosity, a
    prompt style that's verbose enough to state supporting facts (helping completeness/adherence,
    per the Hantaan-virus-style pattern from Iteration 1) but *without* padding with extra
    unnecessary claims (which inflates utilization) might get completeness's improvement without
    utilization's regression. Candidate lever: `"long_cot"`'s CoT reasoning already engages
    relevant content without the "Final Answer" stripping problem — i.e. test showing the Judge
    the FULL long_cot output (reasoning + final answer) instead of just the parsed final line,
    rather than switching prompt style entirely.
  - **Proposed test**: added a new `Config` field `strip_cot_answer: bool = True` (default
    preserves all existing configs' behavior). In `generate_response()`, CoT styles now return the
    full raw generated text (reasoning + answer) when `strip_cot_answer=False`, instead of only the
    parsed "Final Answer:" line. Registered as `"v2"`: same as `baseline_n15`
    (`generation_prompt_style="long_cot"`, n=15) + `strip_cot_answer=False` — isolates exactly one
    variable (what text the Judge sees) vs. `baseline_n15`.
  - **What would confirm it**: completeness stays as good as `v1.1`'s (0.3755) while utilization
    recovers toward `baseline_n15`'s better value (0.1783) or improves further.
  - **What would falsify it**: utilization doesn't recover, or completeness regresses back toward
    `baseline_n15`'s worse value — would suggest the tradeoff is inherent to any verbose response,
    not specific to `"long"` vs `"long_cot"` framing.
  - **Registered as** `"v2"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell): `{"max_samples_per_domain": 15, "strip_cot_answer": False}`, all other fields inherited
    from `baseline`. `ACTIVE_CONFIG_NAME` set to `"v2"`.

### Iteration 5 — `"v2"` config (long_cot, full reasoning shown to Judge, n=15/domain)
- **Status**: DONE, but **INCOMPLETE RUN** (2026-07-09) — see caveat below before trusting these
  numbers.
- **Config**: `CONFIG_REGISTRY["v2"]` = baseline + `max_samples_per_domain=15` +
  `strip_cot_answer=False`. Same `generation_prompt_style="long_cot"` as `baseline_n15`; only
  difference is the Judge now sees the full reasoning + answer instead of the parsed final line.
- **⚠️ Data quality caveat**: this run hit Groq's **tokens-per-day (TPD)** quota, not the
  per-minute limit `request_min_interval_s` was tuned for — all 3 API keys were exhausted near
  their ~100,000 TPD cap partway through (this config's un-stripped CoT responses feed far more
  tokens into the Judge prompt than any prior config). **`pubmedqa` completed only 11/15 rows**
  (4 silently skipped after all retries/key-rotations failed) — `covidqa` completed a full 15/15.
  Pooled `n=26`, not 30. Treat comparisons against `v1.1`/`baseline_n15` (both clean n=30 runs) as
  suggestive, not conclusive, especially for pubmedqa-specific and pooled adherence figures (small
  sample cuts both ways here, compounding the class-imbalance fragility already flagged).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2867 | 0.2044 | 0.4918 | 0.9286 |
  | pubmedqa | 11 (of 15) | 0.3044 | 0.3982 | 0.3211 | 0.2778 |
  | ALL | 26 (of 30) | 0.2943 | 0.3019 | 0.4279 | 0.5362 |

  vs. `v1.1` (Iteration 4) pooled, n=30: relevance 0.2997, utilization 0.2257, completeness
  0.3755, adherence 0.7778.
  vs. `baseline_n15` (Iteration 3) pooled, n=30: relevance 0.3081, utilization 0.1783,
  completeness 0.4948, adherence 0.5185.

- **Observations**:
  1. **The hypothesis is FALSIFIED, not confirmed**: utilization did NOT recover toward
     `baseline_n15`'s better value (0.1783) — it got **worse than both prior configs**
     (0.2257 → 0.3019), moving further in the wrong direction, not back toward the target.
  2. **Completeness also regressed**, moving back toward `baseline_n15`'s worse value rather than
     holding `v1.1`'s gain (0.3755 → 0.4279) — losing most of the ground `v1.1` had gained.
  3. Net effect: showing the Judge the full CoT reasoning made things **worse on both axes**
     simultaneously, not a tradeoff recovery.
- **Inference**: full CoT reasoning text isn't just "more content" the way `"long"`'s single
  verbose paragraph was — it explicitly narrates document-by-document analysis ("Doc 0 mentions
  X... Doc 2 states Y..."), which appears to make the Judge mark an even *larger* set of context
  sentences as "utilized" than a single dense paragraph does (the reasoning walks through nearly
  every retrieved document explicitly, even ones it ultimately rules out as irrelevant). This
  overshoots utilization even further than `"long"` did, and the broader utilized-set also seems
  to dilute the overlap-with-relevant ratio that drives completeness. **Practical read**: of the
  three generation approaches tried so far (`long_cot`-stripped, `long`, `long_cot`-unstripped),
  `"long"`'s single dense paragraph (Iteration 4/`v1.1`) looks like the best point on this
  particular tradeoff curve — going *more* verbose (raw CoT) or *less* verbose (stripped final
  answer) both perform worse than the middle ground. This result should be re-run at a full n=30
  before being fully trusted, given the incomplete-data caveat above, but the direction is
  unambiguous even accounting for that (both metrics moved the wrong way, not just noise-sized
  wobble).
- **Decision for next config**: CONFIRMED with user (2026-07-09) — do not re-run `v2` cleanly for
  now; accept its result as directionally clear despite the incomplete sample, and pivot to a
  different lever entirely. `"long"` (`v1.1`'s generation_prompt_style) is carried forward
  unchanged as the new generation baseline; not touching generation-prompt style further for now.
  - **Hypothesis**: the current embedding (`BAAI/bge-small-en-v1.5`) and reranker
    (`cross-encoder/ms-marco-MiniLM-L-6-v2`) are general-purpose, not biomedical-specific, even
    though both domains (covidqa, pubmedqa) are biomedical text. A domain-adapted embedding/
    reranker pair should retrieve more precisely relevant sentences, which could lift completeness
    and relevance directly — completeness is still `v1.1`'s worst metric (0.3755) and Iteration 3
    found the Judge's relevance annotations look systematically over-liberal vs. ground truth, an
    upstream-of-generation problem generation-prompt tuning can't fix.
  - **Proposed test**: registered `"v3"` = `v1.1`'s config
    (`generation_prompt_style="long"`, n=15) + `embed_model="NeuML/pubmedbert-base-embeddings"` +
    `reranker_model="ncbi/MedCPT-Cross-Encoder"`. Isolates retrieval quality as the single changed
    variable vs. `v1.1`.
  - **What would confirm it**: completeness and/or relevance RMSE improve vs. `v1.1`'s
    0.3755/0.2997, without utilization regressing further from 0.2257.
  - **What would falsify it**: no meaningful change, or a regression — would suggest the Judge's
    relevance over-crediting is a Judge-prompt issue, not a retrieval-precision issue.
  - **Registered as** `"v3"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v3"`.

### Iteration 6 — `"v3"` config (domain-adapted retrieval: PubMedBERT embed + MedCPT reranker)
- **Status**: DONE (2026-07-09), clean n=30 run
- **Config**: `CONFIG_REGISTRY["v3"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `embed_model="NeuML/pubmedbert-base-embeddings"`,
  `reranker_model="ncbi/MedCPT-Cross-Encoder"`. All other fields inherited from `baseline`
  defaults (whole-document retrieval, top_k_retrieve=20/top_k_final=5, hybrid+MMR+reranker on,
  `request_min_interval_s=4.0`).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3711 | 0.2291 | 0.4541 | 0.3571 |
  | pubmedqa | 15 | 0.2808 | 0.2387 | 0.3271 | 0.6346 |
  | ALL | 30 | 0.3291 | 0.2339 | 0.3957 | 0.5370 |

  vs. `v1.1` (Iteration 4) pooled, n=30 (same generation style, general-purpose retrieval):
  relevance 0.2997, utilization 0.2257, completeness 0.3755, adherence 0.7778.

- **Observations**:
  1. **The hypothesis is FALSIFIED**: every metric moved in the wrong direction vs. `v1.1`, not
     just failed to improve. Relevance got worse (0.2997 → 0.3291), utilization got worse
     (0.2257 → 0.2339), completeness got worse (0.3755 → 0.3957). Domain-adapted retrieval did not
     help — modestly hurt — every axis.
  2. **The relevance over-crediting pattern persists unchanged** even with domain-adapted
     retrieval: row 0 (Norovirus question) still shows `pred_relevance=0.75` vs `gt_relevance=
     0.412` — a large overshoot, the same signature seen in Iteration 3 with general-purpose
     retrieval. If retrieval precision were the driver of the over-crediting, swapping to
     domain-specific models should have measurably tightened this gap; it didn't.
  3. Adherence AUCROC dropped again (0.7778 → 0.5370), and checking the same 3 minority-class
     rows (`gt_adherence=0`: rows 0, 16, 24): only **1 of 3** correct this time (row 24), down
     from 2/3 in `v1.1`. Consistent with the already-flagged AUCROC fragility — not treated as
     independent evidence either way.
- **Inference**: the relevance over-crediting pattern is very unlikely to be a retrieval-precision
  problem — it survived a substantive retrieval-side change (domain-adapted embedding + reranker)
  essentially unchanged, while directly hurting completeness/utilization instead of helping. This
  points the problem back toward the **Judge itself**: either the Judge model's interpretation of
  "relevant" is inherently more liberal than RAGBench's original GPT-4-turbo annotator was, or the
  judge prompt's relevance-annotation instructions leave more room for over-inclusion than intended.
  This reframes the leading open question from "which retrieval config is best" to "is our Judge
  systematically miscalibrated on relevance, independent of retrieval or generation choices" — a
  different category of problem than anything tested so far.
- **Decision for next config**: CONFIRMED with user (2026-07-10) — deferring the judge-model/
  judge-prompt question (user does not want to spend tokens on a larger judge model, and the
  judge prompt itself is off-limits). Instead: resolve Iteration 6's confound first, since it's
  the cheapest, most directly informative open thread.
  - **Hypothesis**: `v3` changed `embed_model` AND `reranker_model` together, so it's unknown
    whether the regression vs. `v1.1` came from the embedding, the reranker, or their interaction.
  - **Proposed test**: registered `"v5"` = `v1.1`'s config (`generation_prompt_style="long"`,
    n=15) + `embed_model="NeuML/pubmedbert-base-embeddings"` only — reranker stays
    `cross-encoder/ms-marco-MiniLM-L-6-v2` (general-purpose, same as `v1.1`).
  - **What would confirm/inform it**: if `v5` performs like `v1.1` (no regression) → the reranker
    was the problem in `v3`. If `v5` performs like `v3` (regressed) → the embedding model is the
    problem, reranker is innocent. If `v5` is worse than both → they interact negatively.
  - **What would falsify the "domain-adaptation hurts" narrative**: `v5` actually improves over
    `v1.1` — would mean the reranker specifically caused `v3`'s regression, and domain-adapted
    embeddings alone are fine or better.
  - **Registered as** `"v5"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v5"`.

### Iteration 8 — `"v5"` config (isolates embed_model from Iteration 6's confound)
- **Status**: DONE (2026-07-10), clean n=30 run
- **Config**: `CONFIG_REGISTRY["v5"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `embed_model="NeuML/pubmedbert-base-embeddings"`. Reranker
  (`cross-encoder/ms-marco-MiniLM-L-6-v2`), judge model, chunking, top_k all identical to `v1.1`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3107 | 0.1213 | 0.4194 | 0.4643 |
  | pubmedqa | 15 | 0.3467 | 0.2484 | 0.3752 | 0.8846 |
  | ALL | 30 | 0.3292 | 0.1954 | 0.3979 | 0.7593 |

  Three-way pooled comparison:

  | metric | `v1.1` (neither swapped) | `v3` (embed + reranker) | `v5` (embed only) |
  |---|---|---|---|
  | relevance_rmse | 0.2997 | 0.3291 | **0.3292** |
  | utilization_rmse | 0.2257 | 0.2339 | **0.1954** |
  | completeness_rmse | 0.3755 | 0.3957 | **0.3979** |
  | adherence_aucroc | 0.7778 | 0.5370 | **0.7593** |

- **Observations**:
  1. **`v5`'s relevance (0.3292) and completeness (0.3979) essentially exactly match `v3`'s
     (0.3291 / 0.3957)** — the embedding-only change fully reproduces those two regressions on its
     own. The reranker isn't needed to cause them.
  2. **`v5`'s utilization (0.1954) is BETTER than both `v1.1` (0.2257) and `v3` (0.2339)** — the
     opposite of `v3`'s pattern. Swapping the embedding alone doesn't hurt utilization; if
     anything it helps.
  3. **`v5`'s adherence AUCROC (0.7593) sits close to `v1.1`'s (0.7778)**, nowhere near `v3`'s
     collapse (0.5370). Checking the same 3 minority-class rows (`gt_adherence=0`: rows 0, 16,
     24): `v5` gets 2/3 correct (row 16 and row 24 correct, row 0 wrong) — matching `v1.1`'s 2/3,
     not `v3`'s 1/3.
- **Inference**: this cleanly disentangles Iteration 6's confound — **the embedding model and the
  reranker model are each responsible for a different half of `v3`'s regression**, not acting
  together:
  - The **embedding model** (PubMedBERT) is responsible for the relevance/completeness regression
    — reproduced almost exactly with the reranker held at `v1.1`'s general-purpose model.
  - The **reranker model** (MedCPT) is implicated as responsible for the utilization/adherence
    regression — since removing it (this run) recovers both back to `v1.1`-like levels.
  - This is a strong three-way comparison (not just two configs), and the pattern is clean enough
    (near-exact match on two metrics, full recovery on the other two) to trust the attribution
    without further isolation *in principle* — though a fourth run (reranker swapped alone,
    general embedding) would fully confirm it symmetrically rather than by elimination.
- **Decision for next config**: CONFIRMED with user (2026-07-10).
  - **Hypothesis**: by elimination from Iteration 8, the reranker (not the embedding) should be
    responsible for `v3`'s utilization/adherence regression.
  - **Proposed test**: registered `"v6"` = `v1.1`'s config (`generation_prompt_style="long"`,
    n=15, general-purpose embedding) + `reranker_model="ncbi/MedCPT-Cross-Encoder"` only.
  - **What would confirm it**: `v6`'s utilization/adherence regress toward `v3`'s worse values
    while relevance/completeness stay close to `v1.1`'s good values — the mirror image of `v5`.
  - **What would falsify it**: `v6` looks like `v1.1` on all four metrics — would mean `v3`'s
    regression required both changes together (a genuine interaction effect), not either alone.
  - **Registered as** `"v6"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v6"`.

### Iteration 9 — `"v6"` config (isolates reranker_model, completes the v5 disentangling)
- **Status**: DONE (2026-07-10), clean n=30 run
- **Config**: `CONFIG_REGISTRY["v6"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `reranker_model="ncbi/MedCPT-Cross-Encoder"`. Embedding
  (`BAAI/bge-small-en-v1.5`), judge model, chunking, top_k all identical to `v1.1`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2363 | 0.0811 | 0.5310 | 0.4286 |
  | pubmedqa | 15 | 0.2773 | 0.2593 | 0.3280 | 0.7692 |
  | ALL | 30 | 0.2576 | 0.1921 | 0.4413 | 0.6852 |

  Full four-way comparison (all n=30):

  | metric | `v1.1` (neither) | `v5` (embed only) | `v6` (reranker only) | `v3` (both) |
  |---|---|---|---|---|
  | relevance_rmse | 0.2997 | 0.3292 | **0.2576** (best) | 0.3291 |
  | utilization_rmse | 0.2257 | 0.1954 | **0.1921** (best) | 0.2339 (worst) |
  | completeness_rmse | **0.3755** (best) | 0.3979 | 0.4413 (worst) | 0.3957 |
  | adherence_aucroc | **0.7778** (best) | 0.7593 | 0.6852 | 0.5370 (worst) |

- **Observations**:
  1. **The hypothesis is FALSIFIED**: `v6` (reranker alone) does not reproduce `v3`'s
     utilization/adherence regression at all. Instead, `v6` has the BEST relevance and BEST
     utilization of all four configs — the opposite of what `v3`'s pattern would predict from the
     reranker alone.
  2. **`v6`'s completeness is the WORST of all four** (0.4413) — worse even than the combined
     `v3` (0.3957). The reranker alone hurts completeness more than combining it with the
     embedding does.
  3. **Neither single swap comes close to explaining `v3`'s adherence collapse**: `v5` alone
     (0.7593) and `v6` alone (0.6852) both stay much closer to `v1.1`'s 0.7778 than to `v3`'s
     0.5370. Checking the same 3 minority-class rows (`gt_adherence=0`: rows 0, 16, 24): `v6`
     gets 2/3 correct (matching `v1.1`/`v5`), not `v3`'s 1/3 — the collapse only appears when both
     changes are combined.
  4. Utilization shows the clearest interaction signature: BOTH individual swaps *improve*
     utilization vs. `v1.1` (0.1954 and 0.1921 vs. 0.2257), yet the combined `v3` is *worse* than
     baseline (0.2339) — two individually-positive effects combining into a net-negative one.
- **Inference**: **this overturns Iteration 8's tentative "clean disentangling" conclusion.** The
  truth is a genuine, non-additive interaction effect, not two independent, separable causes:
  - Relevance and completeness each seem to track roughly with whichever single component was
    tested in isolation more than a clean split would suggest (embedding dominates relevance,
    reranker dominates completeness's regression) — but even these aren't fully additive, since
    `v6`'s completeness alone is *worse* than the combined `v3`.
  - Adherence and utilization are the clearest cases of true interaction: neither embedding nor
    reranker alone comes anywhere near reproducing `v3`'s collapse on these two metrics — the
    damage only appears when both domain-adapted components are used together. This suggests the
    two models' retrieval/reranking behaviors compound in some way (e.g. both narrowing toward the
    same subset of "medically precise" content, amplifying an over-narrow or over-technical
    selection that neither alone would produce) rather than simply stacking independent errors.
  - **Practical implication for the "best config" question**: `v1.1` (long prompt, general-purpose
    retrieval, neither domain-adapted component) remains the best overall config found across all
    iterations to date — it's not just that domain adaptation "didn't help," it's that *any*
    domain-adapted retrieval component tested introduces a real tradeoff, and combining both
    components is worse than either alone on the metrics that matter most (adherence, utilization).
- **Decision for next config**: CONFIRMED with user (2026-07-11). This closes out the
  embedding/reranker line of investigation — `v1.1` stands as the best config found. Moving to a
  new, untested, token-neutral lever.
  - **Hypothesis**: `v1.1` uses MMR (`mmr_lambda=0.5`) to diversify retrieved documents, trading
    some pure relevance for reduced redundancy. Given relevance/completeness are still the two
    weakest metrics, this diversity trade-off may be costing precision without a clear benefit at
    a small `top_k_final=5`.
  - **Proposed test**: registered `"v7"` = `v1.1`'s config (`generation_prompt_style="long"`,
    n=15, general-purpose retrieval) + `use_mmr=False` (pure relevance-ranked selection).
    Token-neutral vs. `v1.1` — `top_k_final` unchanged, only which 5 documents get selected
    differs.
  - **What would confirm it**: relevance and/or completeness RMSE improve vs. `v1.1`'s
    0.2997/0.3755, without utilization or adherence regressing.
  - **What would falsify it**: no meaningful change, or a regression — would mean MMR's diversity
    was actually helping (e.g. avoiding redundant near-duplicate documents).
  - **Registered as** `"v7"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v7"`.

### Iteration 10 — `"v7"` config (MMR disabled, pure relevance-ranked retrieval)
- **Status**: DONE (2026-07-11), clean n=30 run
- **Config**: `CONFIG_REGISTRY["v7"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`. Embedding, reranker, judge model, chunking,
  top_k all identical to `v1.1`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.1936 | 0.0808 | 0.4837 | 0.9286 |
  | pubmedqa | 15 | 0.2939 | 0.2844 | 0.3473 | 0.7692 |
  | ALL | 30 | 0.2488 | 0.2091 | 0.4211 | 0.8519 |

  vs. `v1.1` (MMR on) pooled, n=30: relevance 0.2997, utilization 0.2257, completeness 0.3755,
  adherence 0.7778.

- **Observations**:
  1. **Relevance improved meaningfully** (0.2997 → 0.2488, ~17% relative improvement) — the
     largest single-lever relevance gain of any iteration tested so far, and directly consistent
     with the hypothesis: pure relevance-ranked retrieval (no diversity trade-off) selects more
     precisely relevant documents.
  2. **Utilization also improved slightly** (0.2257 → 0.2091).
  3. **Completeness got WORSE** (0.3755 → 0.4211) — the opposite of what "more relevant documents"
     would naively predict, and a real regression on `v1.1`'s single best metric.
  4. **Adherence AUCROC improved to 0.8519**, the best of any iteration to date. Checking the same
     3 minority-class rows (`gt_adherence=0`: rows 0, 16, 24): all **3/3 correct** this run — a
     clean sweep, better than `v1.1`'s 2/3. Still the same fragility caveat applies (n=30, only 3
     negative-class rows), but this is the best result on that specific check so far.
- **Inference**: the hypothesis is **partially confirmed** — MMR's diversity trade-off does appear
  to cost relevance precision, exactly as predicted. But it's NOT a clean win: MMR's diversity
  seems to have been **helping completeness specifically**, most likely because pulling in a
  more varied (not just most-similar) set of documents increases the chance that the *response*
  ends up drawing on a broader spread of the truly relevant sentences, rather than several
  near-duplicate top-ranked documents that all say the same thing. Without MMR, retrieval may be
  more precise per-document but more redundant across documents — good for relevance's ratio, bad
  for completeness's coverage of distinct relevant content. This is a real, mechanistically
  sensible tradeoff, not noise — a third distinct tradeoff axis found in this project (alongside
  the generation-verbosity tradeoff from Iterations 2/4/5, and the embed/reranker interaction from
  Iterations 6/8/9).
- **Decision for next config**: CONFIRMED with user (2026-07-11) — **scope change**: restrict to
  `pubmedqa` only for all runs going forward, to roughly halve Groq token usage per run given
  ongoing budget pressure. User chose to continue refining from `v7` (best relevance/adherence)
  over `v1.1` (best completeness) when asked directly.
  - **Note**: this is a methodology change, not a hypothesis test. Going forward, all comparisons
    should be read as pubmedqa-only performance, not pooled across both domains — any claim about
    covidqa or cross-domain generalization from this point on would need a dedicated check against
    the covidqa-inclusive numbers already on record (Iterations 1-10 above).
  - **Registered as** `"v8"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell): `v7`'s config + `domains=("pubmedqa",)`. `ACTIVE_CONFIG_NAME` set to `"v8"`.

### Iteration 11 — `"v8"` config (pubmedqa-only baseline, continuing from v7)
- **Status**: DONE (2026-07-11)
- **Config**: `CONFIG_REGISTRY["v8"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`, `domains=("pubmedqa",)`. All other fields
  identical to `v7`/`v1.1` (general-purpose embed/reranker, no chunking, top_k_retrieve=20/
  top_k_final=5) — **same config as `v7`, just re-scoped to pubmedqa alone**, not a new
  hypothesis test.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2604 | 0.2069 | 0.2731 | 0.7115 |

  vs. `v7`'s `pubmedqa`-only row (Iteration 10, same config, same 15 questions, both domains run
  together): relevance 0.2939, utilization 0.2844, completeness 0.3473, adherence 0.7692.

- **Observations**: same config, same question set, same order — the only source of run-to-run
  difference should be the generator's `temperature=0.2` (the judge is deterministic at
  `temperature=0.0`, so any variance is generation-side). Relevance, utilization, and completeness
  all came out somewhat better this run (0.2604 vs 0.2939; 0.2069 vs 0.2844; 0.2731 vs 0.3473);
  adherence AUCROC came out somewhat worse (0.7115 vs 0.7692) — traced to the same 2 minority-class
  rows within pubmedqa (`gt_adherence=0`: nitinol stents question, FMS question) as before; this
  run got only 1 of 2 correct (nitinol flipped wrong) vs. 2/2 in the `v7` run.
- **Inference**: since nothing in the pipeline changed except which domain(s) were included, these
  differences are most plausibly **run-to-run generation stochasticity**, not a real effect of
  narrowing scope to pubmedqa. This gives a rough **noise band** for future comparisons at this
  sample size: ~0.03-0.08 RMSE swing and ~0.06 AUCROC swing (on top of the already-flagged
  small-sample AUCROC fragility, worse here since only 2 negative-class rows exist in pubmedqa
  alone, down from 3 pooled). **Any future pubmedqa-only config change should be read against this
  noise band** — a difference smaller than roughly this magnitude may not be a real effect.
- **Decision for next config**: CONFIRMED with user (2026-07-11) — this run establishes the
  pubmedqa-only baseline (relevance 0.2604, utilization 0.2069, completeness 0.2731, adherence
  0.7115) that future levers will be compared against.
  - **Hypothesis**: BM25's sparse candidates may dilute the fused (RRF) ranking's precision by
    injecting less semantically-relevant matches before the reranker sees them — relevance is
    still one of the weaker metrics.
  - **Proposed test**: registered `"v9"` = `v8`'s config (pubmedqa-only, MMR off, `"long"`
    prompt) + `use_hybrid_search=False` (dense-only retrieval, no BM25 fusion). Token-neutral —
    `top_k_final` unchanged.
  - **What would confirm it**: relevance and/or completeness improve beyond the ~0.03-0.08 noise
    band established in Iteration 11, without utilization or adherence regressing similarly.
  - **What would falsify it**: no meaningful change (within noise band) or a regression — would
    mean BM25 was contributing genuinely useful candidates dense retrieval alone misses.
  - **Registered as** `"v9"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v9"`.

### Iteration 12 — `"v9"` config (dense-only retrieval, hybrid/BM25 fusion disabled)
- **Status**: DONE (2026-07-11)
- **Config**: `CONFIG_REGISTRY["v9"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`, `domains=("pubmedqa",)`,
  `use_hybrid_search=False`. All other fields identical to `v8`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.3156 | 0.2517 | 0.2583 | 0.6731 |

  vs. `v8` baseline (Iteration 11): relevance 0.2604, utilization 0.2069, completeness 0.2731,
  adherence 0.7115. Vs. established noise band (~0.03-0.08 RMSE, ~0.06 AUCROC):

  | metric | v8 → v9 | diff | within noise band? |
  |---|---|---|---|
  | relevance_rmse | 0.2604 → 0.3156 (worse) | 0.0552 | yes, at the upper edge |
  | utilization_rmse | 0.2069 → 0.2517 (worse) | 0.0448 | yes |
  | completeness_rmse | 0.2731 → 0.2583 (slightly better) | 0.0148 | yes, comfortably |
  | adherence_aucroc | 0.7115 → 0.6731 (worse) | 0.0384 | yes |

- **Observations**: every single metric moved, but **none of the movements clearly exceed the
  noise band** established in Iteration 11's same-config repeat run. Relevance moved the most (in
  the *wrong* direction from the hypothesis) but still sits within the noise band's upper edge.
- **Inference**: this result is **inconclusive, not falsifying** — the hypothesis predicted
  relevance/completeness would improve; relevance instead moved slightly worse and completeness
  moved slightly better, and neither move is distinguishable from run-to-run noise at n=15. Two
  honest readings: (a) hybrid search genuinely makes no meaningful difference at this scale, or
  (b) the effect size (if any) is smaller than what n=15 can reliably detect, and a larger sample
  would be needed to resolve it. Cannot distinguish between these from this run alone. This is a
  useful negative data point either way — it means hybrid search is not currently a lever worth
  prioritizing further at this sample size, since even a config change produced a smaller shift
  than plain generation-temperature noise did in Iteration 11.
- **Decision for next config**: CONFIRMED with user (2026-07-11) — prioritize a lever with
  historically larger effect sizes over tightening the noise band first, since we don't know in
  advance whether the next lever will need that precision, and a big enough effect wouldn't need
  it either. Top-k widening chosen over chunking: doesn't require rebuilding the corpus/embeddings
  (chunking does), and chunking historically only worked well *combined* with widened top-k in
  the earlier v1 project (chunking alone regressed everything), so top-k is the more fundamental
  lever to test in isolation first.
  - **Hypothesis**: widening `top_k_retrieve`/`top_k_final` gives the generator and Judge more
    retrieved content to draw from, directly targeting completeness and relevance (the persistent
    weaker metrics across this whole project).
  - **Proposed test**: registered `"v10"` = `v8`'s config (pubmedqa-only, MMR off, `"long"`
    prompt, hybrid search back on since `v9` gave no evidence to turn it off) +
    `top_k_retrieve=30` (up from 20) + `top_k_final=10` (up from 5).
  - **What would confirm it**: completeness and/or relevance improve beyond the ~0.03-0.08 RMSE
    noise band, without adherence collapsing (more content could also mean more unsupported
    claims).
  - **What would falsify it**: no meaningful change, or a regression — would suggest retrieval
    depth isn't the bottleneck at this corpus/domain scale.
  - **Registered as** `"v10"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v10"`.

### Iteration 13 — `"v10"` config (widened top_k_retrieve/top_k_final)
- **Status**: DONE (2026-07-11)
- **Config**: `CONFIG_REGISTRY["v10"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`, `domains=("pubmedqa",)`, `top_k_retrieve=30`,
  `top_k_final=10`. Hybrid search back on (general default). Everything else identical to `v8`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.1984 | 0.1314 | 0.3733 | 0.3077 |

  vs. `v8` baseline (Iteration 11): relevance 0.2604, utilization 0.2069, completeness 0.2731,
  adherence 0.7115. Vs. established noise band (~0.03-0.08 RMSE, ~0.06 AUCROC):

  | metric | v8 → v10 | diff | within noise band? |
  |---|---|---|---|
  | relevance_rmse | 0.2604 → 0.1984 (better) | 0.0620 | borderline, near upper edge |
  | utilization_rmse | 0.2069 → 0.1314 (better) | 0.0755 | borderline, near upper edge |
  | completeness_rmse | 0.2731 → 0.3733 (worse) | 0.1002 | **NO — clearly exceeds noise band** |
  | adherence_aucroc | 0.7115 → 0.3077 (much worse) | 0.4038 | **NO — far exceeds noise band** |

- **Observations**:
  1. **The hypothesis is FALSIFIED, and clearly so on the two metrics that matter most.**
     Completeness got measurably worse, not better, and adherence AUCROC collapsed to below
     random-guessing level (0.3077) — a real, large effect, not noise.
  2. **Relevance and utilization did improve**, but only borderline beyond the noise band — a much
     weaker and less certain signal than the completeness/adherence damage.
  3. Checking the same-style minority-class rows for this run (`gt_adherence=0`: nitinol stents
     question and FMS question, same two as before): **both are now wrong** (0/2 correct) — worse
     than every prior pubmedqa-only run, and not attributable to single-row flip noise since both
     flipped simultaneously.
- **Inference**: widening retrieval depth backfired on the metrics we most wanted to improve. Most
  likely mechanism: the additional 5 marginal documents (reranked positions 6-10, versus the
  original top 5) are lower-quality/less relevant by construction — reranking naturally puts the
  best candidates first — and their inclusion appears to encourage the generator to synthesize
  claims across a wider, weaker set of sources. This produces responses making more
  cross-document inferential connections that the Judge can't fully verify against any single
  supporting sentence, directly hurting adherence, and diluting the sentence-level
  relevant/utilized overlap that drives completeness. The modest relevance/utilization gains are
  a much smaller, less certain effect than this clear downside. **Retrieval depth is not the
  bottleneck at this corpus scale — if anything, going deeper actively hurts groundedness.**
- **Decision for next config**: CONFIRMED with user (2026-07-11) — **deadline extended by a
  week**; resuming the remaining-levers sweep rather than wrapping up. This closes out top-k as a
  promising lever — the opposite of what historical precedent (from the earlier v1 project)
  suggested, worth noting as a real divergence for the presentation. `v8` (top_k_final=5) remains
  the best pubmedqa-only config found to date.
  - **Hypothesis**: lower generator temperature (more conservative/deterministic decoding) may
    reduce the kind of speculative cross-document synthesis that hurt adherence in `v10`
    (0.7115→0.3077 with more retrieved content), and could also tighten completeness/utilization
    by reducing stylistic variance in the response.
  - **Proposed test**: added `generator_temperature: float = 0.2` as a new `Config` field
    (`generate_response` now reads `cfg.generator_temperature` instead of a hardcoded `0.2`).
    Registered `"v11"` = `v8`'s config (pubmedqa-only, best-so-far base) +
    `generator_temperature=0.0`.
  - **What would confirm it**: adherence and/or completeness improve vs. `v8`'s baseline
    (0.7115 / 0.2731) beyond the ~0.03-0.08 RMSE / ~0.06 AUCROC noise band.
  - **What would falsify it**: no meaningful change — would suggest temperature isn't a
    meaningful factor at this scale (0.2 was already fairly conservative).
  - **Registered as** `"v11"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v11"`.

### Iteration 14 — `"v11"` config (generator temperature lowered to 0.0)
- **Status**: DONE (2026-07-11)
- **Config**: `CONFIG_REGISTRY["v11"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`, `domains=("pubmedqa",)`,
  `generator_temperature=0.0` (down from default `0.2`). Everything else identical to `v8`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2023 | 0.1771 | 0.4110 | 0.3846 |

  vs. `v8` baseline (Iteration 11): relevance 0.2604, utilization 0.2069, completeness 0.2731,
  adherence 0.7115. Vs. established noise band (~0.03-0.08 RMSE, ~0.06 AUCROC):

  | metric | v8 → v11 | diff | within noise band? |
  |---|---|---|---|
  | relevance_rmse | 0.2604 → 0.2023 (better) | 0.0581 | borderline, near upper edge |
  | utilization_rmse | 0.2069 → 0.1771 (better) | 0.0298 | yes, comfortably |
  | completeness_rmse | 0.2731 → 0.4110 (worse) | 0.1379 | **NO — clearly exceeds noise band** |
  | adherence_aucroc | 0.7115 → 0.3846 (much worse) | 0.3269 | **NO — far exceeds noise band** |

- **Observations**:
  1. **The hypothesis is FALSIFIED**, and in a striking way: this result is **nearly the same
     shape as `v10`'s** (widened top-k) — modest relevance/utilization improvement, but
     completeness and adherence both collapse hard.
  2. **The exact same two minority-class rows fail** as in `v10`: the nitinol stents question
     (`gt_adherence=0`, predicted `1.0`) and the FMS question (`gt_adherence=0`, predicted `1.0`)
     — both wrong in `v10` AND `v11`, 0/2 correct in both, despite `v10` and `v11` changing
     completely unrelated levers (retrieval depth vs. generation temperature).
- **Inference**: this is a genuine **cross-iteration pattern**, not two unrelated coincidences.
  Two entirely different config changes — one retrieval-side (more documents), one
  generation-side (lower temperature) — produced the *same* qualitative failure on the *same*
  two specific questions. This suggests these two particular ground-truth-negative examples
  (nitinol stent hemodynamics; FMS training effectiveness) may be structurally hard for this
  Judge/prompt combination whenever the generated response becomes more confident/assertive in
  a certain way — both `v10` and `v11` push the generator toward less hedged, more
  definitively-stated conclusions (more content to draw a firm conclusion from; deterministic
  decoding reducing hedging language). RAGBench's own ground truth marks both of these as
  *not* fully supported (i.e., appropriately uncertain), while our pipeline's more "confident"
  responses under both configs get judged as fully supported when they shouldn't be. This reads
  as a real, repeatable failure mode: **configs that push toward more assertive/complete-sounding
  answers risk manufacturing false confidence on genuinely ambiguous questions** — worth
  highlighting explicitly in the presentation as a qualitative case study (two concrete examples,
  reproduced identically under two unrelated interventions).
- **Decision for next config**: CONFIRMED with user (2026-07-11) — `v8` remains the best config;
  both attempted "improvements" since (`v10`, `v11`) independently reproduced the same
  adherence-collapse failure mode. Before moving to the next lever, did a free (no-API-cost)
  side-by-side qualitative comparison of the actual response text for both failing questions
  across `v7`/`v8`/`v10`/`v11`, since we already had the full text from each run.

  **FMS question** (the cleaner case — flips cleanly):
  - `v8` (correct, pred=0.0=gt): "...it appears that the FMS **may not be the most effective
    tool** for capturing changes..."
  - `v10`/`v11` (both wrong, pred=1.0≠gt=0): "...the answer to the question is **yes**, the FMS
    can be used..." / "...it appears that the **FMS can be used**..."

  **Nitinol stents question** (correction: `v8` was already wrong, not just `v10`/`v11` — `v7`
  is the last run that got this one right):
  - `v7` (correct, pred=0.0=gt): "...the effect on hemodynamics **is less clear**..."
  - `v8`/`v10`/`v11` (all wrong, pred=1.0≠gt=0, near-identical wording each time): "...**does not
    appear to significantly alter** hemodynamics."

  **Finding**: both questions have substantial retrieved evidence (gt completeness 0.75-0.8) that
  is genuinely *mixed* across documents. RAGBench's ground truth rewards acknowledging that
  ambiguity (hedged language: "is less clear," "may not be the most effective") over resolving it
  into a confident conclusion ("yes," "does not appear to significantly alter"). The exact wording
  of the final sentence — not response length or amount of source content — is what flips these
  specific examples, which also explains why `v7`→`v8` (an identical-config rerun) already flipped
  the nitinol question via ordinary generation-temperature variance, with no config change at all.
  **This is a real qualitative failure mode** (decisive-sounding synthesis overstepping genuinely
  mixed evidence) but not one addressable via a single config lever — it's closer to a fundamental
  tension between confident writing style and appropriately-hedged uncertainty. Logged here as a
  qualitative case study for the capstone presentation (two named, precisely-contrasted examples)
  rather than pursued as a further config test.
  - Moving to the next quantitative lever: **chunking strategy**.
  - **Hypothesis**: whole-document retrieval currently returns 5 full documents, which may carry
    a lot of irrelevant padding around the actually-relevant sentences, hurting relevance's
    precision. Sentence-aligned chunking at the SAME `top_k_final=5` (5 chunks, not whole
    documents) could surface denser, more precisely relevant units without widening top_k the way
    `v10` did — avoiding that specific failure mode while still increasing content precision.
  - **Proposed test**: registered `"v12"` = `v8`'s config (pubmedqa-only, best-so-far base) +
    `chunking_strategy="sentence_window"` (default `chunk_size_chars=500`,
    `chunk_overlap_sentences=1`). `top_k_final` stays at 5.
  - **What would confirm it**: relevance and/or completeness improve beyond the noise band
    without adherence collapsing (a key risk — less total context per unit could also mean less
    material to draw a hedged, evidence-appropriate conclusion from, worsening the exact failure
    mode found in `v10`/`v11`).
  - **What would falsify it**: matches the earlier v1 project's finding — regression across the
    board, since 5 small chunks carry much less total content than 5 whole documents did.
  - **Registered as** `"v12"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v12"`.

### Iteration 15 — `"v12"` config (sentence-window chunking, top_k_final unchanged)
- **Status**: DONE (2026-07-13)
- **Config**: `CONFIG_REGISTRY["v12"]` = `generation_prompt_style="long"`,
  `max_samples_per_domain=15`, `use_mmr=False`, `domains=("pubmedqa",)`,
  `chunking_strategy="sentence_window"` (`chunk_size_chars=500`, `chunk_overlap_sentences=1`).
  Everything else identical to `v8`, including `top_k_retrieve=20`/`top_k_final=5`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2832 | 0.2656 | 0.2892 | 0.5962 |

  vs. `v8` baseline (Iteration 11): relevance 0.2604, utilization 0.2069, completeness 0.2731,
  adherence 0.7115. Vs. established noise band (~0.03-0.08 RMSE, ~0.06 AUCROC):

  | metric | v8 → v12 | diff | within noise band? |
  |---|---|---|---|
  | relevance_rmse | 0.2604 → 0.2832 (slightly worse) | 0.0228 | yes, comfortably |
  | utilization_rmse | 0.2069 → 0.2656 (worse) | 0.0587 | borderline, near upper edge |
  | completeness_rmse | 0.2731 → 0.2892 (slightly worse) | 0.0161 | yes, comfortably |
  | adherence_aucroc | 0.7115 → 0.5962 (worse) | 0.1154 | **NO — exceeds noise band** |

- **Observations**:
  1. **The hypothesis is FALSIFIED**: relevance and completeness did not improve — both moved
     slightly (and non-significantly) in the wrong direction. Utilization worsened borderline.
     Only adherence shows a clear, above-noise regression.
  2. **This is a DIFFERENT failure mode from `v10`/`v11`.** Those two both produced *false
     positives* on the same 2 known minority-class rows (nitinol, FMS) while the majority-class
     (`gt_adherence=1`) rows stayed mostly correct. Here, the nitinol row is still wrong (same
     persistent miss as every run since `v8`), but **FMS is now correctly classified** (hedged
     phrasing: "it may not be sufficient on its own to capture all changes..."). Instead, **new
     false negatives appear on majority-class rows that were correct in `v8`**: the prostate
     biopsy question (pred 0.0 vs gt 1.0 — was correct in `v8`) and the surgery/radiotherapy
     interval question (pred 0.0 vs gt 1.0 — was also correct in `v8`).
- **Inference**: chunking appears to be causing new **false negatives** (responses judged
  unsupported that shouldn't be), not the false positives seen in `v10`/`v11`. Most plausible
  mechanism, consistent with the earlier v1 project's own "chunk-boundary recall" finding:
  splitting documents into chunks can separate a response's supporting sentence from other
  sentences in the same original document that would help the Judge confirm full support: if the
  specific chunk containing the precise supporting sentence isn't among the top-5 retrieved
  chunks (while a different, related-but-less-precise chunk from the same original document is),
  the Judge may correctly find the response sentence's most literal support missing, even though
  whole-document context would have made the connection clear. This replicates the earlier v1
  project's chunking finding in this fresh pipeline: **chunking alone, without widening top-k to
  compensate, regresses adherence** — though here the top-k compensation itself was already ruled
  out as a fix (`v10`), so simply "widen top-k after chunking" (the old project's solution) is not
  available as a follow-up fix in this pipeline.
- **Decision for next config**: CONFIRMED with user (2026-07-13) — before abandoning chunking
  entirely or committing to a bigger implementation effort (parent-document expansion), test the
  cheapest variant first: larger chunks with more overlap, to see if the chunk-boundary recall
  loss is sensitive to chunk size at all.
  - **Hypothesis**: `v12`'s new false negatives came from a supporting sentence's chunk not being
    among the top-5 retrieved — bigger chunks and more overlap directly reduce how often a
    document gets split in a way that separates a claim from its context.
  - **Proposed test**: registered `"v13"` = `v12`'s config +
    `chunk_size_chars=1200` (up from 500) + `chunk_overlap_sentences=2` (up from 1).
  - **What would confirm it**: adherence recovers toward `v8`'s 0.7115, without relevance/
    completeness/utilization regressing further.
  - **What would falsify it**: adherence stays similarly bad — would suggest the problem isn't
    really about chunk size, and the more targeted fix (parent-document expansion: retrieve at
    chunk granularity, but pass the whole source document to generator/judge) is the real next
    step rather than further tuning chunk parameters.
  - **Registered as** `"v13"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v13"`.

### Iteration 16 — `"v13"` config (larger sentence-window chunks, more overlap)
- **Status**: DONE (2026-07-13)
- **Config**: `CONFIG_REGISTRY["v13"]` = `v12`'s config + `chunk_size_chars=1200`,
  `chunk_overlap_sentences=2`. Everything else identical to `v12` (chunking on,
  `top_k_retrieve=20`/`top_k_final=5`).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2779 | 0.2380 | 0.3441 | 0.8462 |

  Three-way comparison:

  | metric | `v8` (no chunking) | `v12` (chunk 500/1) | `v13` (chunk 1200/2) |
  |---|---|---|---|---|
  | relevance_rmse | 0.2604 | 0.2832 | 0.2779 |
  | utilization_rmse | 0.2069 | 0.2656 | 0.2380 |
  | completeness_rmse | **0.2731** | 0.2892 | 0.3441 |
  | adherence_aucroc | 0.7115 | 0.5962 | **0.8462** |

- **Observations**:
  1. **The hypothesis is CONFIRMED**: adherence fully recovered and then some — 0.5962 → 0.8462,
     now the best adherence of any pubmedqa-only config tested, better even than `v8`'s
     whole-document baseline (0.7115). Checking the same minority-class rows: **both nitinol and
     FMS are now correctly classified** (2/2) — full recovery from `v12`'s failures on both, and
     better than `v8`'s own persistent miss on the nitinol question.
  2. Relevance and utilization landed close to `v8`'s baseline (within/near the noise band).
  3. **Completeness regressed further** (0.2731 → 0.3441, a 0.071 diff — right at the noise
     band's upper edge, ambiguous whether this is a real cost or borderline noise).
- **Inference**: bigger chunks with more overlap directly fixed the chunk-boundary recall
  mechanism diagnosed in `v12` — confirming that mechanism was real and chunk-size-sensitive, not
  some other cause. This validates the cheap test before committing to parent-document expansion:
  simply tuning chunk size/overlap was sufficient here, no need for the bigger implementation
  effort. However, there's a real (if borderline) completeness cost — `v13` is not a clean,
  unambiguous win over `v8`, it's another genuine tradeoff: **best adherence of the whole
  project vs. `v8`'s better completeness**, similar in shape to the earlier `v1.1`-vs-`v7`
  tradeoff.
- **Decision for next config**: CONFIRMED with user (2026-07-13) — search for a sweet spot
  between `v12`/`v13` before deciding which config to adopt as the leading candidate.
  - **Hypothesis**: `v13`'s completeness cost (0.071 diff, right at the noise band's edge) may be
    avoidable — if `chunk_overlap_sentences=2` (not chunk size per se) is doing most of the
    adherence-fix work, an intermediate chunk size at the same overlap could keep `v13`'s
    adherence gain without its completeness cost.
  - **Proposed test**: registered `"v14"` = `v12`'s config + `chunk_size_chars=800` (between
    `v12`'s 500 and `v13`'s 1200) + `chunk_overlap_sentences=2` (same as `v13`).
  - **What would confirm a sweet spot exists**: adherence stays close to `v13`'s 0.8462 while
    completeness recovers toward `v8`'s 0.2731 or `v12`'s 0.2892.
  - **What would falsify it**: completeness keeps degrading in lockstep with chunk size
    (confirming a real, unavoidable tradeoff), or adherence drops back toward `v12`'s 0.5962
    level (confirming chunk size specifically, not overlap, was doing the work).
  - **Registered as** `"v14"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v14"`.

### Iteration 17 — `"v14"` config (intermediate chunk size, v13's overlap)
- **Status**: DONE (2026-07-13) — **best result of the entire project**
- **Config**: `CONFIG_REGISTRY["v14"]` = `v12`'s config + `chunk_size_chars=800`,
  `chunk_overlap_sentences=2`. Everything else identical to `v12`/`v13` (chunking on,
  `top_k_retrieve=20`/`top_k_final=5`).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2815 | 0.1427 | 0.2247 | 0.9231 |

  Four-way comparison:

  | metric | `v8` (no chunking) | `v12` (chunk 500/1) | `v13` (chunk 1200/2) | `v14` (chunk 800/2) |
  |---|---|---|---|---|
  | relevance_rmse | 0.2604 | 0.2832 | 0.2779 | 0.2815 |
  | utilization_rmse | 0.2069 | 0.2656 | 0.2380 | **0.1427** |
  | completeness_rmse | 0.2731 | 0.2892 | 0.3441 | **0.2247** |
  | adherence_aucroc | 0.7115 | 0.5962 | 0.8462 | **0.9231** |

- **Observations**:
  1. **The sweet-spot hypothesis is CONFIRMED, and better than expected**: `v14` wins outright on
     THREE of four metrics — best utilization, best completeness, AND best adherence of every
     config tested in the entire project, all at once. Only relevance is marginally worse than
     `v8` (0.2604 → 0.2815, a 0.021 diff — comfortably within the noise band).
  2. Both minority-class rows (nitinol, FMS) are correctly classified again (2/2), matching
     `v13`'s full recovery — confirms `chunk_overlap_sentences=2` (shared by both `v13` and `v14`)
     is the specific lever driving the adherence fix, not chunk size approaching whole-document
     size.
  3. **Completeness and utilization are actually BETTER than `v8`'s whole-document baseline**,
     not just recovered from `v12`'s regression — smaller chunks (800 vs. `v13`'s 1200) appear to
     give the Judge denser, more precisely-scoped units to assess, improving precision on both
     metrics beyond what whole documents or larger chunks achieve.
- **Inference**: this fully resolves the sweet-spot search. `chunk_overlap_sentences=2` fixes the
  chunk-boundary recall problem (confirmed across both `v13` and `v14`); `chunk_size_chars=800`
  (smaller than `v13`'s 1200) turns out to be the more precise retrieval unit, avoiding whatever
  cost `v13`'s larger chunks incurred on completeness/utilization. This is no longer a tradeoff —
  `v14` dominates `v8` on 3 of 4 metrics with the 4th statistically indistinguishable. **`v14` is
  the new leading candidate for the project's best overall configuration.**
- **Decision for next config**: CONFIRMED with user (2026-07-13) — proceed with cross-domain
  generalization check first, since the project's original goal (2026-07-06) was a config that
  generalizes across domains, and `v14` has only ever been tested on pubmedqa alone.
  - **Proposed test**: registered `"v15"` = `v14`'s exact config, re-scoped to
    `domains=("covidqa", "pubmedqa")` (both, n=15/domain, n=30 total) instead of pubmedqa-only.
  - **What would confirm generalization**: `v15`'s pubmedqa-only row (extractable from its
    per-domain scoreboard) stays close to `v14`'s numbers (0.2815 / 0.1427 / 0.2247 / 0.9231),
    and covidqa's row doesn't show a dramatically worse pattern — i.e. the config's strengths
    aren't pubmedqa-specific.
  - **What would falsify it**: covidqa performs much worse than pubmedqa under this same config,
    or pubmedqa's own numbers shift substantially just from re-including covidqa in the same run
    (would point to some cross-domain interaction, e.g. shared embedder/reranker behaving
    differently once two domains' corpora exist side by side — though corpora/indexes are built
    per-domain independently, so this shouldn't mechanically happen).
  - **Registered as** `"v15"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v15"`.

### Iteration 18 — `"v15"` config (v14's config, cross-domain generalization check)
- **Status**: DONE (2026-07-14)
- **Config**: `CONFIG_REGISTRY["v15"]` = `v14`'s exact config (`generation_prompt_style="long"`,
  `use_mmr=False`, `chunking_strategy="sentence_window"`, `chunk_size_chars=800`,
  `chunk_overlap_sentences=2`) + `domains=("covidqa", "pubmedqa")` instead of pubmedqa-only.
  `max_samples_per_domain=15` (n=30 total).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2293 | 0.2947 | 0.5255 | 0.9643 |
  | pubmedqa | 15 | 0.3006 | 0.1919 | 0.2451 | 0.8077 |
  | ALL | 30 | 0.2673 | 0.2486 | 0.4100 | 0.8889 |

  pubmedqa-only comparison vs. `v14` (Iteration 17, same config, pubmedqa isolated):

  | metric | v14 (pubmedqa-only) | v15 pubmedqa row | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.2815 | 0.3006 | 0.0191 | yes |
  | utilization_rmse | 0.1427 | 0.1919 | 0.0492 | yes |
  | completeness_rmse | 0.2247 | 0.2451 | 0.0204 | yes |
  | adherence_aucroc | 0.9231 | 0.8077 | 0.1154 | **NO — exceeds noise band** |

- **Observations**:
  1. **Relevance, utilization, and completeness all reproduce closely** on pubmedqa — every diff
     is within the noise band established in Iteration 11. This is a genuine confirmation: the
     chunking fix's core benefit is not pubmedqa-specific noise, it holds up when covidqa is
     re-introduced into the same run.
  2. **Adherence dropped meaningfully on pubmedqa** (0.9231 → 0.8077) — but checking the same
     two persistent minority-class rows (nitinol, FMS): **both are still correctly classified**
     (2/2, matching `v14`). The drop instead comes from **3 NEW false negatives on
     majority-class (`gt_adherence=1`) rows that were correct in `v14`**: the elderly-fluids
     question, the clopidogrel/BMI question, and the blood-donation question — all now judged
     unsupported when `v14`'s versions of the same responses weren't.
  3. **Covidqa's own numbers are broadly consistent with its historical pattern**: relevance
     (0.2293) and adherence (0.9643, covidqa's best-ever value) are strong; completeness (0.5255)
     is markedly worse than pubmedqa's — but this matches covidqa's *own* long-standing pattern
     under no-chunking configs too (e.g. `v7`'s covidqa completeness was 0.4837) — i.e. covidqa
     has consistently had weaker completeness than pubmedqa across this entire project,
     independent of chunking. Chunking doesn't appear to have introduced a new covidqa-specific
     problem.
- **Inference**: this is a genuine, if partial, generalization confirmation. Three of four metrics
  hold up on pubmedqa within noise; covidqa's completeness weakness is pre-existing, not caused by
  this config. **The adherence drop is most plausibly explained by the still-unfixed missing
  `seed` parameter (flagged 2026-07-13)** — since pubmedqa's corpus/retrieval/chunking are
  identical between `v14` and `v15` (each domain's corpus and index are built independently), the
  only mechanism that can change generated responses for the *same* pubmedqa questions between
  these two runs is `temperature=0.2` sampling variance in `generate_response()`. This result is a
  concrete illustration of exactly the reliability problem that gap creates — worth fixing before
  drawing further firm conclusions from adherence specifically.
- **Decision for next config**: CONFIRMED with user (2026-07-14) — implement the missing `seed`
  parameter now, then re-test `v15`'s exact config to see if it reproduces closer to `v14`'s
  pubmedqa numbers.
  - **Fix applied**: added `seed: int = 42` to `Config`, passed to both `GROQ.create_chat_completion`
    calls in `generate_response()` (generator) and `_invoke_judge()` (judge). Every config
    registered from this point forward gets this by default.
  - **Proposed test**: registered `"v16"` = `v15`'s exact config (both domains,
    `chunk_size_chars=800`/`chunk_overlap_sentences=2`, MMR off, `"long"` prompt), now with the
    seed fix applied.
  - **What would confirm the seed was the cause**: `v16`'s pubmedqa numbers land much closer to
    `v14`'s (0.2815 / 0.1427 / 0.2247 / 0.9231) than `v15`'s did, especially adherence.
  - **What would falsify it**: `v16` still diverges from `v14` by a similar margin — would mean
    the seed wasn't the (or wasn't the only) source of the discrepancy, and something else
    changes between pubmedqa-only and both-domain runs.
  - **Registered as** `"v16"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v16"`.

### Iteration 19 — `"v16"` config (v15's config, with seed fix applied)
- **Status**: DONE (2026-07-14), but **interpretation corrected mid-analysis** — see below
- **Config**: `CONFIG_REGISTRY["v16"]` = identical overrides to `v15` (both domains, chunk
  800/2, MMR off, `"long"` prompt), now with `seed=42` on every Groq call.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2912 | 0.2556 | 0.4808 | 0.9643 |
  | pubmedqa | 15 | 0.2810 | 0.3250 | 0.3408 | **0.3846** |
  | ALL | 30 | 0.2861 | 0.2924 | 0.4167 | 0.5926 |

  pubmedqa comparison: `v14` (no seed) adh 0.9231 → `v15` (no seed) adh 0.8077 → `v16` (seed=42)
  adh **0.3846** — adherence got *worse*, not closer to `v14`. Checking the two persistent
  minority-class rows: **both nitinol and FMS are now wrong** (both flipped to pred=1.0≠gt=0) —
  the first time both have failed simultaneously since before the chunk-overlap fix (`v12`).

- **Correction to the original hypothesis framing**: on reflection, comparing `v16` (seed=42) to
  `v14`/`v15` (no seed at all) was the wrong test. `v14` and `v15` were never pinned to any
  particular random draw — they're each one arbitrary sample from an uncontrolled distribution.
  Setting `seed=42` doesn't retroactively reproduce whatever unpinned draw `v14` happened to land
  on; it only guarantees that **running this exact config again with the same seed reproduces
  IDENTICAL results going forward**. The dip vs. `v14` doesn't falsify the seed fix's actual
  purpose — it's just a new (but now-pinned) sample point, and `v14`'s better numbers were never
  a reliable "ground truth" to reproduce in the first place, only one lucky/unlucky draw among
  many possible ones.
- **The real test of whether the seed fix works**: re-run `v16`'s exact config again,
  unchanged, and confirm the results come back **identical** (or very close — Groq's `seed`
  parameter is documented as best-effort, not a bit-exact guarantee). If a second run of `v16`
  reproduces the same numbers, the fix is working as intended (future comparisons become
  trustworthy) even though this particular sample happens to show weak adherence. If a second run
  differs meaningfully, that would mean Groq's `seed` isn't being honored reliably for this model,
  which would be an important limitation to document.
- **Decision for next config**: not yet finalized with the user — re-run `v16` a second time,
  unchanged, specifically to test determinism rather than to compare against `v14`.

### Iteration 20 — `"v17"`/`"v17b"` config (context repacking) — first attempt hit a real bug
- **Status**: `v17` (first attempt) INVALID — real implementation bug, not a finding. `v17b`
  (fixed) registered, not yet run.
- **Config**: `v14`'s config (pubmedqa-only, chunk 800/2, MMR off, `"long"` prompt) +
  `repack_context=True` (reorder retrieved chunks so the most relevant sits closest to the
  question).
- **`v17`'s buggy result** (for the record, not a real finding): relevance 0.2670, utilization
  0.2610, completeness 0.3981, adherence 0.6154 — utilization/completeness/adherence all
  regressed sharply vs. `v14`.
- **Root cause found**: `generate_response()` reordered documents *locally* for its own prompt
  (so its response cites "[Doc N]" against the reversed order), but `judge_annotate()` was still
  called with the *original*, un-reversed `retrieval.documents` — so the generator's and Judge's
  "[Doc N]" labels referred to different documents. The Judge correctly couldn't verify claims
  attributed to the wrong document, producing mass false-negative adherence — an artifact of the
  bug, not a real quality signal about repacking.
- **Fix applied**: added `repack_documents(docs, cfg)`, called once in `run_domain_evaluation`
  before both `generate_response` and `judge_annotate`, so both always see the identical,
  consistently-labeled document order.
- **Re-registered as `"v17b"`** (not reusing `"v17"`) since checkpointing keys on config *values*,
  not code — no config field changed between the buggy and fixed versions, so reusing `"v17"`'s
  name would have silently resumed/reused the bug-affected cached rows instead of regenerating.
- **Decision for next config**: re-run `"v17b"` to get repacking's real result.

**`v17b` result (bug-fixed, valid):**

| domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
|---|---|---|---|---|---|
| pubmedqa / ALL | 15 | 0.2731 | 0.2462 | 0.3604 | 0.6346 |

vs. `v14` (no repacking) baseline: relevance 0.2815, utilization 0.1427, completeness 0.2247,
adherence 0.9231. Vs. noise band (~0.03-0.08 RMSE, ~0.06 AUCROC):

| metric | v14 → v17b | diff | within noise band? |
|---|---|---|---|
| relevance_rmse | 0.2815 → 0.2731 (slightly better) | 0.0084 | yes, comfortably |
| utilization_rmse | 0.1427 → 0.2462 (worse) | 0.1035 | **NO — exceeds noise band** |
| completeness_rmse | 0.2247 → 0.3604 (worse) | 0.1357 | **NO — exceeds noise band** |
| adherence_aucroc | 0.9231 → 0.6346 (worse) | 0.2885 | **NO — exceeds noise band** |

- **Observations**: **the hypothesis is FALSIFIED**, and clearly — this is a real result (labeling
  bug confirmed fixed; responses now correctly cite the same document order the Judge sees).
  Three of four metrics regressed well beyond the noise band. The new diagnostic fields
  (`pred_relevant_key_count`/`pred_total_valid_key_count`) reveal why: several rows show extreme
  relevance over-crediting — row 0 marks 17/18 context sentences relevant, row 4 marks 10/10
  (100%), row 8 marks 12/13, row 12 marks 15/16, row 13 marks 13/14. The Judge is treating nearly
  the *entire* retrieved context as relevant in multiple rows, far more extreme than in any prior
  config (including `v3`/`v6`, where the original over-crediting pattern was first flagged).
- **Inference**: this is a sharper, newly-mechanistic version of the relevance over-crediting
  pattern flagged since Iteration 3/6. Placing the single most relevant chunk immediately next to
  the question appears to make the Judge perceive the *entire* context block as more thematically
  unified, over-including almost every sentence as "relevant" rather than discriminating within
  the block. Since completeness's denominator is the relevant-set size, inflating it (without
  utilized keeping pace) directly drags completeness down — consistent with what's observed.
  Adherence also suffers, plausibly because a larger claimed-relevant set gives more surface area
  for at least one sentence to be judged unsupported. **Chunk ordering affects the Judge's
  relevance judgment, not just the generator's writing quality** — a genuinely new, presentable
  finding distinct from anything found earlier in the project (which focused on retrieval
  precision or generation verbosity, not presentation order).
- **Decision for next config**: CONFIRMED with user (2026-07-16) — `v14` (no repacking) remains
  the best config found; repacking is now closed out as a lever. Next: cross-domain validation of
  `v14`'s exact config, since this is the highest-value remaining step before treating `v14` as a
  final recommendation.
  - **Proposed test**: registered `"v18"` = `v14`'s exact config (chunk_size=800, overlap=2,
    MMR off, `"long"` prompt) + `domains=("covidqa", "pubmedqa")` — only field changed vs. `v14`.
    Fresh registration, so it benefits from the seed fix cleanly (no unpinned prior baseline to
    compare against).
  - **What we're checking**: does pubmedqa's portion of this run land close to `v14`'s numbers
    (0.2815 / 0.1427 / 0.2247 / 0.9231)? Is covidqa's completeness weakness still just its usual
    domain-specific pattern, not something this specific chunk config makes worse?
  - **Registered as** `"v18"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell). `ACTIVE_CONFIG_NAME` set to `"v18"`.

### Iteration 21 — `"v18"` config (v14's exact config, cross-domain validation)
- **Status**: DONE (2026-07-16) — **result confounded, see below before trusting it**
- **Config**: `CONFIG_REGISTRY["v18"]` = `v14`'s config (`generation_prompt_style="long"`,
  `use_mmr=False`, `chunking_strategy="sentence_window"`, `chunk_size_chars=800`,
  `chunk_overlap_sentences=2`) + `domains=("covidqa", "pubmedqa")` instead of pubmedqa-only.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3365 | 0.0957 | 0.4560 | 0.9286 |
  | pubmedqa | 15 | 0.3270 | 0.2149 | 0.3194 | 0.5577 |
  | ALL | 30 | 0.3318 | 0.1663 | 0.3937 | 0.7037 |

  pubmedqa comparison vs. `v14` (Iteration 17): relevance 0.2815, utilization 0.1427,
  completeness 0.2247, adherence 0.9231.

  | metric | v14 → v18 pubmedqa | diff | within noise band? |
  |---|---|---|---|
  | relevance_rmse | 0.2815 → 0.3270 | 0.0455 | yes |
  | utilization_rmse | 0.1427 → 0.2149 | 0.0722 | borderline, near upper edge |
  | completeness_rmse | 0.2247 → 0.3194 | 0.0947 | **NO — exceeds noise band** |
  | adherence_aucroc | 0.9231 → 0.5577 | 0.3654 | **NO — far exceeds noise band** |

- **⚠️ Confound identified before drawing conclusions**: `v14` was run *before* the `seed` fix
  existed (an unpinned, arbitrary draw). `v18` is a *fresh registration*, so it's the first run of
  this exact chunk config that actually has `seed=42` applied. That means this comparison
  conflates TWO variables at once — (a) domain scope (pubmedqa-only vs. both domains) and (b)
  seed/determinism status (unseeded vs. seeded) — exactly the ambiguity flagged as unresolved
  after Iteration 19. We cannot yet tell whether `v18`'s worse pubmedqa numbers come from
  including covidqa, or from this simply being a different (now-pinned) random draw than `v14`
  was.
- **Observations** (row-level, for reference once the confound is resolved): checking the two
  persistent minority-class rows (nitinol, FMS) — nitinol is wrong again (pred=1.0≠gt=0, matching
  its pattern since `v8`), but FMS is correctly classified (pred=0.0=gt=0). The larger adherence
  drop comes from **5 new false negatives on majority-class rows** (contact-lens-economics,
  disability-pension, clopidogrel-BMI, blood-donation, mixed-chimerism questions) — a similar
  shape to `v15`'s earlier confound, but with more affected rows this time.
- **Inference**: cannot be drawn cleanly yet — see confound above.
- **Decision for next config**: CONFIRMED with user (2026-07-16) — register a pubmedqa-only,
  seeded re-run of `v14`'s exact config to isolate the domain-scope variable cleanly.
  - **Registered as** `"v14b"` in `CONFIG_DEFINITIONS` (`RAG_Pipeline_v2.ipynb`, config registry
    cell): `v14`'s exact config (`generation_prompt_style="long"`, `use_mmr=False`,
    `chunking_strategy="sentence_window"`, `chunk_size_chars=800`, `chunk_overlap_sentences=2`,
    `domains=("pubmedqa",)`), as a fresh registration so it inherits `seed=42`.
    `ACTIVE_CONFIG_NAME` set to `"v14b"`.
  - **What this resolves**: `v14b` vs. `v18`'s pubmedqa portion is now a fair, same-seed
    comparison — isolating whether including covidqa in the same run actually changes pubmedqa's
    results, independent of the seed/determinism confound.
  - **What would confirm cross-domain interaction is real**: `v14b` reproduces close to `v14`'s
    original numbers (0.2815 / 0.1427 / 0.2247 / 0.9231), meaning `v18`'s worse pubmedqa numbers
    are genuinely caused by covidqa's presence in the same run.
  - **What would falsify it**: `v14b` itself lands close to `v18`'s pubmedqa numbers (worse than
    `v14`'s original) — meaning the difference was just seed/sampling variance all along, not a
    cross-domain effect, and `v14`'s original excellent numbers were themselves a favorable draw.

### Iteration 22 — `"v14b"` config (v14's exact config, pubmedqa-only, seeded)
- **Status**: DONE (2026-07-17) — **major finding: resolves the confound, and revises the
  project's leading result**
- **Config**: `CONFIG_REGISTRY["v14b"]` = identical fields to `v14` (chunk_size=800, overlap=2,
  MMR off, `"long"` prompt, pubmedqa-only), now with `seed=42` applied via fresh registration.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.3104 | 0.2714 | 0.2977 | 0.5577 |

  Three-way comparison:

  | metric | `v14` (unseeded) | `v18` pubmedqa row (seeded, both domains) | `v14b` (seeded, pubmedqa-only) |
  |---|---|---|---|---|
  | relevance_rmse | 0.2815 | 0.3270 | 0.3104 |
  | utilization_rmse | 0.1427 | 0.2149 | 0.2714 |
  | completeness_rmse | 0.2247 | 0.3194 | 0.2977 |
  | adherence_aucroc | **0.9231** | 0.5577 | **0.5577** |

- **Observations**: **`v14b`'s adherence (0.5577) exactly matches `v18`'s pubmedqa adherence
  (0.5577) to four decimal places.** Relevance/utilization/completeness are also close between
  `v14b` and `v18`'s pubmedqa row (within/near the noise band), consistent with pubmedqa's
  corpus/retrieval being built independently of whether covidqa is also in the run.
- **Inference — the confound is resolved, and the conclusion reverses**: the exact adherence
  match proves **domain scope has no effect on pubmedqa's results under this config** — `v18`'s
  apparent cross-domain regression was never a real interaction effect. Instead, **`v14`'s
  spectacular original numbers (adherence 0.9231) were themselves a lucky, unpinned random draw
  — not the true, reproducible performance of this config.** With `seed=42` locked in, this exact
  chunk_size=800/overlap=2 configuration's real adherence is ~0.56, not ~0.92. This is a
  significant, humbling revision: the project's "best result" claim for `v14` needs to be
  retracted as stated — it was measuring noise, not a real property of the configuration.
  **This is also the clearest possible demonstration of why the seed fix mattered**: without it,
  we would have confidently reported a config as the best of the whole project based on one
  favorable coin-flip.
- **Decision for next config**: not yet finalized with the user. Given this revision, all of the
  project's earlier "best config" claims that predate the seed fix (`baseline` through `v13`/`v14`)
  are now suspect to the same degree — they were never controlled for this source of variance.
  Practically, re-running everything with a fixed seed is not feasible given remaining time/token
  budget. The most valuable next step is likely re-running `v8` (the strongest *pre-chunking*
  config, and the second-best claim in the project) with the seed fix, to get at least one other
  reliable, reproducible number to compare `v14b`'s 0.5577 against — determining whether chunking
  still helps at all once measured fairly, or whether that conclusion also needs revision.

### Iteration 23 — `"v8b"` config (v8's exact config, whole-document retrieval, seeded)

- **Status**: DONE (2026-07-17) — **major finding: chunking's earlier "win" over whole-document
  retrieval does not survive seed control.**
- **Config**: `CONFIG_REGISTRY["v8b"]` = identical fields to `v8` (whole-document retrieval, no
  chunking, `use_mmr=False`, `"long"` prompt, pubmedqa-only), now with `seed=42` applied via
  fresh registration.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.3033 | 0.2057 | 0.2632 | 0.6731 |

  Comparison against `v14b` (chunked, chunk_size=800/overlap=2, also seeded):

  | metric | `v14b` (chunked) | `v8b` (whole-doc) | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.3104 | 0.3033 | 0.0071 | yes |
  | utilization_rmse | 0.2714 | 0.2057 | 0.0657 | borderline/exceeds |
  | completeness_rmse | 0.2977 | 0.2632 | 0.0346 | yes |
  | adherence_aucroc | 0.5577 | 0.6731 | 0.1154 | **no — real, `v8b` wins** |

- **Observations** (row-level): nitinol (row 1) is still misclassified (pred=1.0 vs gt=0.0) —
  the same persistent minority-class error seen since `v8`'s original run. FMS (row 9) is now
  correctly classified (pred=0.0=gt=0.0), matching `v18`'s pattern rather than earlier
  misclassifications. The two false negatives among majority-class rows (blood-mobile-app-style
  row 9, mixed-chimerism row 14, both pred=0.0 vs gt=1.0) are fewer than `v14b` showed, which is
  the direct source of `v8b`'s adherence advantage.
- **Inference**: with the seed confound removed from both sides, whole-document retrieval
  (`v8b`) **beats** chunking (`v14b`) outright on adherence (a real, noise-band-exceeding
  difference) and utilization, while relevance and completeness are statistically tied. This
  reverses the Iteration 15–17 conclusion that chunking (specifically chunk_size=800/overlap=2)
  fixes an adherence weakness in whole-document retrieval — that earlier comparison (`v12`→`v13`→
  `v14`) was itself never seed-controlled, so the apparent chunking benefit was likely built on
  the same kind of favorable/unfavorable draw asymmetry that inflated `v14`'s original number.
  **Chunking as a lever should now be considered unproven, not confirmed**, pending the user's
  input on whether further seed-controlled reruns of the chunking sweep are worth the remaining
  time/token budget.
- **Decision for next config**: not yet finalized with the user — this result reopens the
  question of which config to present as the project's final recommendation. Candidates worth
  weighing: (a) treat `v8b` (whole-document, seeded) as the new leading config given this direct,
  fair comparison; (b) run one more seed-controlled chunking variant (e.g. re-test `v13`'s
  1200/2 config fresh-seeded) before fully retiring chunking as a lever, since only one chunk
  size (800/2) has been tested under a fixed seed so far; (c) stop the sweep here given
  time/token constraints and write up `v8b` vs `v14b` as a documented, deliberately-surfaced
  limitation (seed sensitivity) rather than chasing a further-refined "best config."

### Iteration 24 — `"v13b"` config (v13's exact config, chunk_size=1200/overlap=2, seeded)

- **Status**: DONE (2026-07-17) — **closes out the chunking lever: chunking is falsified as a
  net improvement over whole-document retrieval, under seed control, at both chunk sizes tested.**
- **Config**: `CONFIG_REGISTRY["v13b"]` = identical fields to `v13` (chunk_size=1200,
  overlap=2, pubmedqa-only), now with `seed=42` applied via fresh registration.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2724 | 0.2568 | 0.3496 | 0.5962 |

  Three-way comparison (all seeded, all pubmedqa-only, n=15):

  | metric | `v8b` (whole-doc) | `v14b` (chunk 800/2) | `v13b` (chunk 1200/2) |
  |---|---|---|---|---|
  | relevance_rmse | 0.3033 | 0.3104 | 0.2724 |
  | utilization_rmse | 0.2057 | 0.2714 | 0.2568 |
  | completeness_rmse | **0.2632** | 0.2977 | 0.3496 |
  | adherence_aucroc | **0.6731** | 0.5577 | 0.5962 |

- **Observations**: relevance is roughly tied across all three (within noise band).
  `v8b` wins completeness outright (`v13b`'s 0.3496 is 0.086 worse — exceeds the noise band) and
  wins adherence over both chunked variants (`v13b`'s 0.5962 is 0.077 worse — at/past the edge of
  the noise band; `v14b`'s 0.5577 is 0.115 worse — clearly exceeds it). Utilization is a mixed,
  smaller-magnitude picture (`v8b` best, but within-noise vs. `v13b`).
- **Inference**: with two different chunk sizes now tested under the same fixed seed, neither
  recovers an adherence or completeness advantage over whole-document retrieval. The
  Iteration 15–17 "chunking fixes adherence" narrative does not survive seed control at all —
  it was built entirely on unpinned-seed comparisons. **`v8b` (whole-document retrieval,
  pubmedqa-only, `use_mmr=False`, `"long"` prompt, seed=42) is now the project's best-supported
  config**, the only one that has been directly, fairly (same-seed) compared against real
  alternatives and won.
- **Decision for next config**: CONFIRMED with user (2026-07-17) — this closes the chunking
  sweep. `v8b` stands as the leading recommended configuration for the final write-up. The
  seed-confound discovery (Iterations 19–24) itself becomes a first-class finding: it reverses
  two previously-reported "best results" (`v14`, then implicitly the whole chunking direction)
  and should be presented as a methodological lesson, not just a footnote.

### Iteration 25 — `"v8c"` config (v8b + MMR on, seeded)

- **Status**: DONE (2026-07-18) — **major finding: MMR is a real, substantial win, not noise. New
  leading config.**
- **Config**: `CONFIG_REGISTRY["v8c"]` = identical to `v8b` (whole-document retrieval,
  pubmedqa-only, `"long"` prompt, seed=42), only `use_mmr=True` changed. `top_k_final` unchanged
  at 5 (token-neutral vs. `v8b`).
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.2756 | 0.1211 | 0.2417 | 0.9231 |

  Comparison against `v8b` (MMR off, otherwise identical):

  | metric | `v8b` (MMR off) | `v8c` (MMR on) | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.3033 | 0.2756 | 0.0277 | yes |
  | utilization_rmse | 0.2057 | 0.1211 | 0.0846 | **no — real, v8c wins** |
  | completeness_rmse | 0.2632 | 0.2417 | 0.0215 | yes |
  | adherence_aucroc | 0.6731 | **0.9231** | 0.25 | **no — far exceeds, v8c wins** |

- **Observations** (row-level): of 13 ground-truth-positive-adherence rows, `v8c` misclassifies
  only 2 (rows 4, 12 — both false negatives), down from 5 false negatives in `v8b`. Both
  ground-truth-negative rows (1, 9) remain correctly classified. The AUCROC of 0.9231 arises from
  a real ranking improvement (11/13 positives correctly separated from both negatives), not a
  degenerate/small-sample artifact — confirmed by hand-checking the binary AUCROC formula against
  the row-level predictions.
- **Inference**: the completeness-via-diversity hypothesis (Iteration 24's decision) is
  confirmed in direction and, unexpectedly, adherence and utilization improved far more than
  completeness itself. Plausible mechanism: MMR's diversity-traded document selection pulls in
  less redundant/overlapping content among the top-5 documents, giving the generator less
  repetitive context to synthesize from and fewer opportunities to produce claims that drift from
  what's actually stated — which shows up as better adherence, not just better completeness as
  originally hypothesized. This is the first lever in the whole project (across both the
  unseeded and seeded phases) to produce a large, noise-band-exceeding improvement on adherence
  AND utilization simultaneously, with no metric regressing.
- **Decision for next config**: not yet finalized with the user. `v8c` is now the project's
  best-supported config, seed-controlled, beating every other seeded candidate (`v8b`, `v14b`,
  `v13b`) outright on at least one metric with no regressions. Given this real, sizeable effect,
  worth considering one more test: does MMR's benefit compound with chunking (`v14b`/`v13b` +
  `use_mmr=True`), or was chunking's earlier underperformance itself partly attributable to
  lacking MMR? Alternatively, treat `v8c` as final and close the sweep here, given time budget.

### Iteration 26 — `"v14c"` config (v14b + MMR on, seeded)

- **Status**: DONE (2026-07-18) — **falsifies the MMR/chunking compounding hypothesis. v8c
  remains the best config by a wide margin.**
- **Config**: `CONFIG_REGISTRY["v14c"]` = identical to `v14b` (chunk_size=800, overlap=2,
  pubmedqa-only, seed=42), only `use_mmr=True` changed.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.3281 | 0.1686 | 0.2532 | 0.5962 |

  Three-way comparison (all seeded, pubmedqa-only, n=15):

  | metric | `v8c` (whole-doc + MMR) | `v14b` (chunked, no MMR) | `v14c` (chunked + MMR) |
  |---|---|---|---|---|
  | relevance_rmse | 0.2756 | 0.3104 | 0.3281 |
  | utilization_rmse | **0.1211** | 0.2714 | 0.1686 |
  | completeness_rmse | **0.2417** | 0.2977 | 0.2532 |
  | adherence_aucroc | **0.9231** | 0.5577 | 0.5962 |

- **Observations**: MMR does move `v14c`'s utilization and completeness in the right direction
  relative to `v14b` (utilization improves by 0.1028, exceeds noise band; completeness improves
  by 0.0445, within/borderline noise band), confirming MMR's redundancy-reduction mechanism
  applies somewhat to chunked retrieval too. But adherence barely moves (0.5577 -> 0.5962, a
  0.0385 shift, within noise band) — nowhere close to `v8c`'s 0.9231. Relevance is essentially
  unchanged/slightly worse.
- **Inference**: chunking's adherence weakness is **not** explained by lacking MMR — it persists
  almost unchanged even with MMR applied on top of chunks. This means whole-document retrieval
  has some property (likely: complete, self-contained document context lets the generator make
  claims it can fully ground, whereas isolated chunks — even diverse, non-redundant ones — strip
  away surrounding context the generator needs to stay strictly grounded) that chunking does not
  replicate regardless of document-selection strategy. **`v8c` (whole-document retrieval + MMR,
  pubmedqa-only, seed=42) is confirmed as the project's best config**, and chunking as a lever is
  now closed out with high confidence (tested at 2 chunk sizes, with and without MMR, all seeded).
- **Decision for next config**: not yet finalized with the user. Relevance (0.2756) and
  completeness (0.2417) remain the two weakest metrics of `v8c` even after MMR's large adherence/
  utilization win. Per the persistent, cross-iteration observation (since Iteration 3) that the
  Judge's relevance annotations look systematically over-liberal, the next most promising
  untested lever for relevance/completeness specifically may need to target retrieval precision
  itself (e.g., `top_k_final` reduced below 5 to force stricter selection) rather than repeating
  document-selection-strategy or chunking variations, both of which are now reasonably
  well-explored.

### Iteration 28 — `"v8e"` config (v8c + both domains, seeded) — NOTE: logged out of order,
before Iteration 27, since this was run and analyzed first; see Iteration 27 below for the
top_k_final=3 test that was proposed earlier but pasted back after this one.

- **Status**: DONE (2026-07-18) — **cross-domain check: adherence generalizes well to covidqa,
  completeness does not.** Also uncovered and fixed a real bug: the first scoreboard pasted for
  this run was stale (byte-identical to `v8d`'s cached numbers), traced to the scoreboard cell
  not having been re-run against the fresh `results_df`. Corrected after re-running that cell.
- **Config**: `CONFIG_REGISTRY["v8e"]` = identical to `v8c` (whole-document + MMR, `"long"`
  prompt, seed=42), only `domains` widened to `("covidqa", "pubmedqa")`.
- **Also discovered a re-run-order bug**: switching a config's `domains` from single- to
  multi-domain requires re-running the "Load RAGBench" cell (builds `RAW_ROWS` keyed by
  `CONFIG.domains`), not just Ingestion onward — `RAW_ROWS`/`CORPUS`/`INDEXES` are all keyed by
  domain and only populated for whatever `CONFIG.domains` was when each cell last ran. Missing
  this caused a `KeyError: 'covidqa'` on the Retriever cell initially.
- **Results** (corrected, post-fix):

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3665 | 0.0880 | **0.5211** | 0.8929 |
  | pubmedqa | 15 | 0.2670 | 0.1914 | 0.2182 | 0.8462 |
  | ALL | 30 | 0.3206 | 0.1490 | 0.3994 | 0.8704 |

  pubmedqa portion vs. `v8c` (pubmedqa-only, otherwise identical):

  | metric | `v8c` (pubmedqa-only) | `v8e` pubmedqa portion | diff |
  |---|---|---|---|
  | relevance_rmse | 0.2756 | 0.2670 | 0.0086 (within noise) |
  | utilization_rmse | 0.1211 | 0.1914 | 0.0703 (borderline/exceeds) |
  | completeness_rmse | 0.2417 | 0.2182 | 0.0235 (within noise) |
  | adherence_aucroc | 0.9231 | 0.8462 | 0.0769 (borderline/exceeds) |

- **Observations**: unlike the earlier clean `v14b`/`v18` domain-independence finding (where
  pubmedqa's adherence matched to 4 decimal places across single- and both-domain runs), `v8e`'s
  pubmedqa rows are NOT byte-identical to `v8c`'s (e.g. row "Are prostate biopsies mandatory..."
  has pred_relevance 0.5 in `v8e` vs 0.9167 in `v8c`, both with the same `total_valid_key_count`
  of 12) — a real, if modest, run-to-run difference despite the fixed seed. Most plausible cause:
  the cross-encoder reranker's floating-point inference order/batching can differ slightly
  depending on what else is being processed in the same session, shifting borderline document
  rankings; this is a smaller-magnitude nondeterminism than the temperature-driven one fixed
  earlier, and both utilization and adherence diffs are close to (not dramatically beyond) the
  noise band. covidqa's completeness (0.5211) is dramatically worse than pubmedqa's (0.2182) — a
  large, real, domain-specific gap.
- **Inference**: `v8c`'s adherence improvement (from MMR) generalizes reasonably well to covidqa
  (0.8929, still strong), but its completeness does not — covidqa's completeness weakness
  (flagged as a domain-specific pattern since Iteration 3) persists even under the best
  seed-controlled config found so far. This suggests covidqa's completeness problem is a
  domain-level property (likely: covidqa's ground-truth relevant-sentence sets are structured
  differently, or its documents/questions have different content density) that config-level RAG
  levers tried so far don't touch.
- **Decision for next config**: not yet finalized with the user. `v8c` (pubmedqa-only) remains
  the strongest single-domain result; `v8e` establishes that a real, best-effort cross-domain
  config lands around 0.32/0.15/0.40/0.87 pooled. Whether to keep chasing pubmedqa-only
  refinements or invest in covidqa-specific completeness diagnosis is an open call for the user.

### Iteration 29 — `"v8f"` config (v8e's covidqa slice + chunking, seeded)

- **Status**: DONE (2026-07-18) — **inconclusive: the mechanism didn't engage as hypothesized, so
  this neither confirms nor cleanly falsifies "chunking helps long-document domains."**
- **Config**: `CONFIG_REGISTRY["v8f"]` = `v8e`'s config restricted to `domains=("covidqa",)`, +
  `chunking_strategy="sentence_window"`, `chunk_size_chars=800`, `chunk_overlap_sentences=2`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3377 | 0.1005 | 0.4835 | 0.8571 |

  Comparison against `v8e`'s covidqa slice (whole-document, otherwise identical):

  | metric | `v8e` covidqa (whole-doc) | `v8f` (chunked 800/2) | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.3665 | 0.3377 | 0.029 (better) | yes |
  | utilization_rmse | 0.0880 | 0.1005 | 0.013 (worse) | yes |
  | completeness_rmse | 0.5211 | 0.4835 | 0.038 (better) | yes, at the edge |
  | adherence_aucroc | 0.8929 | 0.8571 | 0.036 (worse) | yes |

- **Observations**: `pred_total_valid_key_count` (the retrieved-context sentence pool size) is
  essentially unchanged — 18-25 in `v8f` vs. 17-26 in `v8e` — despite chunking being applied.
  This means the hypothesized mechanism (shrinking the sentence pool per retrieved unit) never
  actually engaged: 5 selected 800-char chunks apparently sum to roughly as much content as 5
  whole covidqa documents, implying covidqa's documents aren't dramatically longer than a
  handful of 800-char chunks once MMR selects diverse spans, or multiple chunks from the same
  source document got selected together.
- **Inference**: this test doesn't cleanly confirm or falsify the "long-document domain benefits
  from chunking" hypothesis — it mostly shows `chunk_size_chars=800` wasn't a small enough
  setting to meaningfully shrink covidqa's sentence pool. All four metric diffs stay within the
  noise band, so no real effect (positive or negative) was detected either way.
- **Decision for next config**: not yet finalized with the user. To properly test the
  long-document hypothesis, a much smaller chunk size (e.g. 300-400 chars) would be needed to
  actually shrink covidqa's per-unit sentence pool meaningfully — the current test used the same
  chunk size that was tuned for pubmedqa's shorter documents, which may not transfer as a
  meaningful test unit for covidqa's longer ones.

### Iteration 27 — `"v8d"` config (v8c + top_k_final=3, seeded)

- **Status**: DONE (2026-07-18) — **sharply falsified. Narrowing top_k_final backfired on every
  metric, adherence collapsed below random.**
- **Config**: `CONFIG_REGISTRY["v8d"]` = identical to `v8c` (whole-document + MMR, pubmedqa-only,
  seed=42), only `top_k_final` reduced from 5 to 3.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | pubmedqa / ALL | 15 | 0.3686 | 0.3001 | 0.2864 | 0.3462 |

  Comparison against `v8c` (top_k_final=5, otherwise identical):

  | metric | `v8c` (top_k=5) | `v8d` (top_k=3) | diff |
  |---|---|---|---|
  | relevance_rmse | 0.2756 | 0.3686 | 0.093 (worse) |
  | utilization_rmse | 0.1211 | 0.3001 | 0.179 (far worse) |
  | completeness_rmse | 0.2417 | 0.2864 | 0.045 (worse) |
  | adherence_aucroc | **0.9231** | **0.3462** | 0.577 (catastrophic — below 0.5, worse than
    random guessing) |

- **Observations**: every metric regressed, several far beyond the noise band. Adherence's
  collapse to 0.3462 (below random) is qualitatively different from prior regressions (`v10`,
  `v11`, `v15`) which stayed above 0.5 — here the Judge's supported/unsupported calls are actively
  anti-correlated with ground truth. `pred_total_valid_key_count` (the ground-truth sentence pool
  size) is also visibly smaller per row than in `v8c` (e.g. row 0: 12 vs 18; row 5: 5 vs 12),
  confirming fewer documents were retrieved/considered, shrinking the context available to both
  generator and Judge.
- **Inference**: the "stricter selection reduces over-crediting" hypothesis is decisively
  falsified — the opposite happened. With only 3 documents, the generator more often lacks the
  actual supporting content, forcing either more hedged non-answers (inflating relevance/
  completeness noise) or claims not grounded in the shrunken context (collapsing adherence).
  `top_k_final=5` (as in `v8c`) is not just adequate but appears to be a genuine sweet spot for
  this pipeline — the same direction of change that helped at the wider end (`v10`'s
  `top_k_final=10`, pre-seed) also failed, so `top_k` appears to have a narrow effective range in
  both directions.
- **Decision for next config**: not yet finalized with the user. `v8c` remains the confirmed best
  config; `top_k_final` should not be adjusted from 5 in either direction based on current
  evidence. Remaining untested levers for relevance/completeness specifically: (a) domain-adapted
  embedding/reranker models, now re-testable under seed control (previously showed a real
  negative interaction pre-seed, `v3`/`v5`/`v6`, but never confirmed post-seed-fix); (b) a
  completeness-focused prompt-content change (new `GENERATION_PROMPTS` entry instructing the
  generator to address every piece of relevant retrieved content); (c) accepting that the Judge's
  over-liberal relevance-crediting (flagged since Iteration 3) is an annotation-level ceiling that
  generation/retrieval-side levers cannot fix, and documenting it as a limitation instead.

---

## Open Questions / Parking Lot

*(Anything raised mid-experiment that needs revisiting before the final write-up goes here.)*

- **Adherence AUCROC is unreliable as a cross-config comparison metric at current sample sizes**
  (found in Iteration 3, `baseline_n15`): ground-truth `gt_adherence` is heavily class-imbalanced
  (only 3/30 rows negative in the n=15 run), and `compute_trace_metrics` returns predicted
  adherence as a strict boolean, not a continuous score — so AUCROC swings 0.2–0.3+ on just 1-2
  misclassified minority-class rows. Deliberately not fixed yet (would be its own config change
  deserving its own hypothesis/test cycle). Candidate fixes for later, if time allows: have the
  Judge emit a continuous support-confidence score instead of a boolean `fully_supported`; or
  deliberately raise sample size further/oversample toward more negative-class examples. Worth
  stating explicitly as a methodological limitation in the final presentation regardless of
  whether it gets fixed.
- **Judge relevance annotations look systematically more liberal than RAGBench's own ground
  truth** (found in Iteration 3): a repeatable, directional overshoot pattern, not scattered
  noise — candidate for a real, worth-investigating finding once the current prompt-style
  comparison (`v1.1` vs `baseline_n15`) is resolved.

### Iteration 30 — `"v8g"` config (v8e covidqa + chunk_size=300, overlap=2, MMR on, seeded)

- **Status**: DONE (2026-07-28) — **hypothesis partially confirmed, but same completeness-adherence tradeoff as pubmedqa chunking.**
- **Config**: `CONFIG_REGISTRY["v8g"]` = covidqa-only, `chunking_strategy="sentence_window"`,
  `chunk_size_chars=300`, `chunk_overlap_sentences=2`, `use_mmr=True`, `seed=42`.
  (v8f used chunk_size=800 and was inconclusive; this re-tests at 300 to actually engage splitting.)
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3873 | 0.1887 | 0.4019 | 0.3929 |

  Comparison against `v8e` covidqa slice (whole-doc) and `v8f` (chunk 800/2):

  | metric | `v8e` covidqa (whole-doc) | `v8f` (chunk 800/2) | `v8g` (chunk 300/2) | trend |
  |---|---|---|---|---|
  | relevance_rmse | 0.3665 | 0.3377 | 0.3873 | worse than both |
  | utilization_rmse | 0.0880 | 0.1005 | 0.1887 | worse than both |
  | completeness_rmse | 0.5211 | 0.4835 | **0.4019** | monotonically improving ✓ |
  | adherence_aucroc | 0.8929 | 0.8571 | **0.3929** | collapsed below random ✗ |

- **Observations**:
  - Completeness improvement is real and monotonic across chunk sizes: 0.5211 (whole-doc) → 0.4835
    (800-char) → 0.4019 (300-char). Difference from v8e to v8g is 0.12 RMSE — well beyond the noise
    band. This confirms the hypothesis: smaller chunks do shrink the sentence pool per retrieved unit,
    reducing the number of "relevant" sentences the generator can't cover.
  - Adherence collapsed to 0.3929 (below random). Row-level analysis: rows 3, 12, 14 (all gt=1,
    pred=0 — false negatives) drove the collapse. Row 14 is the clearest case — 12/13 sentences
    marked relevant, response well-grounded, but Judge cannot verify specific claims against the
    narrow 300-char chunk windows. This is the same chunk-boundary recall loss pattern that
    appeared when chunking was applied to pubmedqa (v12/v14b).
  - Row 0 (gt=0, pred=1) is a false positive: generator correctly said "documents are missing"
    (a vacuous non-answer), which the Judge marks as supported — yet ground-truth says not
    adherent. This is a ground-truth annotation ambiguity, not a retrieval failure.
  - Utilization got notably worse (0.0880 → 0.1887): with 300-char chunks, the generator still
    produces full answers but the Judge can only "see" narrow windows of the retrieved content,
    so fewer utilized sentences get matched. This is a direct artifact of the narrow chunk window.

- **Inference**: the completeness-adherence tradeoff for covidqa is structural, not a tuning issue.
  Smaller chunks do reduce the sentence pool (confirming the long-document hypothesis), but they
  also introduce chunk-boundary recall loss that collapses adherence. The tradeoff tightens as
  chunk size decreases: adherence was fine at 800-char chunks (same as whole-doc) but catastrophic
  at 300-char chunks. There is no sweet-spot chunk size that simultaneously improves completeness
  significantly AND preserves adherence. Chunking as a lever for covidqa is now falsified.

  The remaining unblocked lever for covidqa completeness — without implementation changes — is
  a **completeness-focused generator prompt**: a new `GENERATION_PROMPTS["long_completeness"]`
  entry that explicitly instructs the generator to address every relevant piece of retrieved
  content. This operates upstream of the sentence-pool problem (making the generator cover more,
  not shrinking the pool), and does not introduce chunk-boundary recall loss. Base config reverts
  to whole-document retrieval (v8c/v8e settings) to isolate the prompt effect cleanly.

- **Decision for next config**: `v8i` — `generation_prompt_style="long_completeness"`, whole-doc
  retrieval (no chunking), MMR on, covidqa-only, seed=42.

### Iteration 31 — `"v8j"` config (covidqa, whole-doc, MMR on, mmr_lambda=0.3, seeded)

- **Status**: DONE (2026-07-28) — **falsified. More diversity made every metric worse.**
- **Config**: `CONFIG_REGISTRY["v8j"]` = covidqa-only, whole-doc, `use_mmr=True`,
  `mmr_lambda=0.3` (down from default 0.5), `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3725 | 0.2192 | 0.5433 | 0.8214 |

  Comparison against `v8e` covidqa slice (mmr_lambda=0.5, baseline):

  | metric | `v8e` covidqa (λ=0.5) | `v8j` (λ=0.3) | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.3665 | 0.3725 | +0.006 (worse) | yes |
  | utilization_rmse | 0.0880 | 0.2192 | +0.131 (worse) | NO — far outside band |
  | completeness_rmse | 0.5211 | 0.5433 | +0.022 (worse) | yes |
  | adherence_aucroc | 0.8929 | 0.8214 | −0.072 (worse) | at edge |

- **Observations**:
  - `pred_total_valid_key_count` (sentence pool size) is larger in v8j than v8e: rows average
    ~20-25 sentences vs ~13-26 in v8e. More diversity pulled in documents covering more
    sub-topics, each adding sentences, which expanded rather than contracted the pool.
  - Six rows have `pred_adherence=0` with `gt_adherence=1` (rows 0, 4, 8, 9, 10, 12) — the
    more diverse document set introduced off-topic content that the generator partially synthesized
    across, making claims the Judge couldn't verify against the specific chunks shown.
  - Utilization collapsed most severely (+0.131 RMSE): with more diverse docs, a larger fraction
    of retrieved sentences were irrelevant to the question, so the generator used less of what
    was retrieved.

- **Inference**: the "more diversity → smaller per-question relevant pool" hypothesis was wrong.
  Lower mmr_lambda pulls in topically varied documents, but for covidqa's multi-faceted questions
  this adds more sentences total (from more topics) rather than reducing the relevant subset. The
  Judge then marks sentences across multiple topics as relevant, making the pool harder to cover,
  not easier. The only direction that could possibly help is higher lambda (more relevance focus)
  — but given that the structural problem is the Judge's over-liberal crediting of long documents,
  not the topical spread, there is no strong prior that mmr_lambda=0.7 would behave differently
  enough to change the conclusion.

- **Decision**: `mmr_lambda` is now falsified as a completeness lever for covidqa. All tested
  levers — chunking, mmr_lambda, top_k adjustments (earlier iterations) — have either regressed
  adherence or left completeness unchanged. Generator and judge prompts are off-limits. The
  covidqa completeness gap (~0.52 RMSE vs pubmedqa's ~0.24) is a structural limitation of this
  pipeline on longer-document domains: more sentences per document → Judge over-credits more
  "relevant" keys → generator cannot cover them all. This should be documented as a finding, not
  treated as a tunable gap. **`v8e` (whole-doc, MMR on, both domains, seed=42) stands as the
  best cross-domain config.**

---

## Final Summary — Best Configs and Key Findings

### Best Configurations

**Best pubmedqa config: `v8c`** (Iteration 25, 2026-07-18)

| metric | value |
|--------|-------|
| context_relevance RMSE | 0.2756 |
| context_utilization RMSE | 0.1211 |
| completeness RMSE | 0.2417 |
| adherence AUCROC | 0.9231 |

Settings: whole-document retrieval, `use_mmr=True`, `mmr_lambda=0.5`, `top_k_final=5`,
`generation_prompt_style="long"`, `seed=42`, pubmedqa-only.

**Best covidqa config (seeded): `v8e` covidqa slice** (Iteration 28, 2026-07-18)

| metric | value |
|--------|-------|
| context_relevance RMSE | 0.3665 |
| context_utilization RMSE | 0.0880 |
| completeness RMSE | 0.5211 |
| adherence AUCROC | 0.8929 |

Settings: identical to `v8c` but with `domains=("covidqa", "pubmedqa")`.

**Best cross-domain config: `v8e`** (both domains, same settings as `v8c`)

| domain | rel RMSE | util RMSE | comp RMSE | adh AUCROC |
|--------|----------|-----------|-----------|------------|
| pubmedqa | 0.2756 | 0.1211 | 0.2417 | 0.9231 |
| covidqa | 0.3665 | 0.0880 | 0.5211 | 0.8929 |
| ALL (pooled) | 0.3206 | 0.1490 | 0.3994 | 0.8704 |

---

### Key Findings (for capstone presentation)

**1. MMR is the single most impactful lever** (Iterations 23–25)
Turning on `use_mmr=True` (at default `mmr_lambda=0.5`) was the largest single improvement in
the entire experiment: adherence jumped from 0.6731 → 0.9231 (+0.25 AUCROC) and utilization
improved from 0.2057 → 0.1211 RMSE. All other levers produced smaller or negative effects.
MMR reduces redundancy in the retrieved document set, which gives the generator a more complete
and non-repetitive context to draw from — directly benefiting adherence and utilization.

**2. Chunking helps completeness but kills adherence — and this effect is domain-independent**
(Iterations 12–26, 30)
Sentence-window chunking was tested at three chunk sizes (500, 800, 1200 chars for pubmedqa;
300, 800 for covidqa) and under seed control. In every seeded test, chunking improved completeness
at the cost of adherence via chunk-boundary recall loss: the generator makes claims supported by
sentences that end up in non-retrieved chunks, which the Judge cannot verify. The tradeoff
tightens as chunk size decreases. Whole-document retrieval at `top_k_final=5` is consistently
better for adherence; chunking is consistently worse.

**3. Reproducibility requires seeded LLM calls** (Iterations 19–22)
Before `seed=42` was added to Groq calls, apparent improvements across iterations were partly
noise from generator non-determinism at `temperature=0.2`. Adding `seed=42` to both generator
and judge calls eliminated this confound and revealed that several pre-seed results (including
v14's apparent best-in-class adherence) were lucky draws, not reproducible properties of those
configs. Every meaningful config re-tested post-seed gave different results than its pre-seed
version.

**4. covidqa completeness is structurally harder than pubmedqa** (Iterations 28–31)
The covidqa completeness gap (RMSE ~0.52 vs pubmedqa's ~0.24) is not a tuning artifact. covidqa
documents are longer (mean ~582 chars vs pubmedqa's shorter passages), which creates a larger
sentence pool per retrieved document. The RAGBench Judge over-credits more sentences as "relevant"
for longer-document questions, but the generator's answer can only cover a fraction of them —
mechanically inflating completeness RMSE. No retrieval-side parameter (chunking, top_k, mmr_lambda)
fixed this within the pipeline's constraints; the root cause is at the annotation level.

**5. Narrowing top_k_final below 5 is consistently harmful** (Iterations 12, 27)
Both `top_k_final=3` (v8d) and `top_k_final=10` (v10) caused adherence collapse — in opposite
directions for different reasons. `top_k=3` starves the generator of supporting content; `top_k=10`
floods it with too much context for the Judge to attribute claims precisely. `top_k_final=5` is
the empirically validated sweet spot for this pipeline.

**6. Domain-adapted models regress under controlled conditions** (Iterations 6–9)
PubMedBERT embeddings and MedCPT cross-encoder reranker, tested both together (v3) and in
isolation (v5, v6), consistently underperformed the general-purpose BAAI/bge-small-en-v1.5 +
ms-marco-MiniLM-L-6-v2 stack. When domain-adapted components were combined, they interacted
negatively rather than additively. This suggests the general-purpose components are better
calibrated for RAGBench's specific question format, which is not purely biomedical literature
retrieval.

---

### Levers Tested and Their Verdict

| Lever | Verdict |
|-------|---------|
| Generation prompt style (long vs long_cot) | Marginal; "long" slightly better than long_cot |
| Domain-adapted embedding (PubMedBERT) | Regresses relevance/completeness |
| Domain-adapted reranker (MedCPT) | Regresses utilization/adherence; interacts negatively with domain embed |
| Hybrid search (BM25 + dense vs dense-only) | Inconclusive — no noise-band-exceeding difference |
| top_k_final widening (5→10) | Adherence collapse |
| top_k_final narrowing (5→3) | Catastrophic — all metrics regressed, adherence below random |
| Sentence-window chunking (all sizes) | Completeness marginal gain, adherence collapse |
| Context repacking | Falsified — no benefit, introduced citation-mismatch bug |
| Generator temperature (0.2→0.0) | Adherence collapse |
| MMR on vs off | **MMR on = major win (+0.25 adherence AUCROC)** |
| mmr_lambda (0.5→0.3, more diversity) | All metrics worse; utilization far outside noise band |
| Seed=42 on Groq calls | **Essential — eliminates non-determinism confound** |

### Iteration 32 — `"v8k"` config (covidqa, whole-doc, MMR on, mmr_lambda=0.7, seeded)

- **Status**: DONE (2026-07-28) — **adherence collapsed; mmr_lambda lever fully exhausted.**
- **Config**: `CONFIG_REGISTRY["v8k"]` = covidqa-only, whole-doc, `use_mmr=True`,
  `mmr_lambda=0.7` (up from default 0.5), `seed=42`. (Note: scoreboard was stale on first paste —
  re-run confirmed below numbers.)
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3355 | 0.1182 | 0.4849 | 0.4286 |

  Full mmr_lambda sweep (covidqa, whole-doc, seeded):

  | lambda | rel RMSE | util RMSE | comp RMSE | adh AUCROC |
  |---|---|---|---|---|
  | 0.3 (v8j, more diversity) | 0.3725 | 0.2192 | 0.5433 | 0.8214 |
  | **0.5 (v8e default)** | **0.3665** | **0.0880** | **0.5211** | **0.8929** |
  | 0.7 (v8k, more relevance) | 0.3355 | 0.1182 | **0.4849** | 0.4286 |

- **Observations**:
  - λ=0.7 improved relevance (0.3665→0.3355) and completeness (0.5211→0.4849) vs the 0.5
    default, both real differences exceeding the noise band.
  - But adherence collapsed to 0.4286 (below random). Cause: row 0 (gt=0, the only
    hallucinated response in the 15-row set) was marked pred_adherence=1 (missed); rows 8 and 9
    (gt=1) were incorrectly marked pred_adherence=0 (false negatives). More relevance-focused
    retrieval gave the generator more specific content to reference for row 0, which led to a
    confident-sounding but inference-heavy response that the Judge passed as adherent even though
    the ground truth marks it as hallucinated.
  - `pred_total_valid_key_count` remains 17-26 across rows — λ=0.7 does not meaningfully shrink
    the sentence pool. The completeness improvement came from subtly different document content
    (higher-relevance docs sometimes have shorter passages), not from pool shrinkage.
  - The λ sweep reveals a clear tradeoff: higher lambda improves completeness at the cost of
    adherence; lower lambda does the reverse but worse overall. The default λ=0.5 is the Pareto
    optimum across all four metrics.

- **Inference**: `mmr_lambda` is now fully tested in both directions and confirmed as a lever
  that trades adherence for completeness without a net gain. No value of lambda improves on the
  default 0.5 across all four metrics simultaneously. The completeness-adherence tradeoff is
  structural and persists regardless of how diversity vs. relevance is balanced in document
  selection.

- **Decision for next config**: `v8l` — `top_k_retrieve=30` with `top_k_final=5` kept constant.
  Hypothesis: giving the reranker more candidates (30 instead of 20) improves the precision of
  the final 5 selected documents — potentially selecting more targeted docs with fewer total
  sentences, reducing the Judge's over-crediting without changing the generation context size.
  This is the lowest-risk remaining lever (top_k_final unchanged, no architectural change).

### Iteration 33 — `"v8l"` config (covidqa, whole-doc, MMR on, top_k_retrieve=30, seeded)

- **Status**: DONE (2026-07-30) — **new best covidqa config. Real improvement on 3 of 4 metrics.**
- **Config**: `CONFIG_REGISTRY["v8l"]` = covidqa-only, whole-doc, `use_mmr=True`, `mmr_lambda=0.5`,
  `top_k_retrieve=30` (up from default 20), `top_k_final=5`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2693 | 0.1028 | 0.4431 | 0.9286 |

  Comparison against `v8e` covidqa slice (top_k_retrieve=20, otherwise identical):

  | metric | `v8e` covidqa (top_k_r=20) | `v8l` (top_k_r=30) | diff | within noise band? |
  |---|---|---|---|---|
  | relevance_rmse | 0.3665 | **0.2693** | −0.097 (better) | NO — far outside band |
  | utilization_rmse | **0.0880** | 0.1028 | +0.015 (worse) | yes |
  | completeness_rmse | 0.5211 | **0.4431** | −0.078 (better) | at edge — likely real |
  | adherence_aucroc | 0.8929 | **0.9286** | +0.036 (better) | at edge — likely real |

- **Observations**:
  - Relevance improvement (+0.097 RMSE) is the largest single-metric gain seen on covidqa in any
    seeded run. A wider candidate pool gives the reranker more options, allowing it to select docs
    that are genuinely more relevant to each question. The reranker's cross-encoder judgment is
    clearly the binding constraint at top_k_retrieve=20 — it simply didn't have enough candidates
    to find the best 5.
  - Completeness improved from 0.5211 to 0.4431 (−0.078 RMSE). Mechanism: more relevant docs
    in the final selection means the generator's answer covers a higher fraction of the relevant
    sentences the Judge identifies, since those sentences are now from docs genuinely about the
    question rather than tangentially related ones.
  - Adherence improved slightly (0.8929→0.9286): correctly detected the 1 hallucinated row
    (row 0), with only rows 8 and 9 as false negatives (same pattern as other whole-doc runs).
  - Utilization +0.015 RMSE regression is within the noise band — likely not a real effect.
  - `pred_total_valid_key_count` range (17-26) is unchanged vs v8e — the sentence pool size
    didn't shrink. The improvement came from WHICH 5 docs were selected (more relevant ones),
    not from fewer sentences per doc.

- **Inference**: `top_k_retrieve=30` is a genuine win for covidqa. The mechanism is simple:
  widening the reranker's candidate pool improves retrieval precision, selecting docs that are
  more directly relevant to each question. This reduces the Judge's relevance over-crediting
  (more sentences ARE actually about the question now), which reduces completeness RMSE and
  improves adherence simultaneously. No adherence-completeness tradeoff — both improved together.
  This is the best covidqa seeded config found in the project.

- **Decision for next config**: `v8m` — same as `v8l` but `domains=("covidqa", "pubmedqa")`.
  Since `top_k_retrieve=30` improved covidqa, the natural question is whether it also helps
  pubmedqa (currently best at v8c: 0.2756/0.1211/0.2417/0.9231). Testing both domains together
  directly targets the user's end goal of a single best cross-domain config. If pubmedqa holds
  or improves, `v8m` becomes the final answer.

---

### Iteration 34 — v8m: top_k_retrieve=30 on both domains (cross-domain validation)

**Hypothesis**: `top_k_retrieve=30` improved covidqa in v8l — does it also hold or improve
pubmedqa (currently best at v8c: rel=0.2756, util=0.1211, comp=0.2417, adh=0.9231)?

- **Status**: DONE (2026-07-30) — **pubmedqa collapsed. top_k_retrieve is domain-specific.**
- **Config**: `CONFIG_REGISTRY["v8m"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=30`, `top_k_final=5`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2805 | 0.1188 | 0.4852 | 0.9286 |
  | pubmedqa | 15 | 0.3077 | 0.2769 | 0.3393 | 0.5577 |
  | ALL | 30 | 0.2944 | 0.2130 | 0.4187 | 0.7037 |

  Comparison against domain-specific bests:

  | metric | covidqa v8l (best, top_k_r=30) | covidqa v8m | pubmedqa v8c (best, top_k_r=20) | pubmedqa v8m |
  |---|---|---|---|---|
  | relevance_rmse | 0.2693 | 0.2805 (+0.011) | 0.2756 | 0.3077 (+0.032) |
  | utilization_rmse | 0.1028 | 0.1188 (+0.016) | 0.1211 | **0.2769 (+0.156)** |
  | completeness_rmse | 0.4431 | 0.4852 (+0.042) | 0.2417 | 0.3393 (+0.098) |
  | adherence_aucroc | 0.9286 | **0.9286** (=) | 0.9231 | **0.5577 (−0.365)** |

  covidqa regressions are within the noise band. pubmedqa regressions are severe and real.

  Cross-domain comparison vs v8e (previous cross-domain best, top_k_retrieve=20):

  | metric | v8e ALL | v8m ALL | direction |
  |---|---|---|---|
  | relevance_rmse | 0.3206 | **0.2944** | v8m better |
  | utilization_rmse | **0.1490** | 0.2130 | v8m worse |
  | completeness_rmse | **0.3994** | 0.4187 | v8m worse |
  | adherence_aucroc | **0.8704** | 0.7037 | v8m much worse |

  v8e remains the best cross-domain config on 3 of 4 metrics.

- **Observations**:
  - pubmedqa adherence collapsed 0.9231 → 0.5577: 7 out of 15 pubmedqa rows had adherence=0.0
    vs only 1-2 in v8c. The wider candidate pool at top_k_retrieve=30 pulls in tangentially
    related chunks from pubmedqa's shorter, more precise documents. The reranker can't distinguish
    signal from noise as well with 30 candidates as with 20 — the final 5 docs contain more
    irrelevant content, which the generator then hallucinates from.
  - pubmedqa utilization regression (+0.156 RMSE) confirms the same mechanism: more of the
    retrieved sentences are not in the ground-truth annotation, raising utilization RMSE.
  - covidqa held at its v8l level (adherence identical, other regressions within noise). The
    domain has longer documents with richer content, so the reranker can still find high-quality
    candidates from a pool of 30.
  - This is a domain-specific interaction: `top_k_retrieve=30` suits covidqa's document
    characteristics but is harmful for pubmedqa's shorter, more topically focused documents.

- **Key finding**: **`top_k_retrieve` is not a universal lever.** Optimal value is
  domain-dependent: covidqa=30, pubmedqa=20 (or lower). Since the goal is a single cross-domain
  config, `top_k_retrieve` cannot be the unifying mechanism.

- **Decision for next config**: `v8n` — both domains, `top_k_final=3` (down from default 5),
  `top_k_retrieve=20` (default). Hypothesis: sending only 3 highly-ranked docs to the generator
  (instead of 5) tightens the generator's information space — fewer sentences for the judge to
  flag as hallucinated (adherence ↑), better utilization (generator cites more of what it
  receives), without necessarily hurting completeness since the 3 docs are the best-ranked ones.
  This lever hasn't been tested and applies uniformly across domains.

---

### Iteration 35 — v8n: top_k_final=3, both domains

**Hypothesis**: Sending only 3 docs (instead of 5) to the generator tightens the information
space → generator relies less on parametric memory → adherence improves.

- **Status**: DONE (2026-07-30) — **catastrophic regression on both domains. Lever falsified.**
- **Config**: `CONFIG_REGISTRY["v8n"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=20`, `top_k_final=3`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.4064 | 0.1791 | 0.5480 | 0.3929 |
  | pubmedqa | 15 | 0.3316 | 0.3527 | 0.4152 | 0.5962 |
  | ALL | 30 | 0.3709 | 0.2797 | 0.4862 | 0.5370 |

  All metrics worse than v8e cross-domain best (0.3206/0.1490/0.3994/0.8704) and both domain bests.
  covidqa adherence collapsed from 0.9286 (v8l) to 0.3929 — the worst adherence seen on covidqa
  in any seeded run. pubmedqa adherence also regressed (0.9231→0.5962).

- **Observations**:
  - With only 3 docs, the generator more frequently responds with "documents are missing
    information" or synthesizes from parametric memory rather than retrieved context. The judge
    then sees the answer disagree with the 3 retrieved documents → adherence collapses.
  - The hypothesis was backwards: fewer docs don't reduce hallucination risk — they increase it
    because the generator has insufficient grounding to answer factual questions.
  - Completeness also regressed (covidqa 0.4431→0.5480, pubmedqa 0.2417→0.4152): fewer docs
    means less sentence coverage for the judge to match against ground-truth annotations.
  - `pred_total_valid_key_count` dropped (covidqa: 10-18 range vs 17-26 in v8l), confirming
    fewer total sentences reaching the judge from 3 docs vs 5.

- **Inference**: `top_k_final` reduction is harmful. The default of 5 is better than 3. The
  opposite direction (top_k_final=7) is unlikely to help given v8m showed that wider context
  doesn't help pubmedqa adherence. top_k_final lever is exhausted.

- **Decision for next config**: `v8o` — both domains, `use_reranker=False` (skip cross-encoder),
  `top_k_retrieve=20`, `top_k_final=5` (default). Hypothesis: the cross-encoder reranker at
  top_k_retrieve=20 may be re-ordering away from the RRF hybrid signal. Bypassing it lets the
  dense+BM25 fusion directly determine the final 5 docs. Low-confidence test — reranker has
  been beneficial in other configs — but it's the last untested retrieval lever.

---

### Iteration 36 — v8o: use_reranker=False, both domains

**Hypothesis**: Cross-encoder reranker at top_k_retrieve=20 may re-order away from the best
RRF hybrid candidates. Bypassing it lets the dense+BM25 fusion directly determine final 5 docs.

- **Status**: DONE (2026-07-31) — **reranker is essential; removal hurts both domains.**
- **Config**: `CONFIG_REGISTRY["v8o"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=20`, `top_k_final=5`, `use_reranker=False`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3684 | 0.1927 | 0.5673 | 0.4643 |
  | pubmedqa | 15 | 0.2909 | 0.2050 | 0.3401 | 0.5962 |
  | ALL | 30 | 0.3319 | 0.1989 | 0.4677 | 0.5741 |

  Comparison vs domain bests and v8e (cross-domain best):

  | metric | v8e ALL (use_reranker=True) | v8o ALL (use_reranker=False) | direction |
  |---|---|---|---|
  | relevance_rmse | **0.3206** | 0.3319 | v8o worse |
  | utilization_rmse | **0.1490** | 0.1989 | v8o worse |
  | completeness_rmse | **0.3994** | 0.4677 | v8o worse |
  | adherence_aucroc | **0.8704** | 0.5741 | v8o much worse (−0.296) |

- **Observations**:
  - Without the cross-encoder, covidqa adherence collapsed 0.9286 (v8l) → 0.4643 and pubmedqa
    0.9231 (v8c) → 0.5962. The RRF fusion alone selects more topically adjacent but not
    semantically precise documents; the cross-encoder is what elevates precision to a level the
    generator can faithfully ground responses in.
  - Relevance also worsened in both domains — confirming the reranker improves retrieval
    precision across the board, not just hallucination control.
  - The hypothesis was wrong: the reranker is not mis-ordering the RRF candidates; it is the
    primary precision filter and removing it degrades all four TRACe dimensions simultaneously.

- **Inference**: `use_reranker=True` (cross-encoder ms-marco-MiniLM-L-6-v2) is a critical
  component of this pipeline's retrieval stack. The lever is falsified in both directions
  (domain-adapted MedCPT was tested earlier and also regressed). The default reranker is optimal.

- **All retrieval-side levers exhausted.** No further config exploration is warranted.
  Optimization ceiling reached within these architectural constraints.

---

## Final Summary — Updated (2026-07-31)

All retrieval levers have been tested and the pipeline has reached its optimization ceiling.
Below are the definitive best configs.

### Final Best Configurations

**Best pubmedqa config: `v8c`** (unchanged from original summary)

| metric | value |
|--------|-------|
| context_relevance RMSE | 0.2756 |
| context_utilization RMSE | 0.1211 |
| completeness RMSE | 0.2417 |
| adherence AUCROC | 0.9231 |

Settings: whole-doc, `use_mmr=True`, `mmr_lambda=0.5`, `top_k_retrieve=20`, `top_k_final=5`,
`use_reranker=True`, `generation_prompt_style="long"`, `seed=42`, pubmedqa-only.

**Best covidqa config (seeded): `v8l`** (updated from v8e covidqa slice — Iteration 33)

| metric | value |
|--------|-------|
| context_relevance RMSE | 0.2693 |
| context_utilization RMSE | 0.1028 |
| completeness RMSE | 0.4431 |
| adherence AUCROC | 0.9286 |

Settings: identical to `v8c` but `top_k_retrieve=30` and `domains=("covidqa",)`.
Improvement vs v8e covidqa slice: relevance −0.097, completeness −0.078, adherence +0.036
(all outside noise band). The wider reranker candidate pool was the decisive difference.

**Best cross-domain config: `v8e`** (unchanged — every challenger failed)

| domain | rel RMSE | util RMSE | comp RMSE | adh AUCROC |
|--------|----------|-----------|-----------|------------|
| pubmedqa | 0.2756 | 0.1211 | 0.2417 | 0.9231 |
| covidqa | 0.3665 | 0.0880 | 0.5211 | 0.8929 |
| ALL (pooled) | 0.3206 | 0.1490 | 0.3994 | 0.8704 |

Settings: whole-doc, `use_mmr=True`, `mmr_lambda=0.5`, `top_k_retrieve=20`, `top_k_final=5`,
`use_reranker=True`, `generation_prompt_style="long"`, `seed=42`, both domains.

Note: `top_k_retrieve=30` cannot be applied cross-domain — it improves covidqa but collapses
pubmedqa adherence (0.9231→0.5577), making domain-optimal settings incompatible in one config.

### Complete Lever Verdict Table (Final)

| Lever | Verdict |
|-------|---------|
| Generation prompt style (long vs long_cot) | Marginal; "long" slightly better |
| Domain-adapted embedding (PubMedBERT) | ✗ Regresses relevance/completeness |
| Domain-adapted reranker (MedCPT) | ✗ Regresses utilization/adherence |
| Hybrid search (BM25 + dense vs dense-only) | Inconclusive |
| top_k_final narrowing (5→3) | ✗ Catastrophic — all metrics regressed |
| top_k_final widening (5→10) | ✗ Adherence collapse |
| Sentence-window chunking (all sizes) | ✗ Adherence collapse in all seeded tests |
| Context repacking | ✗ No benefit, citation-mismatch bug |
| Generator temperature (0.2→0.0) | ✗ Adherence collapse |
| MMR on vs off | ✓ **Major win: +0.25 adherence AUCROC** |
| mmr_lambda=0.3 (more diversity) | ✗ All metrics worse |
| mmr_lambda=0.7 (more relevance) | ✗ Adherence collapse |
| mmr_lambda=0.5 (default) | ✓ **Pareto optimum** |
| top_k_retrieve=30 (covidqa-only) | ✓ **New covidqa best — real improvement** |
| top_k_retrieve=30 (cross-domain) | ✗ pubmedqa collapses |
| use_reranker=False | ✗ Both domains collapse (−0.296 adherence ALL) |
| Seed=42 on Groq calls | ✓ **Essential — eliminates non-determinism** |

---

### Iteration 37 — v8p: query expansion, both domains

**Hypothesis**: Several covidqa questions retrieve 0 relevant docs with the original phrasing
(rows 7 "severe MARS", 9 "Clade A" — zero relevant keys across multiple runs). Expanding each
question into 2 Groq-generated variants before retrieval, then taking the union of all three
candidate pools (~3×top_k_retrieve=60 candidates), gives the reranker a richer set to select
from. The reranker always scores against the ORIGINAL query, so precision is preserved.

- **Status**: PENDING — run in Colab and paste scoreboard results.
- **Config**: `CONFIG_REGISTRY["v8p"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=20`, `top_k_final=5`, `use_reranker=True`, `use_query_expansion=True`,
  `generation_prompt_style="long"`, `seed=42`.
- **Cost vs. baseline**: 1 extra Groq call per question (expansion only). Generator and judge
  call counts unchanged. 30 extra calls total (15 per domain).
- **Implementation**: `expand_query()` in retriever cell — generates variants via
  `QUERY_EXPANSION_PROMPT`, falls back to original query on any error. `retrieve()` loops over
  all variants, accumulates per-variant RRF scores, caps the union at `top_k_retrieve` candidates
  before passing to the cross-encoder.
- **Reference (cross-domain best)**: v8e — rel=0.3206, util=0.1490, comp=0.3994, adh=0.8704.
- **Confirm criteria**: any metric improves outside the noise band (>0.05 RMSE or >0.06 AUCROC).
- **Falsify criteria**: all metrics within noise band of v8e, or adherence collapses (<0.80).

---

### Iteration 38 — v8q: context summarization, both domains

**Hypothesis**: Compress 5 retrieved docs into one question-focused summary (1 Groq call per
question) before passing to generator and judge. Smaller sentence pool → generator covers a
higher fraction → completeness RMSE falls; adherence may improve as generator has less
off-topic material to hallucinate from.

- **Status**: DONE (2026-08-02) — **catastrophically falsified. Relevance +0.258 and
  utilization +0.413 RMSE vs v8e. Metrics incompatibility — not retrieval quality.**
- **Config**: `CONFIG_REGISTRY["v8q"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=20`, `top_k_final=5`, `use_context_summarization=True`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.6546 | 0.6882 | 0.5092 | **1.0000** |
  | pubmedqa | 15 | 0.4898 | 0.3965 | 0.3079 | 0.4615 |
  | ALL | 30 | 0.5781 | 0.5616 | 0.4208 | 0.6481 |

- **Observations**:
  - Summarization shrank `pred_total_valid_key_count` from 17–26 sentences (full docs) to
    1–5 sentences (summary). With only 1–2 sentences in the judge's pool, essentially all
    are labeled "relevant" and "utilized" → pred_relevance and pred_utilization push toward
    1.0. Ground truth was computed on full docs (5–9 relevant of ~22 total → GT ≈ 0.27–0.41).
    Squared error per row can reach (1.0 − 0.41)² = 0.35 — catastrophic RMSE inflation.
  - **covidqa adherence hit 1.0** (perfect) — the only positive result. With 1–5 summary
    sentences, the generator is forced to be concise and stay close to the provided text,
    eliminating hallucinations almost entirely on covidqa.
  - pubmedqa adherence collapsed (0.9231→0.4615) — summarization loses specific sentences
    the judge needs to verify claims, creating false negatives.
  - The hypothesis was correct mechanically (smaller pool → higher generator coverage fraction)
    but the metric denominator change is fundamentally incompatible with ground-truth collection:
    GT scores were computed on the full original documents, not on compressed summaries. No
    retrieval-side fix can resolve this mismatch.

- **Inference**: Context summarization is falsified as a TRACe-optimizing lever. The approach
  changes what the metrics measure (sentence pool size) rather than improving how well the
  pipeline answers questions. The covidqa adherence=1.0 result is a curiosity but not useful
  given the 3 other metrics all regressed badly.

- **Only one lever remains: `top_k_retrieve=25`** — the interpolation between covidqa's
  optimum (30) and pubmedqa's optimum (20). We jumped directly from 20→30 and never tested
  the midpoint. This is a zero-code-change config entry.

---

### Iteration 39 — v8r: top_k_retrieve=25 (midpoint), both domains

**Hypothesis**: covidqa optimum=30, pubmedqa optimum=20. Midpoint of 25 might give covidqa
partial precision benefit while staying below pubmedqa's dilution threshold that caused
collapse at 30.

- **Status**: DONE (2026-08-02) — **pubmedqa collapses at 25 as badly as at 30. No midpoint exists.**
- **Config**: `CONFIG_REGISTRY["v8r"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=25`, `top_k_final=5`, `use_reranker=True`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.2968 | 0.1695 | 0.4285 | 0.9286 |
  | pubmedqa | 15 | 0.2428 | 0.2324 | 0.3491 | 0.5192 |
  | ALL | 30 | 0.2712 | 0.2034 | 0.3908 | 0.6852 |

  pubmedqa adherence: 0.9231 (v8c, k=20) → 0.5192 (k=25) → 0.5577 (v8m, k=30).
  The collapse at 25 is almost as severe as at 30 — the dilution threshold is between 20 and 25.

  Cross-domain vs v8e (0.3206/0.1490/0.3994/0.8704):
  - relevance improved (−0.049, just outside noise band) ✓
  - utilization slightly worse (+0.044, within noise) ~
  - completeness slightly better (−0.009, within noise) ~
  - adherence major regression (−0.185) ✗ — not a Pareto improvement.

- **Observations**:
  - covidqa at top_k_retrieve=25 is better than 20 on relevance (−0.070), completeness
    (−0.093), and adherence (tied 0.9286), but worse than 30 on relevance (+0.027) and
    utilization (+0.067). The covidqa benefit scales smoothly with k: 20 < 25 < 30.
  - pubmedqa's dilution threshold is strictly between 20 and 25 — there is no integer midpoint
    that preserves pubmedqa's adherence while giving covidqa wider retrieval. The domains'
    optimal k values are fundamentally incompatible.
  - The slight cross-domain relevance improvement (0.3206→0.2712) is real but offset by the
    adherence collapse (0.8704→0.6852), which is the most important metric for hallucination
    detection. v8e wins on 3 of 4 cross-domain metrics.

- **Inference**: No cross-domain top_k_retrieve value between 20 and 30 avoids pubmedqa's
  adherence collapse. The optimal must be exactly 20 for cross-domain use. The domain-specific
  incompatibility is fundamental to pubmedqa's shorter document characteristics.

- **Decision for next config**: one genuinely untested config parameter remained — `rrf_k`
  (RRF smoothing constant, default 60). Lower values make top-ranked docs earn disproportionately
  higher fusion scores. Testing `rrf_k=30` as v8s.

---

### Iteration 40 — v8s: rrf_k=30 (tighter RRF top-rank weighting), both domains

**Hypothesis**: tighter RRF smoothing (30 vs default 60) sharpens the fusion signal — docs that
rank highly from both BM25 and dense retrieval earn much higher combined scores, giving the
cross-encoder a cleaner signal on which 5 docs to keep. Candidate pool size unchanged
(top_k_retrieve=20). Low-confidence (~10%) — the cross-encoder downstream likely absorbs most
of this signal.

- **Status**: DONE (2026-08-03) — **falsified. pubmedqa adherence collapses below random
  chance. rrf_k=60 (default) confirmed as the correct value.**
- **Config**: `CONFIG_REGISTRY["v8s"]` = both domains, whole-doc, `use_mmr=True`,
  `top_k_retrieve=20`, `top_k_final=5`, `use_reranker=True`, `rrf_k=30`, `seed=42`.
- **Results**:

  | domain | n | relevance_rmse | utilization_rmse | completeness_rmse | adherence_aucroc |
  |---|---|---|---|---|---|
  | covidqa | 15 | 0.3282 | 0.0860 | 0.4678 | 0.9286 |
  | pubmedqa | 15 | 0.2979 | 0.2432 | 0.3826 | 0.3077 |
  | ALL | 30 | 0.3135 | 0.1824 | 0.4274 | 0.5370 |

  Cross-domain vs v8e (0.3206/0.1490/0.3994/0.8704):

  | metric | v8e (rrf_k=60) | v8s (rrf_k=30) | diff |
  |---|---|---|---|
  | relevance_rmse ↓ | 0.3206 | 0.3135 | −0.007 (noise band) |
  | utilization_rmse ↓ | 0.1490 | 0.1824 | +0.033 ✗ |
  | completeness_rmse ↓ | 0.3994 | 0.4274 | +0.028 ✗ |
  | adherence_aucroc ↑ | **0.8704** | **0.5370** | −0.333 ✗✗✗ |

- **Observations**:
  - pubmedqa adherence crashed to 0.3077 — worse than random chance (0.5). The relevance
    micro-improvement (−0.007) is inside the noise band and meaningless against this collapse.
  - covidqa was unaffected (adh=0.9286, same as v8e's covidqa). The failure is entirely
    pubmedqa-side, consistent with the pattern seen across all levers tried in Iterations 33–40.
  - Mechanism: making RRF top-heavy shifts which docs survive into the top-5 pool for pubmedqa.
    pubmedqa's short, precise documents need a more balanced fusion that lets BM25 and dense
    retrieval each contribute; winner-takes-all RRF disrupts that balance.

- **Inference**: `rrf_k` is falsified as a lever. The default (60) is the right value for this
  corpus. pubmedqa's adherence sensitivity (seen consistently across top_k, query expansion,
  context summarization, and now rrf_k) reflects a fundamental fragility: the domain's short,
  focused documents are harmed by any change that shifts the retrieved sentence pool away from
  the tight, on-topic distribution that seed=42/top_k=20/rrf_k=60 produces.

- **ALL LEVERS EXHAUSTED. OPTIMIZATION COMPLETE.**

  Final best configs (unchanged since Iteration 33/36):
  - Best cross-domain: **v8e** — rel=0.3206, util=0.1490, comp=0.3994, adh=0.8704
  - Best covidqa (seeded): **v8l** — rel=0.2693, util=0.1028, comp=0.4431, adh=0.9286
  - Best pubmedqa: **v8c** — rel=0.2756, util=0.1211, comp=0.2417, adh=0.9231
