# RAGBench Top-3 Config Demo

The interactive demo for the top-3 RAGBench configurations lives in:

**`../ragbench-top3-demo/`**

That folder is the source of truth for `app.py`, checkpoints, and GitHub Pages deployment.

To run locally:

```bash
cd ../ragbench-top3-demo
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Live site (after GitHub Pages deploy):  
`https://<github-user>.github.io/ragbench-top3-demo/rag-demo/`
