# Noise Robustness — Results

**Dataset:** `en_refine.json`
**Sample size:** 300 (full dataset)
**Passage num:** 5
**Temperature:** 0.0
**Seed:** 2333

## Accuracy (%) by model and noise ratio

| model | 0.0 | 0.2 | 0.4 | 0.6 | 0.8 |
|---|---|---|---|---|---|
| llama-3.1-8b-instant | 98.7 | 98.7 | 98.7 | 98.3 | 95.0 |
| llama-3.3-70b-versatile | — | — | — | — | — |
| qwen/qwen3.6-27b | — | — | — | — | — |

> Remaining rows to be filled in once teammates complete their full-dataset runs.

---

## Accuracy (%) — sample size: 100

| model | 0.0 | 0.2 | 0.4 | 0.6 | 0.8 |
|---|---|---|---|---|---|
| llama-3.1-8b-instant | 100.0 | 100.0 | 100.0 | 100.0 | 99.0 |

> At n=100 the model shows a near-ceiling effect (100% flat until noise_rate=0.8 → 99.0%).
> The n=300 run above reveals the true degradation curve (98.7% → 95.0% at noise_rate=0.8).
