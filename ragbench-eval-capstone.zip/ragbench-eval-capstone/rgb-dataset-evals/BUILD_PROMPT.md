# Prompt: Build the RGB RAG Evaluation Pipeline

Paste this into a fresh Claude Code (or similar coding agent) session, pointed at an
empty project directory, to regenerate this pipeline from scratch.

---

## Task

I'm working on a capstone project. I need a model evaluation pipeline inside a folder
called `rgb-dataset-evals` that implements and evaluates the four RAG abilities from
this paper:

- **Paper**: "Benchmarking Large Language Models in Retrieval-Augmented Generation",
  Chen et al. 2023 — https://arxiv.org/pdf/2309.01431 (arXiv:2309.01431v2)
- **Dataset + reference code**: https://github.com/chen700564/RGB (default branch:
  `master`)

Read the paper first — it's essential for understanding the task, especially Figure 3
(the exact system prompt and instruction template to use for generation) and the
metric definitions in the Noise Robustness / Negative Rejection / Information
Integration / Counterfactual Robustness sections.

You may use the RGB GitHub repo's `evalue.py`, `reject_evalue.py`, `fact_evalue.py`,
and `config/instruction.yaml` **only as reference for understanding the sampling and
scoring semantics** — do not copy-paste their code. Reimplement independently.

### Requirements (from the assignment brief)

1. Use only the **English** dataset files, ignore the Chinese ones.
2. Datasets to use (download from `https://raw.githubusercontent.com/chen700564/RGB/master/data/<file>`):
   - Noise Robustness + Negative Rejection → `en_refine.json`
   - Information Integration → `en_int.json`
   - Counterfactual Robustness → `en_fact.json`
3. Use the exact prompt from Figure 3 of the paper (also in the repo's
   `config/instruction.yaml`, `en:` block) — system message plus a
   `Document:\n{DOCS}\n\nQuestion:\n{QUERY}` instruction template.
4. Experiment with **at least 3 different LLMs**.
5. Report these metrics (see paper for exact definitions):
   - **Accuracy** — for Noise Robustness and Information Integration
   - **Rejection rate** — for Negative Rejection (you do NOT need to report the
     ChatGPT-judged `Rej*` variant, only the exact-match `Rej`)
   - **Error detection rate, Error correction rate** — for Counterfactual Robustness
     (you do NOT need to report the ChatGPT-judged `ED*` variant, only exact-match `ED`)
6. Passage count per query defaults to 5 (paper's default `passage_num`), matching
   Table 1/5/7 conventions.
7. Noise ratios to sweep: `{0, 0.2, 0.4, 0.6, 0.8}` for Noise Robustness, `{0, 0.2, 0.4}`
   for Information Integration (per the paper's English tables).

### Model backends

I want to run models **locally via Ollama** (I have it installed) as the primary
backend, but also have a **Groq-hosted backend wired up and ready to switch to** later
(rotating across multiple free-tier API keys on rate limits — same pattern as my other
RAG pipeline, `rag-pipeline-v2`, which uses a `RotatingGroqClient`). Default to 3 Ollama
models: `llama3.1:8b`, `qwen2.5:7b`, `mistral:7b` — pull them if not already present.

### Format

Build this as a **Jupyter notebook** (`RGB_Evaluation.ipynb`), matching the convention
of my other capstone notebooks (`rag-pipeline-v1/`, `rag-pipeline-v2/`): one driver
notebook, with the heavier logic factored into an importable module so it can be
unit-tested outside the notebook too.

---

## Design decisions to replicate

These are the concrete choices made the first time this was built — reuse them so the
two notebooks stay comparable across team members.

### Directory layout

```
rgb-dataset-evals/
├── data/                   # en_refine.json, en_int.json, en_fact.json, en.json
├── reference/              # RGB repo's scripts (reference only, not imported)
├── results/                # checkpointed JSONL, one file per (ability, dataset,
│                            # model, noise_rate, correct_rate, passage_num, sample_size)
├── src/
│   └── rgb_eval.py         # all core logic, importable from the notebook and testable standalone
├── RGB_Evaluation.ipynb
├── .venv/                  # local venv (see "Environment" below)
└── .gitignore              # .venv/, results/*.jsonl, __pycache__/
```

### Prompt template (exact text — Figure 3 / instruction.yaml `en:` block)

```
SYSTEM: You are an accurate and reliable AI assistant that can answer questions with
the help of external documents. Please note that external documents may contain noisy
or factually incorrect information. If the information in the document contains the
correct answer, you will give an accurate answer. If the information in the document
does not contain the answer, you will generate 'I can not answer the question because
of the insufficient information in documents.'. If there are inconsistencies with the
facts in some of the documents, please generate the response 'There are factual errors
in the provided documents.' and provide the correct answer.

USER: Document:
{DOCS}

Question:
{QUERY}
```

### Document sampling logic (reimplemented per-ability, not copied from the repo)

- **Noise Robustness / Negative Rejection** (`en_refine.json`): each instance has
  `positive` and `negative` doc lists. `neg_num = ceil(passage_num * noise_rate)`,
  `pos_num = passage_num - neg_num`, clamp against list lengths, take
  `positive[:pos_num] + negative[:neg_num]`, shuffle. `noise_rate=1.0` → all `passage_num`
  docs come from `negative` (this is the Negative Rejection setting, same dataset,
  different sampling knob).
- **Information Integration** (`en_int.json`): `positive` is a *list of doc groups*, one
  group per sub-answer that must be integrated (e.g. the query asks two questions, so
  there are two groups). Shuffle each group, then round-robin one doc per group until
  `pos_num` docs are collected (so every sub-answer is represented before any is
  doubled up), pad remaining slots from `negative` per `noise_rate`, shuffle.
- **Counterfactual Robustness** (`en_fact.json`): each instance has `positive` (true-fact
  docs), `positive_wrong` (same docs but altered to support a `fakeanswer`), and
  `negative`. Sample `correct_num = ceil(passage_num * correct_rate)` true-fact docs and
  fill the rest with `positive_wrong` (counterfactual) docs; `correct_rate=0.0` gives the
  paper's `Acc_doc` setting (100% counterfactual evidence).

### Answer matching (exact-match, case-insensitive substring)

`answer` fields are either a bare string, or a list where each item is either a string
or itself a list of accepted phrasings (OR within an item). For multi-part answers
(Information Integration), the ground truth is a list of *items that must all be
present* (AND across items). A prediction counts as correct iff every item matches (any
phrasing variant, if the item is a list).

### Metric definitions

- `insufficient_info` flag: `"insufficient information"` substring present in the
  lowercased prediction (this is the literal phrase from the system prompt).
- `factual_error_flagged` flag: `"factual errors"` substring present in the lowercased
  prediction.
- **Accuracy** = fraction of instances where the answer-matching check passes.
- **Rejection rate** (run at `noise_rate=1.0` on `en_refine.json`) = fraction of
  instances with `insufficient_info == True`.
- **Error Detection Rate (ED)** = fraction of `Acc_doc`-setting instances with
  `factual_error_flagged == True`.
- **Error Correction Rate (CR)** = among instances with `factual_error_flagged == True`,
  the fraction that are *also* answer-correct (i.e. gave the right fact despite it being
  misrepresented in the docs).
- Also report **Acc** (no external docs, `passage_num=0`) and **Acc_doc** (with
  counterfactual docs) for Counterfactual Robustness, matching the paper's Table 7 shape.

### Model client abstraction

Two interchangeable clients with the same `.generate(query, docs, temperature) -> str`
interface:

- `OllamaClient(model, host="http://localhost:11434")` — POSTs to `/api/chat` with the
  system+user messages, `stream: false`. This is the active default.
- `RotatingGroqClient(model, api_keys: list[str])` — cycles through API keys on
  `429`/rate-limit errors, raises only once every key is exhausted. Wired up but
  inactive until `GROQ_API_KEYS` is filled in and a backend switch flag is flipped.

A single `ACTIVE_BACKEND = "ollama" | "groq"` variable in the notebook's config cell
picks which one gets instantiated for all 3 models.

### Checkpointed run loop

One `RunConfig` dataclass (`ability`, `dataset_file`, `model_name`, `passage_num`,
`noise_rate`, `correct_rate`, `temperature`, `sample_size`, `seed`) drives a
`run_predictions(cfg, client)` function that:
- Builds a deterministic `run_id()` from the config fields → one JSONL file per unique
  config combo under `results/`.
- On start, loads any existing checkpoint file and skips already-computed instance IDs
  (resumable — safe to interrupt and rerun without re-calling the model).
- Appends+flushes each new prediction row immediately (so partial progress survives a
  crash).
- Uses a per-run `random.Random(seed)` (paper uses `seed=2333`) for reproducible
  document sampling.

### Notebook structure

1. Markdown intro: table of the 4 abilities → dataset → metric, models used, note about
   `RESULTS/` checkpointing and the "start small, scale after reviewing real numbers"
   methodology.
2. Setup cell: `sys.path.insert(0, "src")`, import the eval module, pandas display
   options.
3. Config cell: backend selection, model lists (Ollama + Groq), `PASSAGE_NUM=5`,
   `TEMPERATURE=0.0`, noise-rate sweeps, **`SAMPLE_SIZE = 30`** (small first-pass default,
   *not* the full dataset — see methodology note below), `make_clients()` helper.
4. Section 1 — Noise Robustness: loop models × noise rates → pivot table (model ×
   noise_rate → accuracy %).
5. Section 2 — Negative Rejection: loop models at `noise_rate=1.0` → table of rejection
   rate per model.
6. Section 3 — Information Integration: loop models × noise rates (0/0.2/0.4) → pivot
   table.
7. Section 4 — Counterfactual Robustness: for each model, run both the no-docs (`Acc`)
   and counterfactual-docs (`Acc_doc`) configs → table with Acc, Acc_doc, ED, CR.
8. Closing markdown: next-steps note (review the small-sample numbers, swap out a bad/
   slow model if needed, then raise `SAMPLE_SIZE` — up to `None` for the full dataset,
   300 for `en_refine.json` / 100 for `en_int.json`/`en_fact.json` — and rerun; existing
   checkpoints mean nothing already-computed gets redone).

## Methodology constraint — important

**Do not pre-run the full 300/100/100-example × 5-noise-rate × 3-model sweep
automatically.** Validate the whole pipeline end-to-end on a tiny sample first (e.g. 2-3
examples, 1 model) to catch bugs cheaply, then hand it back for the team to run at
`SAMPLE_SIZE = 30` (or whatever they choose) and review real numbers before deciding
whether/how to scale up. This mirrors how this team's other RAG pipelines
(`rag-pipeline-v1`, `rag-pipeline-v2`) were built — real run results decide the next
step, not a pre-planned experiment sweep.

## Environment notes

- If the system Python is externally managed (e.g. Homebrew on macOS blocks
  system-wide `pip install`), create a local `.venv` inside `rgb-dataset-evals/` and
  install `jupyter ipykernel requests tqdm nbformat nbclient pandas` there, then
  register it as a Jupyter kernel (`python -m ipykernel install --user --name
  rgb-dataset-evals`).
- Local Ollama models cannot be reached from a hosted notebook environment like Colab —
  this pipeline must run against a local Jupyter kernel that can hit
  `http://localhost:11434`.
- Verify the whole notebook actually executes (not just that the code looks right) by
  running it end-to-end once with a trivial sample size via
  `jupyter nbconvert --to notebook --execute` before handing it off, and check the
  output cells for errors.
