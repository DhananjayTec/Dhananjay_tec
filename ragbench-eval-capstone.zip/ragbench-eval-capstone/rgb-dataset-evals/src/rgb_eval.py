"""
Core logic for the RGB (Retrieval-Augmented Generation Benchmark) evaluation pipeline.

Implements the four RAG abilities from Chen et al. 2023 ("Benchmarking Large Language
Models in Retrieval-Augmented Generation", arXiv:2309.01431):
  - Noise Robustness      (en_refine.json, varying noise_rate)
  - Negative Rejection    (en_refine.json, noise_rate=1.0)
  - Information Integration (en_int.json)
  - Counterfactual Robustness (en_fact.json)

Sampling/metric logic below is an independent reimplementation based on reading the
paper and the reference scripts in RGB (chen700564/RGB) for semantics only -- no code
was copied from that repository.
"""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import requests

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
RESULTS_DIR = ROOT_DIR / "results"
RESULTS_DIR.mkdir(exist_ok=True)

# ---------------------------------------------------------------------------
# Prompt template (Figure 3 of the paper / config/instruction.yaml in RGB repo, English)
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "You are an accurate and reliable AI assistant that can answer questions with the "
    "help of external documents. Please note that external documents may contain noisy "
    "or factually incorrect information. If the information in the document contains "
    "the correct answer, you will give an accurate answer. If the information in the "
    "document does not contain the answer, you will generate 'I can not answer the "
    "question because of the insufficient information in documents.'. If there are "
    "inconsistencies with the facts in some of the documents, please generate the "
    "response 'There are factual errors in the provided documents.' and provide the "
    "correct answer."
)

INSTRUCTION_TEMPLATE = "Document:\n{docs}\n\nQuestion:\n{query}"

INSUFFICIENT_INFO_PHRASE = "insufficient information"
FACTUAL_ERROR_PHRASE = "factual errors"


def build_prompt(query: str, docs: list[str]) -> str:
    docs_block = "\n".join(docs) if docs else ""
    return INSTRUCTION_TEMPLATE.format(docs=docs_block, query=query)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_jsonl(filename: str) -> list[dict]:
    path = DATA_DIR / filename
    records = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


# ---------------------------------------------------------------------------
# Document sampling (per ability)
# ---------------------------------------------------------------------------

def sample_noise_docs(instance: dict, noise_rate: float, passage_num: int, rng: random.Random) -> list[str]:
    """Noise robustness / negative rejection sampling from en_refine.json.

    noise_rate=1.0 means every retrieved document is irrelevant (negative) -- this is
    the negative-rejection setting.
    """
    if noise_rate >= 1.0:
        neg_num = passage_num
        pos_num = 0
    else:
        neg_num = min(math.ceil(passage_num * noise_rate), len(instance["negative"]))
        pos_num = passage_num - neg_num
        pos_num = min(pos_num, len(instance["positive"]))
        neg_num = passage_num - pos_num

    docs = list(instance["positive"][:pos_num]) + list(instance["negative"][:neg_num])
    rng.shuffle(docs)
    return docs


def sample_integration_docs(instance: dict, noise_rate: float, passage_num: int, rng: random.Random) -> list[str]:
    """Information integration sampling from en_int.json.

    `instance["positive"]` is a list of document groups, one group per sub-answer that
    must be integrated. We draw one supporting doc per sub-answer (round-robin, so every
    sub-answer is represented before any is doubled-up) and pad the remaining slots with
    negative (irrelevant) documents according to noise_rate.
    """
    neg_num = min(math.ceil(passage_num * noise_rate), len(instance["negative"]))
    pos_num = passage_num - neg_num

    groups = [list(g) for g in instance["positive"]]
    for g in groups:
        rng.shuffle(g)

    docs: list[str] = []
    round_idx = 0
    while len(docs) < pos_num and any(round_idx < len(g) for g in groups):
        for g in groups:
            if round_idx < len(g) and len(docs) < pos_num:
                docs.append(g[round_idx])
        round_idx += 1

    neg_num = passage_num - len(docs)
    if neg_num > 0:
        docs += list(instance["negative"][:neg_num])

    rng.shuffle(docs)
    return docs


def sample_counterfactual_docs(
    instance: dict, passage_num: int, correct_rate: float, rng: random.Random
) -> list[str]:
    """Counterfactual robustness sampling from en_fact.json.

    `positive_wrong` holds documents that support the *fake* answer (counterfactual
    noise); `positive` holds the matching true-fact documents. correct_rate controls how
    many true-fact documents are mixed in among the counterfactual ones (0.0 = the
    Acc_doc setting from Table 7: entirely counterfactual evidence).
    """
    n = len(instance["positive"])
    correct_num = min(math.ceil(passage_num * correct_rate), n)
    wrong_num = min(passage_num - correct_num, n)

    idx = list(range(n))
    rng.shuffle(idx)
    wrong_idx = set(idx[:wrong_num])
    remaining_idx = [i for i in idx if i not in wrong_idx]

    docs = [instance["positive_wrong"][i] for i in wrong_idx]
    if correct_num > 0 and remaining_idx:
        docs += [instance["positive"][i] for i in remaining_idx[:correct_num]]

    rng.shuffle(docs)
    return docs


# ---------------------------------------------------------------------------
# Answer matching / metrics
# ---------------------------------------------------------------------------

def _matches(prediction_lower: str, ground_truth_item) -> bool:
    """A single ground-truth item matches if it's a bare string contained in the
    prediction, or -- when it's a list of phrasing variants -- if any variant matches."""
    if isinstance(ground_truth_item, list):
        return any(variant.lower() in prediction_lower for variant in ground_truth_item)
    return ground_truth_item.lower() in prediction_lower


def answer_is_correct(prediction: str, answer) -> bool:
    """True if every required ground-truth item (all sub-answers, for multi-part
    questions like information integration) is present in the prediction."""
    prediction_lower = prediction.lower()
    items = answer if isinstance(answer, list) else [answer]
    return all(_matches(prediction_lower, item) for item in items)


def predicted_insufficient_info(prediction: str) -> bool:
    return INSUFFICIENT_INFO_PHRASE in prediction.lower()


def predicted_factual_error(prediction: str) -> bool:
    return FACTUAL_ERROR_PHRASE in prediction.lower()


# ---------------------------------------------------------------------------
# Model clients
# ---------------------------------------------------------------------------

class OllamaClient:
    """Talks to a locally running Ollama server (default http://localhost:11434)."""

    def __init__(self, model: str, host: str = "http://localhost:11434", timeout: int = 180):
        self.model = model
        self.host = host.rstrip("/")
        self.timeout = timeout

    def generate(self, query: str, docs: list[str], temperature: float = 0.0) -> str:
        user_prompt = build_prompt(query, docs)
        resp = requests.post(
            f"{self.host}/api/chat",
            json={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                "options": {"temperature": temperature},
                "stream": False,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()["message"]["content"]

    def __repr__(self) -> str:
        return f"OllamaClient({self.model!r})"


class RotatingGroqClient:
    """Groq-hosted client with API-key rotation on rate limits.

    Not activated by default -- fill in GROQ_API_KEYS in the notebook and switch
    ACTIVE_BACKEND to "groq" to use it, matching the rag-pipeline-v2 pattern.
    """

    def __init__(self, model: str, api_keys: list[str], timeout: int = 60):
        if not api_keys:
            raise ValueError("RotatingGroqClient requires at least one API key")
        self.model = model
        self.api_keys = api_keys
        self.timeout = timeout
        self._key_idx = 0

    def generate(self, query: str, docs: list[str], temperature: float = 0.0) -> str:
        import groq  # local import: only required when the Groq backend is active

        user_prompt = build_prompt(query, docs)
        last_err: Optional[Exception] = None
        for _ in range(len(self.api_keys)):
            key = self.api_keys[self._key_idx]
            try:
                client = groq.Groq(api_key=key)
                completion = client.chat.completions.create(
                    model=self.model,
                    temperature=temperature,
                    messages=[
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": user_prompt},
                    ],
                )
                return completion.choices[0].message.content
            except Exception as e:  # noqa: BLE001 - broad by design, rotate on any failure
                last_err = e
                msg = str(e).lower()
                if "rate_limit" in msg or "429" in msg:
                    self._key_idx = (self._key_idx + 1) % len(self.api_keys)
                    continue
                raise
        raise RuntimeError(f"All Groq API keys exhausted: {last_err}")

    def __repr__(self) -> str:
        return f"RotatingGroqClient({self.model!r})"


# ---------------------------------------------------------------------------
# Checkpointed run loop
# ---------------------------------------------------------------------------

@dataclass
class RunConfig:
    ability: str  # "noise" | "reject" | "integration" | "counterfactual"
    dataset_file: str
    model_name: str
    passage_num: int = 5
    noise_rate: float = 0.0
    correct_rate: float = 0.0
    temperature: float = 0.0
    sample_size: Optional[int] = None
    seed: int = 2333

    def run_id(self) -> str:
        return (
            f"{self.ability}_{Path(self.dataset_file).stem}_{self.model_name}"
            f"_noise{self.noise_rate}_correct{self.correct_rate}_passage{self.passage_num}"
            f"_n{self.sample_size}"
        ).replace("/", "-")


def checkpoint_path(cfg: RunConfig) -> Path:
    return RESULTS_DIR / f"{cfg.run_id()}.jsonl"


def run_predictions(cfg: RunConfig, client, verbose: bool = True) -> list[dict]:
    """Runs (or resumes) predictions for one ability/model/config combo, checkpointed to
    a JSONL file so interrupted runs can pick back up without re-calling the model."""
    instances = load_jsonl(cfg.dataset_file)
    if cfg.sample_size is not None:
        instances = instances[: cfg.sample_size]

    path = checkpoint_path(cfg)
    done: dict[int, dict] = {}
    if path.exists():
        with open(path, encoding="utf-8") as f:
            for line in f:
                row = json.loads(line)
                done[row["id"]] = row

    rng = random.Random(cfg.seed)
    results: list[dict] = []

    iterator = instances
    if verbose:
        try:
            from tqdm import tqdm

            iterator = tqdm(instances, desc=cfg.run_id())
        except ImportError:
            pass

    with open(path, "a", encoding="utf-8") as f:
        for instance in iterator:
            if instance["id"] in done:
                results.append(done[instance["id"]])
                continue

            if cfg.ability in ("noise", "reject"):
                docs = sample_noise_docs(instance, cfg.noise_rate, cfg.passage_num, rng) if cfg.passage_num > 0 else []
                answer = instance["answer"]
            elif cfg.ability == "integration":
                docs = sample_integration_docs(instance, cfg.noise_rate, cfg.passage_num, rng) if cfg.passage_num > 0 else []
                answer = instance["answer"]
            elif cfg.ability == "counterfactual":
                docs = sample_counterfactual_docs(instance, cfg.passage_num, cfg.correct_rate, rng) if cfg.passage_num > 0 else []
                answer = instance["answer"]
            else:
                raise ValueError(f"Unknown ability: {cfg.ability}")

            try:
                prediction = client.generate(instance["query"], docs, cfg.temperature)
            except Exception as e:  # noqa: BLE001
                print(f"[{cfg.run_id()}] error on id={instance['id']}: {e}")
                continue

            row = {
                "id": instance["id"],
                "query": instance["query"],
                "answer": answer,
                "docs": docs,
                "prediction": prediction,
                "correct": answer_is_correct(prediction, answer),
                "insufficient_info": predicted_insufficient_info(prediction),
                "factual_error_flagged": predicted_factual_error(prediction),
            }
            results.append(row)
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            f.flush()

    return results


# ---------------------------------------------------------------------------
# Metric aggregation
# ---------------------------------------------------------------------------

def accuracy(results: list[dict], reject_counts_as_correct_at_noise_1: bool = False) -> float:
    if not results:
        return 0.0
    if reject_counts_as_correct_at_noise_1:
        correct = sum(1 for r in results if r["insufficient_info"])
    else:
        correct = sum(1 for r in results if r["correct"])
    return correct / len(results)


def rejection_rate(results: list[dict]) -> float:
    if not results:
        return 0.0
    return sum(1 for r in results if r["insufficient_info"]) / len(results)


def error_detection_rate(results: list[dict]) -> float:
    if not results:
        return 0.0
    return sum(1 for r in results if r["factual_error_flagged"]) / len(results)


def error_correction_rate(results: list[dict]) -> float:
    flagged = [r for r in results if r["factual_error_flagged"]]
    if not flagged:
        return 0.0
    corrected = sum(1 for r in flagged if r["correct"])
    return corrected / len(flagged)
