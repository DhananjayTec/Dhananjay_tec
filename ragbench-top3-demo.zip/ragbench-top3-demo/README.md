# RAGBench Checkpoint Demo

Static lookup demo over precomputed checkpoint results across multiple domains.
Checkpoint JSONL files are discovered automatically under `checkpoints/<category>/`.

Selecting **Category → Configuration → Dataset → Question** displays:

- the generated response plus predicted vs. ground-truth TRACe scores,
- the RMSE/AUCROC scoreboard for the whole configuration (all datasets pooled),
- configuration metadata when available.

**No live API calls, no vector index, no Groq key needed.**

## Live demo

`https://pritvish.github.io/ragbench-top3-demo/rag-demo/`

## Checkpoint layout

```
checkpoints/
  bio-medical/          # v8c, v8e, v8l
  general-knowledge/    # v4, v9, v25
  financial/            # v2–v6, tatv1–tatv9, tatv5_best
  Legal/                # results_v19, v25, v31 (flat JSONL files)
```

Each category may use a different folder structure; `demo_data.py` discovers all
`*.jsonl` files recursively and normalizes heterogeneous schemas (RAGBench TRACe
fields vs. legal `generated_response` / `computed_context_*` fields).

## Repo layout

```
ragbench-top3-demo/
  app.py                # local Gradio UI
  demo_data.py          # shared discovery + normalization
  build_pages.py        # static site generator
  checkpoints/
  docs/rag-demo/
    index.html          # generated — do not hand-edit
    data/*.json         # per-category checkpoint data (generated)
  .github/workflows/deploy-rag-demo.yml
```

## Local development

```bash
cd ragbench-top3-demo
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## GitHub Pages (static HTML)

Published as a **static HTML/JS** page. Category data is loaded on demand from
`docs/rag-demo/data/<category>.json` (no Python in the browser).

### Regenerate the static site

After editing checkpoints, `demo_data.py`, or `build_pages.py`:

```bash
python build_pages.py --repo-name ragbench-top3-demo
```

### Local preview

```bash
python build_pages.py
python -m http.server -d docs
# Open http://127.0.0.1:8000/rag-demo/
```

### Deploy

Push to `main` on GitHub. The workflow rebuilds the site when checkpoints or
build scripts change. In GitHub: **Settings → Pages → Source: GitHub Actions**.

## Adding checkpoints

Drop new JSONL files anywhere under `checkpoints/<category>/`, then rerun
`python build_pages.py --repo-name ragbench-top3-demo`. No code changes are
needed unless you want to add configuration metadata in `CONFIG_METADATA` inside
`demo_data.py`.
